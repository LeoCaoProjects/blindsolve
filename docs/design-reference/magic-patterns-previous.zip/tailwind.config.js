export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        bg: '#0C0D0E',
        surface: '#121315',
        raised: '#191B1E',
        hover: '#202226',
        line: '#24272B',
        'line-strong': '#34383D',
        fg: '#ECEAE4',
        muted: '#A2A4A8',
        faint: '#71747A',
        signal: '#7FE0C4',
        'signal-ink': '#06261E',
        warn: '#E8B84E',
        danger: '#F0705F',
        cube: {
          W: '#EEEDE7',
          Y: '#F2CF3A',
          G: '#1E9E5A',
          B: '#2D6BDB',
          R: '#D6363C',
          O: '#EE8424',
        },
      },
      fontFamily: {
        sans: ['Geist', 'system-ui', 'sans-serif'],
        mono: ['"Geist Mono"', 'ui-monospace', 'monospace'],
        serif: ['Newsreader', 'Georgia', 'serif'],
      },
      screens: {
        short: { raw: '(max-height: 640px)' },
      },
    },
  },
}
