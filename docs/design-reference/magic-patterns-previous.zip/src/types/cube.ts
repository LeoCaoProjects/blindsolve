export type Face = 'U' | 'L' | 'F' | 'R' | 'B' | 'D';
export type FaceColor = 'W' | 'Y' | 'G' | 'B' | 'R' | 'O';
export type CubeState = Record<Face, FaceColor[]>;
export type PieceKind = 'edge' | 'corner';
export type StickerKey = string; // `${face}${index}`

export interface Scheme {
  name: string;
  edges: string[];
  corners: string[];
}