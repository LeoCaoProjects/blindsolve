import { FaceColor } from './cube';

export type Penalty = 'ok' | '+2' | 'dnf';
export type PieceScope = 'both' | 'edges' | 'corners';
export type MemoOrder = 'corners' | 'edges';
export type EdgeMethod = 'M2' | 'OP';

export interface MemoPair {
  tokens: string[];
  word: string;
  /** indices inside tokens that were cycle-break targets */
  breaks?: number[];
}

export interface SolveMemo {
  corners: MemoPair[];
  edges: MemoPair[];
}

export interface Solve {
  id: string;
  sessionId: string;
  date: string;
  scramble: string;
  rawMs: number;
  memoMs?: number;
  execMs?: number;
  multiphase: boolean;
  penalty: Penalty;
  memo: SolveMemo;
}

export interface Session {
  id: string;
  name: string;
}

export type TrainingMode = 'exec' | 'guided' | 'recall' | 'trace';

export interface TrainingAttempt {
  id: string;
  mode: TrainingMode;
  date: string;
  scope: PieceScope;
  success: boolean;
  durationMs: number;
  memoMs?: number;
  execMs?: number;
  recallMs?: number;
  correct?: number;
  total?: number;
}

export interface PairEntry {
  shared: string[];
  edges?: string[];
  corners?: string[];
  usage: number;
}

export type PairDB = Record<string, PairEntry>;

export interface FlashAttempt {
  id: string;
  key: string;
  kind: 'edge' | 'corner';
  word: string;
  outcome: 'remembered' | 'forgot';
}

export type FeedbackType = 'bug' | 'feature' | 'general';
export type FeedbackStatus = 'new' | 'reviewing' | 'planned' | 'resolved' | 'archived';

export interface FeedbackRecord {
  id: string;
  type: FeedbackType;
  status: FeedbackStatus;
  message: string;
  date: string;
  source: string;
  user?: {name: string;detail: string;};
  contact?: string;
  screenshot?: string;
  context?: Record<string, string>;
  note?: string;
}

export type AccountMode = 'guest' | 'signedIn' | 'admin' | 'unconfigured';
export type SyncStatus = 'synced' | 'saving' | 'offline' | 'failed';

export interface Prefs {
  showLiveTimer: boolean;
  multiphase: boolean;
  m2Swap: boolean;
  memoOrder: MemoOrder;
}

export interface SetupDraft {
  schemeName: string;
  edges: string[];
  corners: string[];
  edgeBuffer: number;
  cornerBuffer: number;
  edgeMethod: EdgeMethod;
  cornerMethod: 'OP';
  viewTop: FaceColor;
  viewFront: FaceColor;
}