import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { useStore } from './AppStore';
import { sampleScrambles } from '../data/scrambles';
import { uid } from '../utils/dom';

/**
 * PRESENTATION MIRROR of production useTimer / useTimerSession.
 * Lives above routes so the workspace survives navigation (NAV-09, TMR-28).
 */

export type TimerPhase = 'idle' | 'memo' | 'exec' | 'running' | 'stopped';
export type ScrambleStatus = 'preparing' | 'ready' | 'failed';

export interface TimerResult {
  totalMs: number;
  memoMs?: number;
  execMs?: number;
}

interface TimerCtx {
  scramble: string | null;
  scrambleStatus: ScrambleStatus;
  replaceFailed: boolean;
  newScramble: () => void;
  phase: TimerPhase;
  startAt: number;
  splitAt: number | null;
  multiphaseRun: boolean;
  start: (multiphase: boolean) => void;
  press: () => void;
  result: TimerResult | null;
  pendingSolveId: string | null;
  reconstructionOpen: boolean;
  finishReconstruction: () => void;
}

const Ctx = createContext<TimerCtx | null>(null);

export function TimerProvider({ children }: {children: React.ReactNode;}) {
  const store = useStore();
  const [scramble, setScramble] = useState<string | null>(null);
  const [scrambleStatus, setStatus] = useState<ScrambleStatus>('preparing');
  const [replaceFailed, setReplaceFailed] = useState(false);
  const [phase, setPhase] = useState<TimerPhase>('idle');
  const [startAt, setStartAt] = useState(0);
  const [splitAt, setSplitAt] = useState<number | null>(null);
  const [multiphaseRun, setMultiphaseRun] = useState(true);
  const [result, setResult] = useState<TimerResult | null>(null);
  const [pendingSolveId, setPendingSolveId] = useState<string | null>(null);
  const [reconstructionOpen, setReconOpen] = useState(false);
  const requestId = useRef(0);
  const requestCount = useRef(0);
  const scrambleIndex = useRef(0);
  const scrambleRef = useRef<string | null>(null);
  scrambleRef.current = scramble;

  const newScramble = useCallback(() => {
    const id = ++requestId.current;
    const n = requestCount.current++;
    setStatus('preparing');
    setReplaceFailed(false);
    window.setTimeout(() => {
      if (id !== requestId.current) return; // only latest request may land
      const fail = store.simulateFailures && n % 2 === 0;
      if (fail) {
        if (scrambleRef.current) {
          setStatus('ready');
          setReplaceFailed(true);
        } else setStatus('failed');
        return;
      }
      scrambleIndex.current = (scrambleIndex.current + 1) % sampleScrambles.length;
      setScramble(sampleScrambles[scrambleIndex.current]);
      setStatus('ready');
    }, 550);
  }, [store.simulateFailures]);

  useEffect(() => {
    newScramble();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const start = useCallback((multiphase: boolean) => {
    setResult(null);
    setSplitAt(null);
    setMultiphaseRun(multiphase);
    setStartAt(performance.now());
    setPhase(multiphase ? 'memo' : 'running');
  }, []);

  const press = useCallback(() => {
    const now = performance.now();
    if (phase === 'memo') {
      setSplitAt(now);
      setPhase('exec');
      return;
    }
    if (phase !== 'exec' && phase !== 'running') return;
    const totalMs = Math.round(now - startAt);
    const r: TimerResult =
    phase === 'exec' && splitAt ?
    { totalMs, memoMs: Math.round(splitAt - startAt), execMs: totalMs - Math.round(splitAt - startAt) } :
    { totalMs };
    setResult(r);
    setPhase('stopped');
    const id = uid('solve');
    store.addSolve({
      id,
      sessionId: store.activeSessionId,
      date: new Date().toISOString(),
      scramble: scramble ?? '',
      rawMs: r.totalMs,
      memoMs: r.memoMs,
      execMs: r.execMs,
      multiphase: phase === 'exec',
      penalty: 'ok',
      memo: { corners: [], edges: [] }
    });
    setPendingSolveId(id);
    window.setTimeout(() => setReconOpen(true), 520);
  }, [phase, startAt, splitAt, scramble, store]);

  const finishReconstruction = useCallback(() => {
    setReconOpen(false);
    setPendingSolveId(null);
    newScramble();
  }, [newScramble]);

  return (
    <Ctx.Provider
      value={{
        scramble,
        scrambleStatus,
        replaceFailed,
        newScramble,
        phase,
        startAt,
        splitAt,
        multiphaseRun,
        start,
        press,
        result,
        pendingSolveId,
        reconstructionOpen,
        finishReconstruction
      }}>
      
      {children}
    </Ctx.Provider>);

}

export function useTimer(): TimerCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error('useTimer must be used inside TimerProvider');
  return c;
}