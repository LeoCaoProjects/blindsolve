import React, { createContext, useContext, useState } from 'react';

interface Chrome {
  /** true while a solve/attempt is live — navigation recedes */
  quiet: boolean;
  setQuiet: (q: boolean) => void;
  shortcutsOpen: boolean;
  setShortcutsOpen: (o: boolean) => void;
}

const ChromeContext = createContext<Chrome | null>(null);

export function ChromeProvider({ children }: {children: React.ReactNode;}) {
  const [quiet, setQuiet] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  return (
    <ChromeContext.Provider value={{ quiet, setQuiet, shortcutsOpen, setShortcutsOpen }}>{children}</ChromeContext.Provider>);

}

export function useChrome(): Chrome {
  const ctx = useContext(ChromeContext);
  if (!ctx) throw new Error('useChrome must be used inside ChromeProvider');
  return ctx;
}