import React, { createContext, useCallback, useContext, useState } from 'react';
import { PieceScope, TrainingMode } from '../types/domain';
import { sampleChallenges } from '../data/trainingSamples';

/**
 * PRESENTATION MIRROR of production useTrainingSession / SessionWorkspaceContext.
 * One retained workspace per drill; scope shared across drills.
 */

export type DrillPhase = 'idle' | 'active' | 'memo' | 'exec' | 'report' | 'study' | 'recall' | 'review';

export interface DrillState {
  phase: DrillPhase;
  challenge: number;
  preparing: boolean;
  t0: number;
  t1: number | null;
  t2: number | null;
  inputs: {corners: string;edges: string;};
  attemptId: string | null;
  success: boolean;
  display: 'letters' | 'words';
}

const initial = (challenge: number): DrillState => ({
  phase: 'idle',
  challenge,
  preparing: false,
  t0: 0,
  t1: null,
  t2: null,
  inputs: { corners: '', edges: '' },
  attemptId: null,
  success: true,
  display: 'letters'
});

interface TrainingCtx {
  mode: TrainingMode;
  setMode: (m: TrainingMode) => void;
  scope: PieceScope;
  setScope: (s: PieceScope) => void;
  drills: Record<TrainingMode, DrillState>;
  update: (m: TrainingMode, patch: Partial<DrillState> | ((s: DrillState) => Partial<DrillState>)) => void;
  nextChallenge: (m: TrainingMode, prepare: boolean) => void;
  busy: boolean;
}

const Ctx = createContext<TrainingCtx | null>(null);

export function TrainingProvider({ children }: {children: React.ReactNode;}) {
  const [mode, setMode] = useState<TrainingMode>('exec');
  const [scope, setScopeState] = useState<PieceScope>('both');
  const [drills, setDrills] = useState<Record<TrainingMode, DrillState>>({
    exec: initial(0),
    guided: initial(1),
    recall: initial(2),
    trace: initial(0)
  });

  const update = useCallback<TrainingCtx['update']>((m, patch) => {
    setDrills((d) => ({ ...d, [m]: { ...d[m], ...(typeof patch === 'function' ? patch(d[m]) : patch) } }));
  }, []);

  const nextChallenge = useCallback(
    (m: TrainingMode, prepare: boolean) => {
      update(m, (s) => ({
        ...initial((s.challenge + 1) % sampleChallenges.length),
        display: s.display,
        preparing: prepare
      }));
      if (prepare) window.setTimeout(() => update(m, { preparing: false }), 500);
    },
    [update]
  );

  const setScope = (s: PieceScope) => {
    setScopeState(s);
    setDrills((d) => {
      const out = { ...d };
      (Object.keys(out) as TrainingMode[]).forEach((k) => {
        out[k] = { ...out[k], phase: 'idle', inputs: { corners: '', edges: '' }, attemptId: null, t1: null, t2: null };
      });
      return out;
    });
  };

  const busy = drills[mode].phase !== 'idle';

  return (
    <Ctx.Provider value={{ mode, setMode, scope, setScope, drills, update, nextChallenge, busy }}>{children}</Ctx.Provider>);

}

export function useTraining(): TrainingCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error('useTraining must be used inside TrainingProvider');
  return c;
}