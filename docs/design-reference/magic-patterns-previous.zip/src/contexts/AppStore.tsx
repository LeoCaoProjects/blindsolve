import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Scheme } from '../types/cube';
import {
  AccountMode,
  FeedbackRecord,
  FlashAttempt,
  PairDB,
  PairEntry,
  Prefs,
  Session,
  SetupDraft,
  Solve,
  SyncStatus,
  TrainingAttempt,
  TrainingMode } from
'../types/domain';
import { SPEFFZ } from '../utils/lettering';
import { uid } from '../utils/dom';
import { samplePairs } from '../data/vocabulary';
import { sampleSessions, sampleSolves } from '../data/timerHistory';
import { sampleAttempts } from '../data/trainingSamples';
import { sampleFlashHistory } from '../data/flashcards';
import { sampleFeedback } from '../data/feedback';

/**
 * PROTOTYPE PRESENTATION STORE.
 * Mirrors the shape of production state so screens can be wired to
 * StoreProvider / AppDataProvider / SessionWorkspaceProvider later.
 */

export const DEFAULT_SETUP: SetupDraft = {
  schemeName: 'Speffz',
  edges: [...SPEFFZ],
  corners: [...SPEFFZ],
  edgeBuffer: 20, // D:DF
  cornerBuffer: 4, // L:UBL
  edgeMethod: 'M2',
  cornerMethod: 'OP',
  viewTop: 'W',
  viewFront: 'G'
};

const DEFAULT_PREFS: Prefs = { showLiveTimer: true, multiphase: true, m2Swap: false, memoOrder: 'corners' };

interface Account {
  mode: AccountMode;
  sync: SyncStatus;
  lastTried: string;
  name: string;
  detail: string;
  provider: 'WCA' | 'Google';
}

interface LeaveHandlers {
  save: () => void;
  discard: () => void;
}

interface Store {
  ready: boolean;
  prefs: Prefs;
  setPrefs: (p: Partial<Prefs>) => void;
  setup: SetupDraft;
  saveSetup: (s: SetupDraft) => void;
  scheme: Scheme;

  sessions: Session[];
  activeSessionId: string;
  selectSession: (id: string) => void;
  createSession: (name: string) => void;
  renameSession: (id: string, name: string) => void;
  deleteSession: (id: string) => void;
  solves: Solve[];
  sessionSolves: Solve[];
  addSolve: (s: Solve) => void;
  updateSolve: (id: string, patch: Partial<Solve>) => void;
  deleteSolve: (id: string) => void;
  clearSessionSolves: () => void;

  pairs: PairDB;
  savePair: (key: string, entry: PairEntry | null) => void;
  clearFirstToken: (first: string) => void;
  clearAllPairs: () => void;

  attempts: TrainingAttempt[];
  addAttempt: (a: TrainingAttempt) => void;
  updateAttempt: (id: string, patch: Partial<TrainingAttempt>) => void;
  deleteAttempt: (id: string) => void;
  clearAttempts: (mode: TrainingMode) => void;

  flashHistory: FlashAttempt[];
  flashCounts: {seen: number;remembered: number;forgot: number;};
  addFlash: (a: FlashAttempt) => void;
  deleteFlash: (id: string) => void;
  clearFlash: () => void;

  account: Account;
  signIn: (provider: 'WCA' | 'Google') => void;
  signOut: () => void;
  retrySync: () => void;

  feedback: FeedbackRecord[];
  updateFeedback: (id: string, patch: Partial<FeedbackRecord>) => void;
  deleteFeedback: (id: string) => void;
  simulateFailures: boolean;

  settingsDirty: boolean;
  setSettingsDirty: (d: boolean) => void;
  leaveHandlers: React.MutableRefObject<LeaveHandlers | null>;
}

const StoreContext = createContext<Store | null>(null);

interface ProviderProps {
  children: React.ReactNode;
  accountMode: AccountMode;
  syncStatus: SyncStatus;
  emptyWorkspace: boolean;
  simulateFailures: boolean;
}

export function AppStoreProvider({ children, accountMode, syncStatus, emptyWorkspace, simulateFailures }: ProviderProps) {
  const [prefs, setPrefsState] = useState<Prefs>(DEFAULT_PREFS);
  const [setup, setSetup] = useState<SetupDraft>(DEFAULT_SETUP);
  const [sessions, setSessions] = useState<Session[]>(emptyWorkspace ? [{ id: 's-today', name: 'Today' }] : sampleSessions);
  const [activeSessionId, setActiveSessionId] = useState('s-today');
  const [solves, setSolves] = useState<Solve[]>(emptyWorkspace ? [] : sampleSolves);
  const [pairs, setPairs] = useState<PairDB>(emptyWorkspace ? {} : samplePairs);
  const [attempts, setAttempts] = useState<TrainingAttempt[]>(emptyWorkspace ? [] : sampleAttempts);
  const [flashHistory, setFlashHistory] = useState<FlashAttempt[]>(emptyWorkspace ? [] : sampleFlashHistory);
  const [flashCounts, setFlashCounts] = useState(emptyWorkspace ? { seen: 0, remembered: 0, forgot: 0 } : { seen: 7, remembered: 5, forgot: 2 });
  const [feedback, setFeedback] = useState<FeedbackRecord[]>(sampleFeedback);
  const [settingsDirty, setSettingsDirty] = useState(false);
  const leaveHandlers = useRef<LeaveHandlers | null>(null);
  const [ready, setReady] = useState(false);

  const [account, setAccount] = useState<Account>({
    mode: accountMode,
    sync: syncStatus,
    lastTried: '09:26',
    name: 'Leo Cao',
    detail: '2019CAOL01',
    provider: 'WCA'
  });

  useEffect(() => setAccount((a) => ({ ...a, mode: accountMode, sync: syncStatus })), [accountMode, syncStatus]);
  useEffect(() => {
    const t = window.setTimeout(() => setReady(true), 350);
    return () => window.clearTimeout(t);
  }, []);

  const scheme = useMemo<Scheme>(() => ({ name: setup.schemeName, edges: setup.edges, corners: setup.corners }), [setup]);
  const sessionSolves = useMemo(
    () => solves.filter((s) => s.sessionId === activeSessionId).sort((a, b) => b.date.localeCompare(a.date)),
    [solves, activeSessionId]
  );

  const setPrefs = useCallback((p: Partial<Prefs>) => setPrefsState((prev) => ({ ...prev, ...p })), []);

  const createSession = useCallback((name: string) => {
    const id = uid('s');
    setSessions((s) => [...s, { id, name: name.trim() }]);
    setActiveSessionId(id);
  }, []);

  const deleteSession = useCallback(
    (id: string) => {
      setSolves((all) => all.filter((s) => s.sessionId !== id));
      setSessions((list) => {
        const rest = list.filter((s) => s.id !== id);
        if (rest.length === 0) {
          const fallback = { id: uid('s'), name: 'Today' };
          setActiveSessionId(fallback.id);
          return [fallback];
        }
        if (id === activeSessionId) setActiveSessionId(rest[0].id);
        return rest;
      });
    },
    [activeSessionId]
  );

  const value: Store = {
    ready,
    prefs,
    setPrefs,
    setup,
    saveSetup: setSetup,
    scheme,
    sessions,
    activeSessionId,
    selectSession: setActiveSessionId,
    createSession,
    renameSession: (id, name) => setSessions((l) => l.map((s) => s.id === id ? { ...s, name: name.trim() } : s)),
    deleteSession,
    solves,
    sessionSolves,
    addSolve: (s) => setSolves((l) => [...l, s]),
    updateSolve: (id, patch) => setSolves((l) => l.map((s) => s.id === id ? { ...s, ...patch } : s)),
    deleteSolve: (id) => setSolves((l) => l.filter((s) => s.id !== id)),
    clearSessionSolves: () => setSolves((l) => l.filter((s) => s.sessionId !== activeSessionId)),
    pairs,
    savePair: (key, entry) =>
    setPairs((db) => {
      const next = { ...db };
      if (!entry) delete next[key];else
      next[key] = entry;
      return next;
    }),
    clearFirstToken: (first) =>
    setPairs((db) => Object.fromEntries(Object.entries(db).filter(([k]) => k.split('|')[0] !== first))),
    clearAllPairs: () => setPairs({}),
    attempts,
    addAttempt: (a) => setAttempts((l) => [...l, a]),
    updateAttempt: (id, patch) => setAttempts((l) => l.map((a) => a.id === id ? { ...a, ...patch } : a)),
    deleteAttempt: (id) => setAttempts((l) => l.filter((a) => a.id !== id)),
    clearAttempts: (mode) => setAttempts((l) => l.filter((a) => a.mode !== mode)),
    flashHistory,
    flashCounts,
    addFlash: (a) => {
      setFlashHistory((l) => [...l, a].slice(-200));
      setFlashCounts((c) => ({
        seen: c.seen + 1,
        remembered: c.remembered + (a.outcome === 'remembered' ? 1 : 0),
        forgot: c.forgot + (a.outcome === 'forgot' ? 1 : 0)
      }));
    },
    deleteFlash: (id) => setFlashHistory((l) => l.filter((a) => a.id !== id)),
    clearFlash: () => setFlashHistory([]),
    account,
    signIn: (provider) => setAccount((a) => ({ ...a, mode: 'signedIn', provider, sync: 'saving' })),
    signOut: () => setAccount((a) => ({ ...a, mode: 'guest' })),
    retrySync: () => {
      setAccount((a) => ({ ...a, sync: 'saving' }));
      window.setTimeout(() => setAccount((a) => ({ ...a, sync: 'synced', lastTried: 'just now' })), 1200);
    },
    feedback,
    updateFeedback: (id, patch) => setFeedback((l) => l.map((f) => f.id === id ? { ...f, ...patch } : f)),
    deleteFeedback: (id) => setFeedback((l) => l.filter((f) => f.id !== id)),
    simulateFailures,
    settingsDirty,
    setSettingsDirty,
    leaveHandlers
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): Store {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside AppStoreProvider');
  return ctx;
}