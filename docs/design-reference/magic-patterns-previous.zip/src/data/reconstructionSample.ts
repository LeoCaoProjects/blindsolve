// Sample trace for the prototype. Production: domain/bld/trace.ts pauses at buffer returns
// and supplies the valid physical cycle-break candidates; the UI only reports the user's choice.
export interface BreakCandidate {
  token: string;
  tail: string[];
}

export interface PieceTraceSample {
  prefix: string[];
  candidates: BreakCandidate[];
}

export const reconstructionSample: {corners: PieceTraceSample;edges: PieceTraceSample;} = {
  corners: {
    prefix: ['G', 'T', 'O', 'B'],
    candidates: [
    { token: 'C', tail: ['W', 'M'] },
    { token: 'P', tail: ['W', 'K'] },
    { token: 'H', tail: ['W', 'S'] }]

  },
  edges: {
    prefix: ['A', 'Q', 'N', 'F', 'T', 'K'],
    candidates: [
    { token: 'B', tail: ['X', 'M'] },
    { token: 'I', tail: ['X', 'C'] },
    { token: 'V', tail: ['X', 'O'] }]

  }
};