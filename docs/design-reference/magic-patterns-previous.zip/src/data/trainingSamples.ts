import { TrainingAttempt } from '../types/domain';

// Sample challenge target data. Production derives these from the frozen challenge via its BLD engine.
export interface SampleTarget {
  token: string;
  isBreak?: boolean;
}

export interface SampleChallenge {
  scramble: string;
  corners: SampleTarget[];
  edges: SampleTarget[];
}

export const sampleChallenges: SampleChallenge[] = [
{
  scramble: "B2 U' R2 D L2 U F2 D2 R2 U' B' L' U2 F R' D' L2 U' F' R",
  corners: [{ token: 'J' }, { token: 'M' }, { token: 'D' }, { token: 'R' }, { token: 'P', isBreak: true }, { token: 'K' }],
  edges: [
  { token: 'B' }, { token: 'I' }, { token: 'C' }, { token: 'K' }, { token: 'A' }, { token: 'R' },
  { token: 'V', isBreak: true }, { token: 'X' }, { token: 'O' }]

},
{
  scramble: "D2 F' L2 B U2 F' R2 B2 L2 F2 D' L' B' U' R2 F U2 B' L' D'",
  corners: [{ token: 'G' }, { token: 'T' }, { token: 'O' }, { token: 'B' }, { token: 'S' }, { token: 'V' }],
  edges: [
  { token: 'A' }, { token: 'Q' }, { token: 'N' }, { token: 'F' }, { token: 'T' }, { token: 'K' },
  { token: 'I', isBreak: true }, { token: 'R' }]

},
{
  scramble: "U' L2 D' F2 U2 R2 U' B2 R2 D' L B' R' D F2 L2 U B' R D2",
  corners: [{ token: 'A' }, { token: 'K' }, { token: 'E' }, { token: 'L' }, { token: 'C', isBreak: true }, { token: 'W' }, { token: 'M' }],
  edges: [
  { token: 'B' }, { token: 'S' }, { token: 'W' }, { token: 'M' }, { token: 'G' }, { token: 'T' },
  { token: 'L' }, { token: 'P' }, { token: 'D' }]

}];


export const sampleAttempts: TrainingAttempt[] = [
{ id: 'a1', mode: 'exec', date: '2026-11-02T08:30:00', scope: 'both', success: true, durationMs: 41230 },
{ id: 'a2', mode: 'exec', date: '2026-11-02T08:33:00', scope: 'both', success: false, durationMs: 44810 },
{ id: 'a3', mode: 'exec', date: '2026-11-02T08:36:00', scope: 'edges', success: true, durationMs: 27450 },
{ id: 'a4', mode: 'guided', date: '2026-11-01T20:10:00', scope: 'both', success: true, durationMs: 72400, memoMs: 29800, execMs: 42600 },
{ id: 'a5', mode: 'guided', date: '2026-11-01T20:15:00', scope: 'both', success: true, durationMs: 69120, memoMs: 27350, execMs: 41770 },
{ id: 'a6', mode: 'recall', date: '2026-11-01T18:00:00', scope: 'both', success: true, durationMs: 24310, recallMs: 11200, correct: 15, total: 15 },
{ id: 'a7', mode: 'recall', date: '2026-11-01T18:04:00', scope: 'both', success: false, durationMs: 21870, recallMs: 13050, correct: 12, total: 14 },
{ id: 'a8', mode: 'recall', date: '2026-11-01T18:08:00', scope: 'corners', success: true, durationMs: 9840, recallMs: 4100, correct: 7, total: 7 },
{ id: 'a9', mode: 'trace', date: '2026-10-31T21:20:00', scope: 'both', success: true, durationMs: 18450, correct: 16, total: 16 },
{ id: 'a10', mode: 'trace', date: '2026-10-31T21:24:00', scope: 'both', success: false, durationMs: 20110, correct: 13, total: 15 }];