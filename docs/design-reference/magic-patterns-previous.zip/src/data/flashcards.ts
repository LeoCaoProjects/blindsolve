import { FlashAttempt } from '../types/domain';

export const sampleFlashHistory: FlashAttempt[] = [
{ id: 'f1', key: 'A|Q', kind: 'edge', word: 'aqua', outcome: 'remembered' },
{ id: 'f2', key: 'G|T', kind: 'corner', word: 'gate', outcome: 'remembered' },
{ id: 'f3', key: 'T|K', kind: 'edge', word: 'tusk', outcome: 'forgot' },
{ id: 'f4', key: 'B|L', kind: 'corner', word: 'blue', outcome: 'remembered' },
{ id: 'f5', key: 'A|R', kind: 'corner', word: 'armour', outcome: 'forgot' },
{ id: 'f6', key: 'C|K', kind: 'edge', word: 'cake', outcome: 'remembered' },
{ id: 'f7', key: 'S|V', kind: 'corner', word: 'silver', outcome: 'remembered' }];