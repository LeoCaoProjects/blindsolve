export interface NavItem {
  to: string;
  label: string;
  short: string;
  icon: 'timer' | 'training' | 'pairs' | 'cards' | 'settings';
}

export const primaryNav: NavItem[] = [
{ to: '/', label: 'Timer', short: 'Timer', icon: 'timer' },
{ to: '/training', label: 'Training', short: 'Training', icon: 'training' },
{ to: '/pairs', label: 'Letter Pairs', short: 'Pairs', icon: 'pairs' },
{ to: '/flashcards', label: 'Flashcards', short: 'Cards', icon: 'cards' }];


export const settingsNav: NavItem = { to: '/settings', label: 'Settings', short: 'Settings', icon: 'settings' };

export interface ShortcutGroup {
  title: string;
  items: {keys: string[];label: string;}[];
}

export const shortcutsByRoute: Record<string, ShortcutGroup[]> = {
  '/': [
  {
    title: 'Timing',
    items: [
    { keys: ['Space'], label: 'Hold to arm, release to start' },
    { keys: ['Space'], label: 'End memo, then stop' },
    { keys: ['N'], label: 'New scramble' }]

  },
  {
    title: 'Result',
    items: [
    { keys: ['1'], label: 'OK' },
    { keys: ['2'], label: '+2' },
    { keys: ['3'], label: 'DNF' },
    { keys: ['Enter'], label: 'Save solve (review)' },
    { keys: ['Esc'], label: 'Save now' }]

  },
  {
    title: 'History',
    items: [
    { keys: ['⌫'], label: 'Delete latest solve' },
    { keys: ['⇧', '⌫'], label: 'Clear session · delete session in Sessions' }]

  }],

  '/training': [
  {
    title: 'Drill',
    items: [
    { keys: ['Space'], label: 'Hold to start · advance phase · stop' },
    { keys: ['N'], label: 'New scramble (Execution, Guided)' },
    { keys: ['S'], label: 'Solved' },
    { keys: ['D'], label: 'DNF' },
    { keys: ['Enter'], label: 'Next field · submit · next attempt' },
    { keys: ['Esc'], label: 'Show answer (Recall) · cancel word edits' }]

  },
  {
    title: 'History',
    items: [
    { keys: ['⌫'], label: 'Delete latest attempt' },
    { keys: ['⇧', '⌫'], label: 'Clear drill history' }]

  }],

  '/pairs': [
  {
    title: 'Browse',
    items: [
    { keys: ['↑', '↓'], label: 'Move between pairs' },
    { keys: ['←', '→'], label: 'Jump by four' },
    { keys: ['Home', 'End'], label: 'First · last pair' },
    { keys: ['[', ']'], label: 'Previous · next first letter' },
    { keys: ['A–X'], label: 'Type a token to jump' },
    { keys: ['Enter'], label: 'Edit pair' }]

  }],

  '/flashcards': [
  {
    title: 'Cards',
    items: [
    { keys: ['Space'], label: 'Reveal · Remembered' },
    { keys: ['F'], label: 'Forgot' },
    { keys: ['E'], label: 'Edit word' },
    { keys: ['A'], label: 'Add alternate' },
    { keys: ['⌫'], label: 'Delete latest' },
    { keys: ['⇧', '⌫'], label: 'Clear history' }]

  }]

};