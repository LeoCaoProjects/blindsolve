import { TrainingMode } from '../types/domain';

export interface ModeInfo {
  id: TrainingMode;
  name: string;
  short: string;
  line: string;
  meanLabel: string;
  help: string[];
}

export const trainingModes: ModeInfo[] = [
{
  id: 'exec',
  name: 'Execution Sprint',
  short: 'Execution',
  line: 'Execute physically from given memo',
  meanLabel: 'Mean exec',
  help: [
  'Apply the scramble to your cube.',
  'Hold Space, then release. The memo appears and the clock starts.',
  'Execute while reading the memo. Press Space to stop.',
  'Report Solved or DNF.']

},
{
  id: 'guided',
  name: 'Guided Solve',
  short: 'Guided',
  line: 'Full solve with tracing done for you',
  meanLabel: 'Mean total',
  help: [
  'Apply the scramble to your cube.',
  'Hold Space, then release. Memorise the letter pairs.',
  'Press Space to hide the memo and start execution.',
  'Press Space to stop, then report Solved or DNF.']

},
{
  id: 'recall',
  name: 'Memo Recall',
  short: 'Recall',
  line: 'Memorise targets, then type them back',
  meanLabel: 'Mean memo',
  help: [
  'Hold Space, then release. Study the targets.',
  'Press Space or Enter when ready. The targets hide.',
  'Type them back from memory. Enter moves to the next field and submits.',
  'Review mistakes and add missing words.']

},
{
  id: 'trace',
  name: 'Trace Sprint',
  short: 'Trace',
  line: 'Read a scrambled cube into targets',
  meanLabel: 'Mean trace',
  help: [
  'Hold Space, then release. Two views of the same cube appear.',
  'Trace the cube and type the targets.',
  'Enter moves to the next field and submits.',
  'Compare your trace with the expected targets.']

}];