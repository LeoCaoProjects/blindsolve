import { Session, Solve, SolveMemo } from '../types/domain';

const memoA: SolveMemo = {
  corners: [
  { tokens: ['G', 'T'], word: 'gate' },
  { tokens: ['O', 'B'], word: 'oboe' },
  { tokens: ['C', 'W'], word: 'crow', breaks: [0] },
  { tokens: ['M'], word: '' }],

  edges: [
  { tokens: ['A', 'Q'], word: 'aqua' },
  { tokens: ['N', 'F'], word: 'nifty' },
  { tokens: ['T', 'K'], word: 'tusk' },
  { tokens: ['B', 'X'], word: 'boxer', breaks: [0] },
  { tokens: ['M'], word: '' }]

};

const memoB: SolveMemo = {
  corners: [
  { tokens: ['J', 'M'], word: 'jam' },
  { tokens: ['D', 'R'], word: 'dragon' },
  { tokens: ['L', 'P'], word: 'lamp' }],

  edges: [
  { tokens: ['B', 'I'], word: 'bike' },
  { tokens: ['C', 'K'], word: 'cake' },
  { tokens: ['A', 'R'], word: 'arrow' },
  { tokens: ['F', 'R'], word: 'frog' },
  { tokens: ['H', 'N'], word: 'hound', breaks: [0] }]

};

const memoC: SolveMemo = {
  corners: [
  { tokens: ['A', 'K'], word: 'ark' },
  { tokens: ['S', 'V'], word: 'silver' },
  { tokens: ['E', 'L'], word: 'elf' },
  { tokens: ['W'], word: '' }],

  edges: [
  { tokens: ['B', 'S'], word: 'bus' },
  { tokens: ['I', 'R'], word: 'iron' },
  { tokens: ['K', 'N'], word: 'knee' },
  { tokens: ['O', 'B'], word: '' },
  { tokens: ['G'], word: '' }]

};

export const sampleSessions: Session[] = [
{ id: 's-today', name: 'Today' },
{ id: 's-comp', name: 'Comp prep' },
{ id: 's-warm', name: 'Warm-up' }];


export const sampleSolves: Solve[] = [
{ id: 'v1', sessionId: 's-today', date: '2026-11-02T09:02:00', scramble: "R2 D' F2 L2 U' B2 D R2 U2 F2 L' B U' R' F D2 L B' R2 U'", rawMs: 78420, memoMs: 31210, execMs: 47210, multiphase: true, penalty: 'ok', memo: memoA },
{ id: 'v2', sessionId: 's-today', date: '2026-11-02T09:05:00', scramble: "F' U2 L2 F2 D R2 D' B2 U' L2 F2 R' B' D L' U R2 F' D' B", rawMs: 71930, memoMs: 28740, execMs: 43190, multiphase: true, penalty: 'ok', memo: memoB },
{ id: 'v3', sessionId: 's-today', date: '2026-11-02T09:09:00', scramble: "L U2 B2 R' F2 R' D2 L' U2 R2 B' D' F U' L' B2 U R' F' D2", rawMs: 84050, memoMs: 35880, execMs: 48170, multiphase: true, penalty: 'dnf', memo: memoC },
{ id: 'v4', sessionId: 's-today', date: '2026-11-02T09:13:00', scramble: "B2 U' R2 D L2 U F2 D2 R2 U' B' L' U2 F R' D' L2 U' F' R", rawMs: 69310, memoMs: 27020, execMs: 42290, multiphase: true, penalty: 'ok', memo: memoA },
{ id: 'v5', sessionId: 's-today', date: '2026-11-02T09:17:00', scramble: "D2 F' L2 B U2 F' R2 B2 L2 F2 D' L' B' U' R2 F U2 B' L' D'", rawMs: 75640, memoMs: 30110, execMs: 45530, multiphase: true, penalty: '+2', memo: memoB },
{ id: 'v6', sessionId: 's-today', date: '2026-11-02T09:22:00', scramble: "U' L2 D' F2 U2 R2 U' B2 R2 D' L B' R' D F2 L2 U B' R D2", rawMs: 66880, memoMs: 25940, execMs: 40940, multiphase: true, penalty: 'ok', memo: memoC },
{ id: 'v7', sessionId: 's-today', date: '2026-11-02T09:26:00', scramble: "R' U2 F2 D' B2 D L2 U' F2 U' R2 B L' F' D2 R' U B2 L' F2", rawMs: 73120, memoMs: 29900, execMs: 43220, multiphase: true, penalty: 'ok', memo: memoA },
{ id: 'v8', sessionId: 's-comp', date: '2026-10-30T19:40:00', scramble: "F2 D R2 U' L2 D' B2 R2 D2 F' U' R' B' L U2 F' R D' B2 L", rawMs: 81250, memoMs: 33400, execMs: 47850, multiphase: true, penalty: 'ok', memo: memoB },
{ id: 'v9', sessionId: 's-comp', date: '2026-10-30T19:46:00', scramble: "R2 D' F2 L2 U' B2 D R2 U2 F2 L' B U' R' F D2 L B' R2 U'", rawMs: 92310, memoMs: 39020, execMs: 53290, multiphase: true, penalty: 'dnf', memo: memoA },
{ id: 'v10', sessionId: 's-comp', date: '2026-10-30T19:52:00', scramble: "L U2 B2 R' F2 R' D2 L' U2 R2 B' D' F U' L' B2 U R' F' D2", rawMs: 79870, multiphase: false, penalty: 'ok', memo: memoC }];