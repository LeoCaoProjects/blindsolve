import { FeedbackRecord } from '../types/domain';

export const sampleFeedback: FeedbackRecord[] = [
{
  id: 'fb1', type: 'bug', status: 'new', date: '2026-11-02T07:41:00', source: '/training',
  message: 'Trace Sprint: after submitting with an empty edges field, the review shows the corners comparison twice on my phone.',
  user: { name: 'Mira Okafor', detail: '2017OKAF01' },
  screenshot: 'trace-review-iphone.png',
  context: { Drill: 'Trace Sprint · Both', Build: '2026.10.29-a41c', Browser: 'Safari 19', Device: 'iOS 19 · iPhone', Viewport: '390×844' }
},
{
  id: 'fb2', type: 'feature', status: 'reviewing', date: '2026-11-01T22:10:00', source: '/pairs',
  message: 'Would love to see which pairs I most often leave blank during reconstruction.',
  contact: 'lukas.b@example.com'
},
{
  id: 'fb3', type: 'general', status: 'planned', date: '2026-10-31T13:02:00', source: '/settings',
  message: 'The Cube View setting finally made sense to me after I rotated the cube and pressed Use this view. Nice.',
  user: { name: 'Jonas Varga', detail: 'jonas.varga@gmail.com' },
  note: 'Consider surfacing this in setup.'
},
{
  id: 'fb4', type: 'bug', status: 'resolved', date: '2026-10-28T18:55:00', source: '/',
  message: 'Pressing N while the rename field was focused generated a new scramble.',
  user: { name: 'Ana Ruiz', detail: '2015RUIZ02' },
  context: { Build: '2026.10.20-77fe', Browser: 'Chrome 141', Device: 'macOS', Viewport: '1440×900' }
},
{
  id: 'fb5', type: 'general', status: 'archived', date: '2026-10-20T09:15:00', source: '/flashcards',
  message: 'Thanks for the keyboard shortcuts on flashcards.'
}];