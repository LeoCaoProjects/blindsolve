// Prototype sample scrambles. Production generates legal 3BLD scrambles with its cubing engine.
export const sampleScrambles = [
"R2 D' F2 L2 U' B2 D R2 U2 F2 L' B U' R' F D2 L B' R2 U'",
"F' U2 L2 F2 D R2 D' B2 U' L2 F2 R' B' D L' U R2 F' D' B",
"L U2 B2 R' F2 R' D2 L' U2 R2 B' D' F U' L' B2 U R' F' D2",
"B2 U' R2 D L2 U F2 D2 R2 U' B' L' U2 F R' D' L2 U' F' R",
"D2 F' L2 B U2 F' R2 B2 L2 F2 D' L' B' U' R2 F U2 B' L' D'",
"U' L2 D' F2 U2 R2 U' B2 R2 D' L B' R' D F2 L2 U B' R D2",
"R' U2 F2 D' B2 D L2 U' F2 U' R2 B L' F' D2 R' U B2 L' F2",
"F2 D R2 U' L2 D' B2 R2 D2 F' U' R' B' L U2 F' R D' B2 L"];