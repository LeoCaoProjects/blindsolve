import React, { useCallback, useEffect, useRef, useState } from 'react';
import { isControlTarget, isTypingTarget, overlayOpen } from '../utils/dom';

export type HoldState = 'idle' | 'armed' | 'ready';

interface Options {
  enabled: boolean;
  onStart: () => void;
  threshold?: number;
  keyboard?: boolean;
}

/**
 * PRESENTATION MIRROR of production hold-to-start (useTimer / useHoldStart):
 * ~280ms hold arms → ready; release starts; early release / leave / cancel aborts.
 */
export function useHoldToStart({ enabled, onStart, threshold = 280, keyboard = true }: Options) {
  const [state, setState] = useState<HoldState>('idle');
  const stateRef = useRef<HoldState>('idle');
  const timer = useRef<number>();
  const enabledRef = useRef(enabled);
  const startRef = useRef(onStart);
  enabledRef.current = enabled;
  startRef.current = onStart;

  const set = (s: HoldState) => {
    stateRef.current = s;
    setState(s);
  };

  const begin = useCallback(() => {
    if (!enabledRef.current || stateRef.current !== 'idle') return;
    set('armed');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => set('ready'), threshold);
  }, [threshold]);

  const end = useCallback((commit: boolean) => {
    window.clearTimeout(timer.current);
    const was = stateRef.current;
    if (was === 'idle') return;
    set('idle');
    if (commit && was === 'ready' && enabledRef.current) startRef.current();
  }, []);

  useEffect(() => {
    if (!enabled && stateRef.current !== 'idle') end(false);
  }, [enabled, end]);

  useEffect(() => {
    if (!keyboard) return;
    const down = (e: KeyboardEvent) => {
      if (e.code !== 'Space' || isTypingTarget(e.target) || overlayOpen()) return;
      if (!enabledRef.current) return;
      e.preventDefault();
      if (e.repeat) return;
      begin();
    };
    const up = (e: KeyboardEvent) => {
      if (e.code !== 'Space') return;
      if (stateRef.current !== 'idle') e.preventDefault();
      end(true);
    };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, [keyboard, begin, end]);

  const handlers = {
    onPointerDown: (e: React.PointerEvent) => {
      if (isControlTarget(e.target) || overlayOpen()) return;
      begin();
    },
    onPointerUp: () => end(true),
    onPointerLeave: () => end(false),
    onPointerCancel: () => end(false)
  };

  return { state, handlers };
}