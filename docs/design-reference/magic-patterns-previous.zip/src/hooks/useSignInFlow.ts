import { useEffect, useRef, useState } from 'react';
import { useStore } from '../contexts/AppStore';

type Provider = 'WCA' | 'Google';

/**
 * PROTOTYPE stand-in for production useSignInFlow: simulates the OAuth round trip
 * so pending, return and migration states can be reviewed.
 */
export function useSignInFlow(onSignedIn?: () => void) {
  const store = useStore();
  const [pending, setPending] = useState<Provider | null>(null);
  const [migrating, setMigrating] = useState(false);
  const timer = useRef<number>();

  useEffect(() => () => window.clearTimeout(timer.current), []);

  const start = (p: Provider) => {
    setPending(p);
    timer.current = window.setTimeout(() => {
      setPending(null);
      store.signIn(p);
      const hasGuestData = Object.keys(store.pairs).length > 0 || store.solves.length > 0;
      if (hasGuestData) setMigrating(true);else
      onSignedIn?.();
    }, 1600);
  };

  return {
    pending,
    start,
    cancel: () => {
      window.clearTimeout(timer.current);
      setPending(null);
    },
    migrating,
    finishMigration: () => {
      setMigrating(false);
      store.retrySync();
      onSignedIn?.();
    }
  };
}