# BlindSolve — Master handoff for Magic Patterns

**CURRENT BLINDSOLVE = FUNCTIONAL SOURCE OF TRUTH.**

**MAGIC PATTERNS = FUTURE PRESENTATION SOURCE OF TRUTH.**

**PRESERVE CAPABILITY, NOT CURRENT PRESENTATION.**

Audited source `2eeab8872d3a8106a0ef0b711b8108407e85c887`. Eight screen routes, two legacy redirects, wildcard not-found, 278 functional contract entries, 87 screenshot references. Documentation only; no final visual-design prompt.

The designer may radically redesign navigation, layout, typography, spacing, component architecture, information hierarchy, dialogs, cards, page composition, responsive composition, Timer, Training, Settings and reconstruction presentation. Every real capability and data meaning must remain accounted for. Current screenshots are functional evidence, not visual inspiration.

This consolidated document includes the entire numbered package, including the full contract and screenshot index; no sibling document is required to understand product behavior. Images and machine-readable evidence are supplied alongside it.

---

<!-- Source section: 00_READ_ME_FIRST.md -->

# BlindSolve: functional handoff for a complete presentation redesign

Audit date: 2 November 2026, Pacific/Auckland. Documentation and functional reference only. This package is **not a visual-design prompt**.

**CURRENT BLINDSOLVE = FUNCTIONAL SOURCE OF TRUTH.**

**MAGIC PATTERNS = FUTURE PRESENTATION SOURCE OF TRUTH.**

**PRESERVE CAPABILITY, NOT CURRENT PRESENTATION.** Navigation, layouts, typography, spacing, component architecture, information hierarchy, dialogs, cards, page composition, responsive composition, Timer presentation, Training presentation, Settings presentation, and reconstruction presentation may all be radically redesigned. None of those freedoms permits silently removing a real action, state, data distinction, or accessibility requirement.

## Baseline and evidence

- Audited source: `2eeab8872d3a8106a0ef0b711b8108407e85c887`, remote `main`, fetched during this audit. Its tree equals `64eaabc` (the concise-copy branch merged by PR #3).
- Original workspace remained on `dev`, `2b0e69e03d99ee6dfbacba0ef2df1acc4514394d`, initially clean. Local `main` was stale at `b6cded8`; the cached `origin/main` was also stale at `8fd10f4`. Neither was accepted as current without checking the remote.
- Live reference: https://blindsolve.com/ and its routes, inspected during this audit. Public HTML loaded `/assets/index-BRiBABqx.js` and `/assets/style-BZVYYi60.css`.
- **Deployment provenance limit:** current remote main and observed production behavior agree, including latest copy and redirects. No deployment manifest, Cloudflare deployment SHA, or byte-for-byte reproducible deployed JS comparison was available. Therefore the source SHA above is exact; attribution of the deployed build to that SHA is strongly supported, not independently certified.
- Browser captures prefixed `production` or containing `-production-` are live-site references. Captures containing `-local-` are the unmodified audited main source running at `127.0.0.1:5184` with no Supabase configuration and disposable guest data. Times and answers in local captures are audit examples, not genuine physical solves.
- `matrix-*` captures are production at each named, measured viewport. Measurements are saved in `screenshots/responsive-measurements.json`.
- Source paths throughout this package refer to **the audited main SHA**, not necessarily to files available in the older checked-out dev tree. Use `git show 2eeab887:path` to recover them.

## Reading order

Read the consolidated `MAGIC_PATTERNS_MASTER_HANDOFF.md` to upload one self-contained specification. The numbered documents provide focused reading. The functional contract supplies independently checkable requirements. The screenshot index records provenance and viewport sizes. Screenshots are evidence of capabilities and current weaknesses, **not visual inspiration**.

Code-present, browser-observed, and unavailable live states are distinguished explicitly. A component prop, retired file, persisted legacy enum, or preview initializer does not prove a user-facing feature exists. `useScreenInit.js` returns `{}` in the audited product; preview props are not public configuration options.

The CubeIQ brief and linked Notion overview were read for repository context. They describe a camera/CFOP project vision and are **not evidence that BlindSolve has camera recording, automatic human move recovery, or CFOP analytics**. The current BlindSolve entry point mounts `src/magic/App.tsx`; the older `src/pages` and `src/features/timer` trees are not its routed product.

## Deliverable boundary

This work changed documentation/reference files only. It did not redesign the app, change production source, configure authentication, modify databases, submit feedback, deploy, or create a Magic Patterns design prompt. A temporary source extraction was used for safe stateful inspection. One synthetic Timer run was begun in the live signed-out browser, creating a pending guest solve locally; its reconstruction was not saved. Automatic approval review stopped further live progression, so all subsequent saved examples used the isolated local copy.

---

<!-- Source section: 01_PRODUCT_OVERVIEW.md -->

# Product overview

BlindSolve supports 3×3 blindfolded cube practice: timing physical solves, tracing the scramble into blindfold targets, recording the user's cycle-break and mnemonic choices, maintaining a letter-pair vocabulary, practising mnemonic flashcards, and running four focused drills. It supports optional WCA/Google sign-in and local-first account synchronization.

The core user is a blindfolded cuber using physical sticker buffers, a lettering scheme, M2 or Old Pochmann edges, and Old Pochmann corners. A target is a directed sticker on a piece. A letter is the user's label for that sticker, not the sticker's identity. A letter pair may have a shared mnemonic and separate edge/corner overrides.

## Main journeys

1. Open Timer, receive a legal 3BLD scramble, optionally inspect the cube and its letters, and apply the scramble physically. Hold/release to time the solve, optionally split memo from execution, stop, reconstruct cycle breaks/mnemonics, choose OK/+2/DNF, and save. Review the solve in the active session.
2. Choose a Training drill and Both/Edges/Corners. Start by hold/release. Depending on the drill, read provided memo, memorize and recall letters, trace a cube, or memorize then execute a physical solve. Review measured time and either objective typed-answer comparison or a self-reported physical outcome. Next returns to idle.
3. Browse Letter Pairs by first token and scope; create/edit a primary word, alternates, and overrides. Suggestions are opt-in, not automatically saved.
4. Flashcards shows eligible saved pairs randomly, reveals their effective mnemonic, records Remembered/Forgot, and permits immediate word edits and alternates.
5. Settings edits cube labeling, physical buffers, view orientation, methods, memo order, and Timer preferences; it also exposes account status, backups, and feedback. Setup is a separate optional first-use wizard.

## Current capabilities versus absent features

| Exists | Must not be inferred from a name or old plan |
|---|---|
| Mathematical scramble cube and BLD target tracing | Camera observation of a physical solve |
| User-specified cycle breaks and remembered mnemonic words | Recognition of actual face turns, replay, or move timestamps |
| Manual physical Solved/DNF self-report | Automatic verification that the physical cube is solved |
| Random flashcard practice and saved practice records | Spaced repetition, adaptive weighting, scheduled reviews |
| Current session best, mo3, success count; drill means/counts | Graph dashboards, ao5/ao12, rankings, CFOP analysis |
| WCA/Google OAuth | Password accounts, password reset, profile editing, account deletion |
| Optional imported BlindSolve JSON backup | General csTimer import or arbitrary file conversion |
| 3BLD workflows | Smart-cube connection, Bluetooth timer, camera permission UI, other puzzle events |

## Data users depend on

Solves retain raw time, optional memo split, result, scramble, date, session, scheme snapshot, cycle-break choices, raw target tokens and, when completed, mnemonic snapshots with optional execution-target identities. Practice records are separate from Timer solves. Letter-pair records retain primary/alternate words and practice counters. Settings, sessions, pairs, solves, and attempts use the existing local/account store.

In-memory Timer and per-drill workspaces survive SPA navigation. This is distinct from durable saved data: a reload does not restore an active Timer clock, unsaved reconstruction controller, unsaved form, or active training phase. Saved histories do restore. The current route is the URL; do not invent a persisted 'last destination' setting.

PRESERVE CAPABILITY, NOT CURRENT PRESENTATION. The existing app bar, split columns, horizontal strips, and side sheets are implementations, not product requirements.

---

<!-- Source section: 02_ROUTE_AND_FEATURE_INVENTORY.md -->

# Routes, shell, secondary surfaces

Source: `src/main.tsx` → `src/App.tsx` → `src/magic/App.tsx`. Providers: `StoreProvider`, `AppDataProvider`, `SessionWorkspaceProvider`; global `ErrorBoundary`; reduced-motion preference via `MotionConfig`.

## Route census

**Eight screen routes**, **two explicit legacy redirects**, and **one wildcard/not-found handler** were audited. Query/preview states are not separate routes.

| Route | Screen / access | Required destinations and actions |
|---|---|---|
| `/` | Timer; guests and accounts | Scramble, clock, cube, session chooser, solve list, details, reconstruction, shortcuts, cleanup |
| `/training` | Training; guests and accounts | Four drills, shared piece scope, help, stateful workspace, result review, history cleanup |
| `/pairs` | Letter Pairs | First-token browser, Shared/Edges/Corners, pair inspector, suggestions, scoped clears |
| `/flashcards` | Flashcards | Random card, reveal/self-report, inline word edits, recent-card history |
| `/settings` | Settings | Cube & lettering, Methods, Timer, Account & sync, Data, Support; setup link; conditional admin link |
| `/setup` | Optional wizard | Lettering → Edge buffer → Corner buffer → Ready; Back/Continue, Use defaults, Sign in, Start timing |
| `/signin` | OAuth surface | Continue with WCA, Continue with Google, redirecting/cancel, migration choice; Continue without signing in |
| `/admin/feedback` | Database-granted admins | Filter/search inbox, details, statuses, note, archive/restore/delete. Non-admins redirect to Settings |
| `/memo` | Legacy redirect | `/training`, replace in SPA; production redirect is HTTP 301 |
| `/about` | Retired page redirect | `/`, replace in SPA; production also redirects `/about/` and `/about.html` |
| `*` | Not found | Page not found and return-to-Timer link; static production 404 includes 'This address does not exist.' |

Production `_redirects` also canonicalizes `www` and trailing slashes for supported routes. `src/seo/pages.json`, `RouteMetadata.tsx`, and `scripts/build-seo.mjs` supply route titles/descriptions, canonical URLs, loading fallback HTML and indexing behavior. Settings/Setup/Sign-in/Admin are noindex. Preserve route access/deep links and appropriate metadata; the static SEO fallback is not another interactive app.

## Current navigation mechanics

`AppBar` exposes Timer, Letter Pairs, Flashcards, Training, Settings, and desktop keyboard-help access. It uses actual links for primary routes, selected-route `aria-current`, and shorter mobile labels Pairs/Cards. On screens below `md` the help icon is hidden; `?` remains a keyboard affordance. There is no hamburger menu, mobile bottom navigation, global avatar menu, or header profile editor in audited main. Account controls live under Settings.

Timer additionally exposes the session chooser in its shell. Training has secondary drill navigation and piece/display controls. Settings section navigation scrolls an internal container and tracks the visible section. The wizard and sign-in page use their own shells.

Navigation through the app bar respects the Settings dirty-draft guard. Modified link clicks keep ordinary browser-link behavior. Do not claim all navigation and tab close are blocked: the guard is an app-level callback, not a universal browser-router/unload blocker. In-memory workspace providers remain mounted across SPA route changes. Keyboard listeners activate only for their active Timer/Training destination; navigating away is not equivalent to stopping or saving an attempt.

## Overlay / action census

| Owner | Distinct surfaces |
|---|---|
| Timer | Keyboard shortcuts; Sessions; rename field; session-delete confirmation; latest/history cleanup confirmation; solve details; reconstruction break/word/review stages; mnemonic suggestions; changed-word decision controls |
| Training | How it works/help sheet; shortcuts; four review surfaces; Recall missing-word edit/suggestion state; pending-review Save/Cancel; history cleanup |
| Letter Pairs | Pair inspector; Shared/Edges/Corners editor states; suggestions/More; Clear pair confirmation; Clear first-token section confirmation |
| Flashcards | Inline Edit and Add alternate forms; shortcuts; latest/whole-history cleanup confirmation |
| Settings | Speffz replace confirmation; unsaved changes Save/Discard; Stay/Discard/Save and leave dialog; backup valid/invalid import dialog; clear-all-pairs confirmation; sign-out confirmation; feedback sheet |
| Authentication | Provider pending state; device-data migration dialog |
| Feedback admin | Record inspector; status control; private note draft; permanent-delete confirmation |
| Global | Runtime error screen and reload action |

There is no separate history URL or reconstruction URL; these are Timer overlays. Training history rows are readouts with delete controls, not reopenable attempt-detail pages. Flashcard history rows do reopen their pair in revealed state.

Preserve access to every destination and action. The redesign may completely replace the current navigation architecture.

---

<!-- Source section: 03_TIMER_AND_RECONSTRUCTION.md -->

# Timer and reconstruction: behavior and meaning

Primary sources: `hooks/useTimer.ts`, `useTimerSession.ts`, `useReconstruction.ts`, `contexts/SessionWorkspaceContext.tsx`, `components/concepts/workspace/{WorkspaceTimer,WorkspaceHistory,WorkspaceReconstruction,WorkspaceSolveDetails}.tsx`, `components/reconstruction/*`, `domain/bld/{trace,memoConventions,orientation}.ts`, `utils/{reconstruction,time}.ts`.

## Scramble and cube

Timer initially shows `Preparing scramble…`, with New scramble disabled and timing disabled until a nonempty scramble is ready. It generates a legal 3BLD scramble with the production cubing engine. The diagram derives from exactly the displayed scramble. Notation is interpreted in the fixed white-top/green-front reference even if the user changes Cube View.

New scramble is available at rest, with `N` outside text inputs/modifier shortcuts and overlays. It is disabled while running or generating. Each request has a monotonically increasing identity: only the latest completed request may replace text, error, or pending state; late results cannot undo a newer choice. Unmount invalidates outstanding work. Initial failure reads `Scramble unavailable. Try again.`; failure with an existing scramble retains that scramble and says `New scramble failed`. The same New scramble action retries. Previous solve records remain intact.

The desktop cube supports temporary drag rotation and a Sticker letters toggle. Letters come from the saved scheme. A new state or saved view resets the temporary angle. On mobile, the Timer's entire reference cube area is currently hidden; this is a presentation weakness to reconsider, not permission to remove cube inspection as a product capability.

## State machine

| State | User sees | User does / required transition |
|---|---|---|
| idle | 0.00, scramble, session reference | Hold Space or the timing surface → armed |
| armed | Muted timer/hold feedback | Release before ~280 ms → previous idle/stopped state, no new solve |
| ready | Ready accent; zero timer | Release → memo if multiphase on, otherwise running |
| memo | Advancing total and memo-active phase marker | Space or pointer down records memo split → exec |
| exec | Advancing total; frozen memo split when live display enabled | Space or pointer down stops |
| running | Advancing single total, no memo/execution split | Space or pointer down stops |
| stopped | Recorded total and optional split values | Pending solve/draft created asynchronously; reconstruction opens after approximately 520 ms |

Timer measures monotonic elapsed time; the visible readout floors to hundredths and uses minute formatting above 60 seconds. Starting a fresh run clears the prior split. Space prevents page scrolling, repeated keydown does not double-trigger, and typing targets are ignored. A key/pointer lock prevents the release after a memo/stop press from starting another run. Armed/ready cancel when timing becomes disabled. Pointer timing is limited to the timing surface, not arbitrary buttons.

`Show live timer` defaults on. When off, active memo/exec/running displays **Solve**, and active numeric split values are hidden. Timing continues internally. Stopped/result/reconstruction/details still show recorded values. This setting applies to Timer presentation; Training clocks do not consume it.

App bar/cube/history recede visually during a run. Fading is not the same as disabling every navigation control. Timer state lives above routes and continues to exist across SPA navigation; page-specific keyboard controls are inactive away from `/`. The controller is not persisted as an active clock across reload.

## Pending result and penalties

Stop inserts a pending solve using the current scramble, raw total, memo/execution times, scheme snapshot, canonical cycle-break choices, session ID and date. Initial result is success/OK. A draft holds the scheme, state, current memo preferences, and presentation sample. Reconstruction is the next step, rather than a second solve record.

Result control offers **OK**, **+2**, **DNF**, with keys **1**, **2**, **3**. +2 changes effective total by 2 seconds and retains raw recorded time. DNF is a result designation, not a zero-duration solve. Historical raw duration and memo split are not overwritten by penalties. Details permit later penalty changes.

## Reconstruction is target tracing, not observed move recovery

The cube shown is the mathematical state **at the start of memo / after the scramble**. It can be rotated and highlighted, but it does not advance through face turns as the user answers. There are no playback, next-move, previous-move, timeline-scrubbing or algorithm-execution controls. Progression is through cycle-break questions, mnemonic questions, and review. Do not invent physical-move reconstruction, camera evidence, or a shortest solver path as an observed human sequence.

The production engine traces edges/corners from physical directed buffers and the selected lettering scheme. At a buffer return with unsolved cycles, it pauses with valid physical cycle-break candidates. UI shows the pending sequence slot, candidate letter buttons, and cube highlights. The user chooses a valid candidate; its physical ID is appended to the relevant piece's choices and the engine retraces. Multiple breaks can occur. Piece ordering follows the draft's memo-order preference. This is not a quiz with one canonical 'right' cycle break: the user reports the break they used from the valid set.

Break keyboard interaction: arrows wrap focused candidate, Enter selects, a matching single-character target key selects directly, and the visible sticker buttons provide pointer access. Multi-character tokens are supported in lettering; their labels are not all reachable by a single key. Back only traverses later word/review step indices; it is not a cycle-break undo stack.

### Raw trace and execution representation

- Raw targets retain physical sticker IDs, order, token, and cycle-break metadata. Custom labels must never be used as physical identities.
- Trace Sprint and Memo Recall consume raw targets. Execution Sprint and Guided Solve consume the prepared execution representation.
- The M2 preference can transform affected targets on every second M2 shot, zero-based odd indices, using physical UF/DB mappings in the method frame inferred from the saved buffer. It must not change the raw trace or use hard-coded user letters.
- The setting is effective only with M2 in a compatible configuration. OP edges and OP corners do not inherit M2 swaps. The corner UI offers OP only.
- The default M2 buffer is physical `D:DF`; corner OP buffer is physical `L:UBL` (the UI may spell the piece LUB). Method changes choose a conventional edge buffer relative to the current Cube View once; subsequent view changes are presentation-only.
- Odd M2 target count carries parity metadata. That internal flag does not add an extra raw target, parity step, or count. Audited main removed the explanatory M2-execution labels and has no parity-instruction screen or manual M2-orientation selector. Preserve internal distinctions without treating removed helper labels as mandatory copy.

### Mnemonic steps

Once required cycle breaks are resolved, reconstruction asks for words for unique full pairs missing an effective mnemonic in their piece context. The same letter pair in edges and corners remains separately addressable. Repeated occurrences within one piece are not repeated questions. A trailing single target has no full-pair word question. The user can enter the word they used, request suggestions, Skip the word, Continue, and go Back between later steps. Existing effective words are available in final review and may be edited there.

Review shows ordered corner/edge pairs and words, cycle-break marking, new words to be added, and changed words requiring a decision:

| Decision | Solve snapshot | Vocabulary result |
|---|---|---|
| Keep existing (default) | Retains the word entered for this solve | Leaves stored words unchanged |
| Use new word | Retains the entered word | Replaces primary, retains later alternates |
| Add as alternate | Retains the entered word | Appends a new alternate |

Comparison of changed/new words trims and compares case-insensitively. New nonempty words join the appropriate piece vocabulary. Blank skipped words remain blank in the solve; they are not invented by the designer.

**Save solve** commits the result, raw memo/cycle-break data, mnemonic snapshot and selected vocabulary updates, closes the reconstruction, and requests a new scramble. Enter on review saves. **Skip to save** and **Escape** call the finish path immediately; they do not require every mnemonic or every break question to be completed. In particular, a skip during a pending break can save the current partial trace even though the record is marked complete. Do not describe skip as guaranteed full canonical reconstruction. Treat this as an implementation caveat requiring deliberate later integration, not a license for prototype code to repair domain behavior.

## History and details

The active session's list is newest first and excludes deleted records. Each row exposes its solve number/time and a direct delete action. Selecting the row or latest-solve readout opens details with date, scramble, scrambled cube, raw/effective time, result controls, optional memo/execution split, and saved memo words. Historical word snapshots remain visible; if the current primary differs, a secondary `now …` note identifies that difference. Empty word slots display a dash.

Details close with Close, Escape, or scrim. Keys 1/2/3 change penalty. Delete solve in details and row delete act directly; the shared keyboard delete-latest and clear-history paths ask for confirmation. Preserve this distinction rather than claiming every deletion has a confirmation today.

Session statistics: best effective non-DNF time; **mo3** is the arithmetic mean of the latest three, DNF if any of those three are DNF; success is non-DNF/total. Missing best/mo3 is a dash. No ao5, ao12 or chart exists. Last-solve memo is hidden on mobile; details remain available. Source also contains `short:hidden`, but audited Tailwind configuration does not define a short breakpoint, so this class is not evidence of working short-height hiding.

Sessions: chooser shows names, current selection and solve counts; select closes chooser; nonempty new name creates/selects a session; rename commits on blur/Enter and cancels on Escape; delete always asks, including empty sessions, and removes that session's solves. Deleting the last session creates a usable Today fallback. Active session identity persists. `Shift+Backspace/Delete` inside Sessions asks to delete the active session, distinct from clear-current-history outside it.

Keyboard `?` opens shortcuts; Backspace/Delete asks to delete latest at rest; Shift+Backspace/Delete asks to clear active session at rest. Typing/dialogs/running disable cleanup shortcuts. There is no independent reconstruction-resume route for old pending solves.

---

<!-- Source section: 04_TRAINING.md -->

# Training inventory

Sources: `data/trainingModes.ts`, `pages/Training.tsx`, `hooks/useTrainingSession.ts`, `useExecScramble.ts`, `useHoldStart.ts`, `components/training/*`, `components/training/review/*`, `utils/{bld,challengeTargets,training,guidedSolve}.ts`.

Exactly four active modes, in this order: **Execution Sprint**, **Guided Solve**, **Memo Recall**, **Trace Sprint**. Legacy persisted `full`/Full Memo is excluded from active history/modes; do not restore it as a fifth drill.

## Shared setup, lifecycle, and persistence

- Piece scope is **Both**, **Edges**, **Corners**. Both means both piece classes; Guided review labels the same scope All. Scope is shared across the four drills, while challenge seeds and active workspaces are distinct per drill.
- Start only by holding/releasing Space or the idle practice surface (~280 ms). A short hold cancels. Pointer leave/cancel cancels arming. Button/link/input targets do not start a hold. No drill starts automatically on route entry or Next.
- Drill selector and setup controls lock during active/recall/memo/execution/report/review. Desktop uses radio-like tabs; phones use a native Drill select. Piece controls are replaced by clocks while busy; Execution Sprint's clock is in the stage.
- Execution-oriented drills prepare exact physical scrambles for scope. Text, cube state and target memo derive from the same frozen challenge. `N`/New scramble changes it only while idle and ready. While preparing, text reads `Preparing scramble…`, New scramble and hold start are unavailable. There is no dedicated user-visible generation-error/retry panel in this hook: do not fabricate one.
- Scope changes invalidate/reset challenge input, phase, result and timing across affected per-mode controllers. Idle mode changes select the other retained controller; navigating to another route and back does not recreate its challenge. Settings changes can recompute derived challenge/target data; no separate 'settings changed, restart?' dialog exists.
- Help explains the selected drill. Shortcuts sheet and shared deletion confirmations exist. Space in a text field is input, not a phase transition. Enter advances fields and submits the final field. Review Enter advances only when no pending word edit needs saving.
- Attempts are stored separately from Timer solves, restored after reload and account hydration, filtered by drill. Submissions use synchronous challenge guards to avoid duplicate records. Seeded review props do not correspond to saved attempts and cannot overwrite real history.
- Wide-screen aside shows count, correct/solved fraction and mean appropriate to the drill, plus newest-first attempt rows and direct delete. Clear and keyboard latest/clear paths confirm. Empty history says No attempts yet. Below `xl` this aside is hidden with no alternate history drawer currently provided.
- Review panels have summary, scrollable body, stable footer and Next. Clicking the scrim is Next unless there are pending word edits. Next always returns idle; the next challenge starts only after another hold.

## Execution Sprint

Purpose: practise physical blind execution while reading provided memo; not memory testing. Apply the displayed scramble physically before timing. Scope supports Both/Edges/Corners. Setup includes **Show: Letters / Words**, default Letters; this is unique to this drill.

Start reveals execution targets and starts one execution clock. The scramble and challenge cube step away during the run. Both-scope groups use memo-order preference. Letters shows token pairs; Words shows each effective piece mnemonic, falling back to letters where no word exists. A trailing single target remains a letter. There is no typed answer or automatic cube verification.

Space, Stop, or non-control pointer down on the active stage ends the attempt. Review shows total, target count, full-pair count, per-target time, scramble, scrambled cube, corner/edge memo with cycle-break markers and saved words. **Solved / DNF** is self-reported; Solved is initially selected. S/D changes the result of this attempt by its stable saved ID. No +2 in this drill. Review Next returns idle and prepares the next scramble. Saved drill mean is execution duration; unsuccessful attempt rows show DNF.

## Guided Solve

Purpose: a complete physical blind solve with tracing already provided. It replaces the former Full Memo mode. Scope supports Both/Edges/Corners. Setup shows the exact scramble to apply. There is no Words display switch here.

Lifecycle: **idle → memo → execution → report → review → idle**. Hold/release starts memo timing and reveals generated execution-target letter pairs. Space/Start execution hides memo and begins the execution split, retaining the same immutable challenge. During execution the stage says Solving and shows running total; header shows memo and execution values. Space/Stop freezes total and presents **Did you solve the cube? Solved / DNF**. S/D can report the result. No attempt is persisted until that report is made; repeated reports cannot duplicate it.

Review shows total and Solved/DNF, memo time, execution time, scope (All/Edges/Corners), original scramble and per-piece letter sequences. Stored data includes scope, scramble, raw physical targets, execution physical targets, token snapshot and memo order. This is self-reported physical success, not objective recognition. There is no review result-toggle control equivalent to Execution Sprint; Next starts the next setup. Memo and execution durations must sum to total according to the production timing helper.

## Memo Recall

Purpose: memorize a generated raw target sequence and type it from memory. Scope supports Both/Edges/Corners. Idle hides the challenge; wide reference cube is solved until start. Hold/release generates the next challenge, shows letter pairs and the matching scrambled cube, and starts memo time.

Space/Enter or Ready ends study, freezes memo time, hides letters, dims the cube to ~8% opacity, and focuses the first Recall input. Inputs are separated by piece in memo-order preference. Enter moves to the next input or submits. Submit/Show answer/Escape submits the current answer, including blanks; it is not a free reveal without an attempt. Recall elapsed is displayed separately. The saved history duration/mean is **memo time**, not combined memo+recall time.

Review compares expected and entered tokens position by position. It distinguishes correct, wrong, missing and extra tokens; it is not edit-distance alignment or alternative-cycle-break validation. Summary shows Correct/Incorrect, correct target count/total, memo and recall times. All-correct groups have their own indication; mismatches show expected/yours pair comparisons.

The vocabulary review initially shows **Worth a look**: missing words or missed pairs. Show all words/Show fewer changes that list. Missing full pairs allow No word · add and opt-in suggestions. Drafting does not save immediately. A nonempty pending draft changes footer to unsaved-word count, Cancel, Save; scrim/Next is blocked until resolved. Enter saves pending words; Escape cancels drafts. Saving writes piece-specific mnemonic words and marks them saved. Trailing single targets have no word slot. Suggestions appear after answer submission, not during memorization.

## Trace Sprint

Purpose: read a scrambled cube into raw targets as fast as possible, not memorize a provided sequence. Scope supports Both/Edges/Corners. Hold/release reveals two linked cube views of one state: front and back, not two challenges. Face labels and hidden-partner cues help identify stickers. Cubes can be rotated; the companion follows the same physical cube.

During active phase, users type Corners targets and/or Edges targets. Inputs use scheme-aware tokenization including multi-character tokens; grouping follows memo order. Enter advances fields then submits; Submit works with incomplete/blank answers. The clock measures trace duration. Inputs stop accepting changes once review begins.

Review shows total trace time, Correct/Incorrect, correct targets/total, accuracy percentage, per-target time, and expected/yours token comparison per piece. It does not provide mnemonic editing or a physical Solved/DNF choice. Next returns idle. Saved mean is trace duration.

## Responsive and state limits

At wide widths Trace Sprint places cube pair beside inputs when measured stage width ≥900 and height ≥320; otherwise it stacks cube pair above scrollable answers. Cube size is clamped; two cubes remain the same challenge. Memo Recall uses an inline cube below `xl`, above content on phones, and a reference-aside cube on wide screens. Active Execution/Guided content can scroll without pushing primary footer actions away. Review widths are capped by the viewport and become full width on phones. Do not preserve hidden history, cramped controls, dimming, or current horizontal tab architecture as visual requirements.

Current code has no difficulty/sequence-length selector, drill scheduling, arbitrary mode list, recognition training, hardware input, camera verification, generic retry-same-challenge button, or practice analytics dashboard. Preserve each mode's real distinct lifecycle instead of merging them into a generic start/stop mockup.

---

<!-- Source section: 05_LETTER_PAIRS_AND_FLASHCARDS.md -->

# Letter Pairs and Flashcards

Sources: `pages/{LetterPairs,Flashcards}.tsx`, `components/pairs/*`, `hooks/useFlashcards.ts`, `utils/pairs.ts`, `contexts/AppDataContext.tsx`, `domain/letterPairs/index.ts`.

## The mnemonic model

The visible database is keyed by `${first}|${second}`. Tokens can contain multiple characters, so plain concatenation is not a safe replacement for this model. Entry shape: ordered `shared` words, optional ordered `edges` words, optional ordered `corners` words. First word is primary, later words are alternates.

| Context | Effective list |
|---|---|
| Shared | Shared words only |
| Edges | Nonempty edge override, else shared, else empty |
| Corners | Nonempty corner override, else shared, else empty |

An override replaces the effective list; it does not append to shared. An empty override is normalized away on Save, so it does not suppress a shared word. Removing an override restores inheritance. Editing an effective word in Flashcards writes to the actual source: that piece override if present, otherwise shared.

Persisted domain records use physical sticker IDs and tokens. The adapter derives the visible shared/override model: identical edge/corner lists collapse to Shared; differing lists use the edge list as Shared with a corner override; old single-vocabulary data with one physical record can display it as Shared. New edits use the hidden `pairSharing: separate` discriminator. This discriminator is not a current setting. Thus the visible scope tabs are not a promise that storage contains a separate shared record.

Saving normalizes words by trimming, removing empties and case-insensitive duplicates while preserving first occurrence/order. Shared values may collapse visually even when represented by two physical records. Custom or duplicate sticker labels do not make physical piece identities interchangeable. Existing adapter behavior is authoritative; do not redesign storage in prototype code.

## Letter Pairs browser

Users browse one first token at a time using the First letter rail. Token axes derive from the active scheme and Shared/Edges/Corners scope. Same-token diagonal combinations are disabled as 'not a pair'. Each first-token item shows filled count out of possible second tokens excluding the diagonal; page heading repeats current count. Empty database reads No mnemonics yet; empty rows remain editable. Groups show primary, alternates/override hints, inherited state, and usage count where applicable.

There is **no full-text search field, 'missing only' filter, CSV import or bulk auto-fill**. Browsing/filtering consists of first-token selection, scope tabs and keyboard token jump. Arrow up/down moves rows; left/right moves groups of four; Home/End move to ends; `[`/`]` and PageUp/PageDown cycle first token; typing tokens jumps to the first token/pair; Enter edits. Custom multi-character tokens use greedy longest-match tokenization. Focus returns to the browser after closing the editor.

Clear first-token section is shown when any entries with that first token exist. Its confirmation removes **all words/alternates/edge/corner overrides for that first token**, regardless of selected vocabulary tab. It is not just 'clear displayed scope'. Clear all pairs is under Settings/Data, with a separate count-bearing confirmation.

## Pair inspector

Header shows the pair and Used in N solves / Not used in a solve yet. This usage value is backed by aggregated encounter counters and should not be reinterpreted as a verified distinct-solve count by new logic. Scope tabs Shared/Edges/Corners are inside the editor; override tabs are marked.

Shared or an explicit override offers a primary Mnemonic input, Remove primary, Alternates list, Add alternate input and opt-in Suggest words. Suggestions support More and choosing a suggested word; they are not saved until Save. Alternate input commits into the draft on Enter or blur. Clicking an alternate makes it primary. Removing primary promotes the first alternate with a status notice; alternate removal is independent.

An inheriting piece tab says Uses shared and displays its primary or Nothing yet. Different word for edges/corners begins an empty override draft; Use shared instead removes it. Save commits normalized content, Cancel/Close/Escape abandons draft. Enter from primary saves. Clear in a new draft clears draft words; Clear pair for an existing entry asks and removes every scope and alternate. An entirely empty saved entry is removed.

Responsive: first-token rail is vertical from `md`, horizontal and scrollable below it. Pair groups adapt columns. Inspector is a 480px right panel on desktop and a full-width bottom sheet capped at 92dvh on phones; body scroll and footer actions remain distinct. Current list/rail geometry is reference only.

## Flashcards eligibility and randomness

One internal card is **one pair in one piece context**. Both tokens must exist in that piece's own current lettering, differ from each other, and resolve to a nonempty effective mnemonic. A shared pair can yield both an Edge and a Corner variant. Selection is uniform random over eligible variants; Forgot does not weight it. When more than one variant exists, the immediate previous variant is excluded from the next draw. The same letter pair can still recur next in the other piece context.

User-visible eligible count deduplicates by pair plus normalized complete effective word list. Therefore identical shared edge/corner answers can display **1 card** while both physical variants remain in the sampling pool. Different override answers count separately. The header's next ordinal is recent history count +1, not a finite deck progress meter. There is no user-facing scope selector: initializer `scope` is screen-seeding context only.

## Flashcards interaction

| State | Visible content | Actions |
|---|---|---|
| Empty | No pairs yet, Add your first mnemonic | Go to Letter Pairs |
| Question | Pair tokens, Edge/Corner label, hidden word placeholder | Reveal; Space/Enter |
| Revealed | Primary plus alternates | Remembered, Forgot, Edit, Add alternate |
| Editing | Primary word input, Save/Cancel | Save/Enter updates source list; Escape cancels |
| Adding | Current primary plus alternate input, Save/Cancel | Save adds nonduplicate alternate; blank returns without change |

Remembered uses Enter or Space outside focused button behavior; Forgot uses F; Edit E; Add alternate A. Holding a key never repeatedly reveals/records/cards through the deck. A card must have been visible ~220ms before an answer is accepted. Text fields and dialogs suppress global card shortcuts; editing disables answer buttons. Each accepted self-report records a saved flashcard attempt and encounter/forgotten counters, then selects another question.

Wide layout includes a piece-location cube, stats (cards seen, remembered, forgot) and at most 200 most recent saved flashcard entries. The cube is not the physical cube to solve; it illustrates where tokens sit. Recent rows show pair, effective primary and self-reported outcome; selecting one reopens that pair revealed. Row delete removes that record immediately. Backspace/Delete asks to remove latest; Shift+Backspace/Delete or Clear asks to clear flashcard history. Removing history does not erase pair words or reverse already accumulated encounter counters. Main-source IDs are record IDs, replacing the older timestamp-based deletion.

Below `lg`, the cube/stats/recent-history aside is hidden and no mobile history alternative currently exists. Revealed/edit controls wrap on narrow screens. Long words can break/wrap; alternates and list content may truncate. A removed or newly ineligible current card is replaced unless the user is in an edit/add state. No spaced repetition, review due dates, mastery percentages, completion screen, pause button, or separate 'Next' that avoids a remembered/forgot report exists.

---

<!-- Source section: 06_SETTINGS.md -->

# Exhaustive current Settings inventory

Sources: `pages/Settings.tsx`, `types/app.ts`, `components/settings/*`, `utils/{methodBuffers,view,scheme}.ts`, `contexts/AppDataContext.tsx`, `lib/repository.ts` defaults/schema. This table enumerates every persisted user-editable configuration exposed by current Settings. Account, backup and support actions follow it; they are not configuration preferences.

| ID | Setting / purpose | Control / allowed values | New-workspace default | Save, dependencies, disabled/hidden, effects |
|---|---|---|---|---|
| SET-01 | Sticker lettering: labels for each directed edge/corner sticker | Select sticker on rotatable cube; Token input; up to 3 characters, uppercase, whitespace removed; blank permitted | Speffz A–X separately for edges and corners | Draft; explicit Save. Centers not label targets. Duplicate same-piece labels produce 'Also on …' information, not a hard validation error. Empty reads Unlabelled. Affects every token-based cube/memo/pair/drill surface. Previous/Next sticker; Enter/Tab advances, Shift+Tab reverses |
| SET-02 | Scheme name | Text input, placeholder Custom | Speffz | Draft; shown only when current scheme differs from Speffz. Does not rename physical stickers or move existing raw records |
| SET-03 | Restore Speffz labeling | Use Speffz button plus overwrite confirmation | Already Speffz | Disabled if already Speffz. Overwrites custom tokens in draft; pair records are kept. Confirmation explains this. Explicit Save persists |
| SET-04 | Physical edge buffer | Edge-buffer mode, selectable edge sticker on cube; Common shortcuts UF, DF, UR, UB | `D:DF` | Draft physical directed sticker, not just a letter. Recommendation OP usually UL may offer Use UL when applicable; M2 recommendation does not use the same fixed shortcut because orientation matters. Buffer affects raw trace and compatible M2 method frame |
| SET-05 | Physical corner buffer | Corner-buffer mode, selectable corner sticker; Common UFR, UBL, UFL, DFR | `L:UBL` | Draft. OP commonly UBL; recommendation can offer conventional selection. Piece text ordering may render LUB. Sticker direction matters beyond the unordered piece name |
| SET-06 | Default Cube View top | Top face color radiogroup: White, Yellow, Green, Blue, Red, Orange | White | Draft. When top changes, front is retained only if adjacent; otherwise adjusted to a valid front. Presentation orientation affects cube rendering, not scramble reference, raw trace or saved physical buffer |
| SET-07 | Default Cube View front | Front face colors from same six; only four adjacent to top enabled | Green | Draft. Same/opposite color disabled. Applies saved display orientation throughout cubes. Combined top/front must be one of 24 legal orientations |
| SET-08 | Adopt/reset rotated Cube View | Drag cube, Use this view, Reset; Back to white top, green front | Standard orientation | Use this view disabled until a valid manual rotation differs from saved draft; adopts view and resets temporary angle. Reset shown while rotated. Standard-view reset shown only when nonstandard |
| SET-09 | Edge method | RadioRows OP or M2 | M2 | Draft. Changing method selects conventional physical edge buffer relative to current draft Cube View once: OP method UL, M2 method DF. Later view changes alone do not remap the buffer. Legacy unsupported values remain stored until a supported choice is saved; active view falls back to OP |
| SET-10 | Corner method | RadioRows OP only | OP | Draft. No 3-style or other selectable methods. Legacy unsupported stored values have active OP view fallback |
| SET-11 | Automatically swap M2 targets | Toggle on/off | Off | Immediate persistence, outside draft Save. Visible/enabled even with OP; semantic effect requires compatible M2 configuration. Applies execution representation in Execution Sprint/Guided Solve/Timer reconstruction; raw Trace Sprint/Memo Recall unchanged |
| SET-12 | Memo order | Corners first / Edges first radio rows | Corners first | Immediate. Orders both-piece training groups and reconstruction, and current history memo presentation. Does not reverse target order inside a piece or rewrite raw physical states |
| SET-13 | Show live timer | Toggle on/off | On | Immediate. Masks active Timer total and numeric split with Solve; stopped values still visible. Does not hide Training timers |
| SET-14 | Multiphase timing | Toggle on/off | On | Immediate. Next Timer run starts memo then exec when on; one running phase when off. Saved solve multiphase flag determines whether historical memo split appears |

## Configurator and draft lifecycle

Configurator modes are **Overview**, **Lettering**, **Edge buffer**, **Corner buffer**, **Cube view**. Overview summarizes scheme, buffers and view, with Change actions. Modes and sticker selection are local editing controls, not persisted settings. Switching modes does not commit the draft. Cube can rotate in configurator. Colors are the fixed reference scheme; this is not a customizable sticker-paint palette.

Setup fields (labels/name, buffers, methods) and default view are staged together. When different, an Unsaved changes region offers Discard/Save. Dirty comparison waits for owner workspace hydration. Account transitions reset the draft only after the new owner is ready, preventing edits leaking across accounts. Loading reads Loading account settings….

App-bar navigation with a dirty draft opens Save setup changes?: Stay, Discard, Save and leave. This guard covers registered app navigation, not every possible browser action. Save invokes local-first updates; cloud sync is separate. Saving state prevents repeated submissions. Code contains a preview-triggered 'Couldn’t save — nothing was lost'/Retry branch, but `useScreenInit` supplies no public trigger. Do not promise this preview branch is a fully implemented generic network-save error display.

Important distinction: immediate preferences can persist even when a user later Discards draft setup changes. Do not bundle them into a single global unsaved transaction in a prototype without an explicit behavior decision.

## Account & sync

See 07. WCA/Google sign-in, account identity, Synced/Saving/Offline/Sync failed/Retry, sign out and migration choices. No account button in the current global shell. No email/password, profile fields, delete-account, or notification settings.

## Data

- **Export backup** downloads version-3 BlindSolve JSON including setup/lettering, pairs, solves, sessions/preferences and practice history. Filename `3bld-backup-YYYY-MM-DD.json`; status Backup saved to downloads.
- **Import…** accepts JSON. Reads/validates before any update, limits files to 25 MB, and handles invalid JSON/schema. Valid preview shows filename/date, lettering, buffers, total/new/differing pairs, alternates, solve count, practice count.
- Import strategies: **Merge, keep mine where they differ** (default), **Merge, use the backup where they differ**, **Replace everything with the backup**. Primary confirmation label changes to Replace my data for replacement. Cancel applies nothing. Use real parser/merge implementation; differing words can be preserved as alternates under its rules.
- Invalid preview: Can’t import this file, filename, This isn’t a backup from this app, problems, Close / Choose another file. There is a keyboard-focus-only Preview a sample backup action; it previews current data, not an actual foreign file import.
- In the disposable audit workspace, Preview a sample backup rejected its own current data with `Invalid timing split` for one synthetic Timer solve. The parser requires exact integer `totalMs === memoMs + executionMs`; Timer currently rounds those values independently. This is an observed integration caveat, not an imported-file feature and not repaired in this task. Screenshot 48 records the actual rejection.
- **Clear all letter pairs** is disabled when database empty. Otherwise confirmation names entry count and removal of all words, alternates and overrides, with Cancel/Clear all. Afterwards All letter pairs cleared. Does not clear Timer solves or practice history.

## Support and first-use access

Give feedback opens the feedback sheet; admin accounts additionally see Feedback inbox with new-item count and Open inbox. Desktop settings section rail includes Run first-use setup. It is currently hidden on mobile; direct `/setup` remains valid. Section destinations remain required even if their new composition changes completely.

## Settings deliberately absent / legacy only

No pair-sharing strategy selector; no manual M2 orientation; no parity instructions toggle; no flipped-edge/twisted-corner convention selector; no 3-style; no timer hardware settings; no inspection/WCA countdown setting; no color-scheme editor beyond Cube View; no theme/dark mode/language/sound/hold-duration controls. `pairSharing`, flipped/twisted strategy fields and retired method enum values in persistence do not establish visible settings. Preview initializers are not actual preferences.

---

<!-- Source section: 07_AUTH_AND_ACCOUNT.md -->

# Authentication, account, synchronization and feedback

Sources: `pages/SignIn.tsx`, `hooks/useSignInFlow.ts`, `components/auth/*`, `components/settings/AccountSection.tsx`, `app/Store.tsx`, `lib/{supabase,repository,cloudLock,feedback}.ts`, `pages/FeedbackInbox.tsx`, `components/feedback/*`, `types/feedback.ts`.

## Guest and sign-in

Guests can use all normal practice routes. Data stays in a device guest workspace until explicit account migration. Production Settings offers Continue with WCA and Continue with Google. An unconfigured local deployment instead says Local and explains sign-in is unavailable and data stays on the device. Standalone `/signin` still has provider buttons but cannot authenticate without configuration.

There are no password/registration forms. First successful provider sign-in creates the account via existing backend behavior. WCA launches the server-side WCA OAuth function; Google uses Supabase OAuth with return to origin. Secret-bearing WCA exchange belongs on the server. A pending provider shows its progress and disables provider actions; standalone SignIn exposes Cancel and Continue without signing in.

WCA callback consumes a token hash and strips it from the URL before verifying; auth errors are also consumed from the query. The flow records error strings, but **the current SignIn and signed-out AccountSection do not render `flow.error`**. Do not invent a tested visible OAuth error banner in the inventory. This is a current UI gap to solve during later integration. Provider return, fresh account creation, authenticated cloud behavior and account-to-account switching were inspected in source/tests, not completed against a live user account in this audit.

## Existing device data

When sign-in encounters meaningful guest data, a migration dialog shows pair and solve counts. Choices: Merge into my account; Use my account’s data. Continue confirms current choice. Continue with account data (also cancel path) chooses account data. Guest data is retained until migration/sync handling makes it safe to clear.

Current dialog helper copy says differing pairs will be asked about and that account-only choice keeps a backup file. The actual Store merges differing mnemonic values as alternates and preserves a guest device copy; it does not implement a per-conflict question wizard or an automatic downloaded backup in `resolveGuestMigration`. Treat those helper claims as copy/implementation mismatches, not capabilities for Magic Patterns to invent.

## Signed-in account panel

Shows initials, full name, WCA ID or email, provider label/mark and Sign out. It is a Settings section, not a profile menu. Sign out asks confirmation; the callback invokes real Supabase sign-out and ownership transition. Account data remains in its owner-isolated device cache; returning to guest must not display or upload another account's workspace. No account-delete or credential-management UI exists.

| Actual store-derived state | User-visible account treatment |
|---|---|
| ready false | Settings content replaced by Loading account settings… |
| saved → idle | Synced · last tried time, or not yet attempted |
| saving/loading → saving | Saving spinner/status |
| offline | Offline — changes are kept here and sync when you reconnect |
| error → failed | Sync failed, last tried, Retry; detailed syncMessage rendered as alert |
| guest local | Provider invitation rather than signed-in sync status |
| no Supabase config | Local explanation, no account sign-in controls in Settings |

`SyncStatus` includes conflict and AccountSection has '3 pairs changed on another device' / Keep this device’s markup. The real Store does **not emit a conflict state**; conflicts are merged as alternates and surfaced through store messages. `setAccount` is not a general conflict resolver. Do not turn that dormant literal example into a live fixed-count conflict workflow. Likewise not every `store.notify` message is visibly rendered in the current shell; failed-sync details have an actual outlet, arbitrary success notices do not.

Local persistence is immediate; cloud updates are batched/retried. Owner epochs, per-account locks, cross-tab merge, pending record changes, revision conflicts and RLS remain existing implementation responsibilities. UI must show truthful status and retry without bypassing them or treating a green badge as proof of account isolation.

## User feedback surface

Available from Settings/Support. Types: Bug, Feature request, General feedback. Nonblank Message required; Send disabled until entered. Signed-out users may provide optional email. Signed-in identity is attached automatically; optional guest email control is omitted. Bug reports offer one screenshot (add, preview/name, remove) and 'What’s included' technical disclosure: source page, drill/scope if relevant, build, browser, OS/device and viewport. Training answers and mnemonic text are deliberately excluded from automatic context. Feature/general do not send bug screenshot/context.

States: idle, Sending, failed retaining draft and attachment with Try again, and sent confirmation that auto-closes after about 1.8 seconds. Cannot close during Sending. Closing an unsent draft does not immediately reset it; sent closure resets it. Duplicate send is guarded. Attachment validation/security limits are enforced by `lib/feedback.ts` and server; UI only advertises image selection, not an invented upload gallery. Actual sending was not performed during this audit.

## Admin feedback

Admin role comes from a database check, never email/name/local UI state. Signed-out users do not probe admin-only RPC. Non-admin `/admin/feedback` navigates to Settings. Frontend hiding is not authorization; server/RLS must enforce access.

Inbox: counts new records; type All/Bugs/Feature requests/General; status Open (not archived), New, Reviewing, Planned, Resolved, Archived, Everything; text search across message/contact/user name/detail/source. Empty database says No feedback yet; no matches varies by search/type/status. List adapts between wide rows and narrower composition, with category/status/source/date/user information.

Selecting a record opens an inspector showing message, screenshot link, identity/contact/source/time, technical details and private admin note. Status changes apply immediately among New/Reviewing/Planned/Resolved/Archived. Private note uses Save note/Cancel only when dirty. Archive updates status and closes; archived item offers Restore → New. Delete permanently has its own irreversible confirmation. These admin mutation branches are source-audited only; no real user feedback was loaded, edited or deleted.

There is no dedicated admin feedback loading/retry/error UI wired in the inbox component. Do not present a generic production success toast or error workflow for these mutations without integration work. Preserve the access rules, forms, statuses and actions while allowing every shell/panel layout to change.

---

<!-- Source section: 08_RESPONSIVE_BEHAVIOR.md -->

# Responsive behavior and measured evidence

The live five primary routes were captured at **1440×900, 1280×720, 1024×768, 900×560, 390×844, 320×568**. Browser `innerWidth/innerHeight` and document scroll width were measured, not inferred from screenshot filenames. All 30 primary-route measurements had document scroll width equal to viewport width. This does not prove every inner element, dialog or horizontal rail fits; those have their own overflow behavior.

## Layout transitions

| Range / measurement | Current composition and consequences |
|---|---|
| 1440×900 | Timer two columns with cube/history; Training aside visible (`xl`); Flashcards cube/history visible (`lg`); Settings section rail plus editor |
| 1280×720 | Same key sidebars as wide desktop, with smaller clamped cubes and vertical stage; short viewport reduces free space |
| 1024×768 | Timer/Flashcards still have reference sidebars; Training aside hidden below `xl`; Settings configurator uses its `lg` split |
| 900×560 | Timer still uses desktop columns. Training aside hidden. Flashcards aside hidden below `lg`. Settings configurator stacks below `lg`. Reconstruction remains a wide right overlay with internal scroll |
| 390×844 | App nav labels shorten; shortcut icon hidden; Timer reference cube hidden and history occupies lower ~32dvh row; Training Drill becomes select; no Training history aside; Flashcards aside hidden; Settings section links and configurator modes are separate horizontal rails |
| 320×568 | Same mobile transitions with much less room: Training header can become multiple control rows, scramble wraps several lines, and stage is small. Settings first viewport is largely taken by tabs and cube, with actual form controls below scroll. Dialogs use full width |

Actual Tailwind breakpoints in this baseline: sm 640, md 768, lg 1024, xl 1280. `short:hidden` occurs in Timer markup but no short variant is configured; do not infer a working max-height breakpoint from that token. Trace Sprint also uses measured stage width/height, not viewport width alone.

## Scroll, cubes, dialogs and forms

- App shells use `100dvh`, overflow-hidden outer containers, and internal scroll. Timer history, Settings main, inspector bodies, review bodies, vocabulary lists and practice stages have separate scroll regions.
- Timer desktop cube area is clamped by available width/height; displayed cube size roughly 120–272px. No mobile cube block. Timer readout uses viewport-responsive font clamps.
- Reconstruction/dialog top has result/splits beside a cube; body scrolls; Save/Continue/Skip footer remains separate. At 390px the result side is visibly narrow because cube column still claims substantial width. At 320px numbers/penalty control pressure needs attention. No claim that all target options fit without horizontal/inner scrolling.
- Settings configurator cube fits its content column in the captured mobile overview, but its fixed 340px mobile stage plus nested controls consumes most of 568px height. Section tabs and cube-mode tabs scroll horizontally, hiding destinations beyond the initial rail position. Forms remain below; page scroll is essential.
- Letter Pairs first-token navigation changes from vertical rail to horizontal scroll. Main rows scroll independently; inspector footer stays accessible. Long content and suggestions may require body scroll.
- Flashcards large pair/word content is scrollable; revealed actions wrap. At 320px action area occupies multiple rows; cube, stats and recent history are not available through an alternate mobile surface.
- Training active footer remains outside scrolling stage. Trace cube pair stacks above answers when stage dimensions are small; Memo Recall inline cube precedes content on phones. Reviews use full viewport width with scrollable contents. A software keyboard may further reduce space; no physical-phone keyboard test was available.
- Setup puts cube and form side by side from `lg`; otherwise the form is below with max ~58dvh and scroll. Bottom Back/Continue remain outside form scroll. Sign-in centers provider controls with guest exit in its header.
- Shared Sheet and Inspector bound their scrolling regions and include keyboard/focus behavior. Inspector becomes a bottom sheet below `md`, full width with maximum 92dvh, while reconstruction/details remain full-height right overlays. ConfirmDialog constrains width but has no explicit maximum height/internal overflow rule: the valid backup preview at 320×568 measured top −6.5 and bottom 574.5, extending beyond both viewport edges. Custom reconstruction/details panels do not use all the same shared focus-trap hooks. Their accessibility deserves a separate redesign validation rather than assuming `aria-modal` alone solves focus.

## Current weaknesses a redesign should address

These are observations, not a proposed layout. Training and Flashcard history lose practical mobile access because entire asides are hidden. Timer hides its cube on mobile. Repeated global, section, configurator, drill, scramble and footer bands consume vertical space; Settings has horizontal navigation nested inside another horizontal navigation. Reconstruction places a large cube beside a narrow result column on phones. Small muted controls, low-salience scroll affordances, and multiple independently scrolling regions make discovery harder. Lack of page-level overflow does not establish an efficient composition.

Captures include mobile reconstruction, pair editor, feedback, solve details, backup import preview, Guided Solve report/review, Trace Sprint and Flashcard editing. Some 390×844 browser captures returned a 390×843 JPEG raster; names retain the actual measured 390×844 viewport, with raster dimensions separately recorded in the screenshot manifest. Not every possible setting/word length was tested at every size. Authenticated/admin visual states were not available. Real iOS/Android touch behavior, keyboard occlusion, screen reader use, zoom and physical hardware were not verified. The six-size audit is browser layout evidence, not device certification.

---

<!-- Source section: 09_CURRENT_UI_CRITIQUE.md -->

# Factual critique of current presentation

This critique grants no authority to change production functionality. It identifies current presentation costs so that screenshots do not accidentally become a visual specification. No aesthetic direction is prescribed.

1. **Stacked horizontal structures compete for attention.** Global app bar, drill/settings controls, scramble band, stage boundary and action dock repeat the same horizontal division. Settings adds section rail, configurator tabs and a bordered cube/editor region. At 320×568, controls and scramble consume a large fraction of the screen before practice content. The navigation architecture should be rethought from first principles.
2. **The same side-column pattern hides different capabilities.** Timer keeps mobile solve history in a lower strip, but Training hides its aside below 1280px and Flashcards hides it below 1024px. This removes on-screen history/stats access for otherwise valid tablet/phone workflows. There is no visible equivalent drawer in those pages.
3. **Responsive reconstruction preserves desktop geometry too literally.** In the captured 390px cycle-break screen, the result occupies a narrow left column while the cube occupies most of the header. Total and splits feel compressed despite available space elsewhere. At short desktop height, header/footer and progress bands squeeze the actual question.
4. **Settings spends space on the illustration before the edit.** Mobile first viewport prominently shows the cube and mode tabs; current setting details and Change controls require further scroll. Additional horizontal mode items are hidden to the side. Multiple nav levels lack a strong distinction in role.
5. **Hierarchy relies heavily on faint type and hairlines.** Small labels, dimmed controls, empty dashes and repeated thin rules compete rather than clearly explaining what's primary, contextual or unavailable. Active practice fades global controls; opacity does not by itself communicate whether they are disabled.
6. **Some empty states reserve a large unused reference area.** Desktop empty Flashcards displays a large blank cube/reference region above zero statistics and empty history while the main prompt is sparse. Density is uneven across the same screen.
7. **Terminology and data promises sometimes diverge.** Pair 'Used in N solves' comes from encounter counters; migration copy implies per-conflict questions/downloaded backup while actual logic preserves alternates/device guest data. Dormant fixed '3 pairs changed' markup is not a live conflict system. These should not become invented redesign features.
8. **Error coverage is inconsistent.** Timer scramble failures and feedback send failures have actual visible treatment. OAuth errors exist in state without a rendered outlet, and admin mutations lack a dedicated error/retry presentation. A polished prototype should not imply these integrations already exist.
9. **Discoverability differs by input/device.** Keyboard help icon disappears on phones, first-use setup link is desktop-only, and mnemonic editing/extra actions can be visually subtle. Keyboard shortcuts are extensive but not a substitute for touch-accessible actions.
10. **Repeated container boundaries add cognitive grouping without always adding meaning.** Some rules delineate meaningful phase/data boundaries; others simply repeat shell structure. The handoff preserves the meaning and accessible actions, not the number of bars, cards, borders or panels.

The designer is free to eliminate or replace the present app bar, current secondary navigation, tab rows, sidebars, cards, inspector sheets and repeated headers. Preserve capability, not current presentation. This is an objective functional handoff, not the final design prompt.

---

<!-- Source section: 10_FUNCTIONAL_UI_CONTRACT.md -->

# Master functional UI contract

**278 independently checkable entries.** Baseline: `2eeab8872d3a8106a0ef0b711b8108407e85c887`.

Each row is a capability/state/action to account for when reviewing the future prototype. Presentation may change for every row; semantic preservation is fixed. Rows explicitly marked as limitations describe current boundaries, not a demand to keep a defect. Any future behavioral repair needs an explicit integration decision. Detailed defaults/dependencies are in the Settings inventory; domain meanings are in the focused documents.

The CSV contains identical rows and adds source locations. Source paths are under `src/` (usually `src/magic/`) in the audited main commit. All supported routes and redirect handlers are included; preview-only concepts and retired modes are excluded.

## NAV: global

Source: `magic/App.tsx; components/layout/AppBar.tsx; contexts/SessionWorkspaceContext.tsx`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| NAV-01 | global | Primary destinations | any main screen | Timer/Pairs/Cards/Training destinations | Follow a primary link | Reach corresponding URL with selected-route state | Yes | Yes |
| NAV-02 | global | Settings destination | main screens | Settings control | Open Settings | Access all six settings sections | Yes | Yes |
| NAV-03 | global | Mobile navigation | narrow viewport | Short labels for all four destinations | Select destination | All primary destinations remain reachable | Yes | Yes |
| NAV-04 | global | Keyboard help | desktop or keyboard | Shortcut sheet | Open help or press ? | Show actual page-aware shortcuts; Escape closes | Yes | Yes |
| NAV-05 | global | Route identity | direct URL | Route-specific screen and title | Open deep link | Render matching screen without requiring prior navigation | Yes | Yes |
| NAV-06 | global | Legacy memo | /memo | Redirect | Open old URL | Reach /training; no fifth drill | Yes | Yes |
| NAV-07 | global | Retired About | /about | Redirect | Open old URL | Reach /; no About screen required | Yes | Yes |
| NAV-08 | global | Unknown destination | unmatched URL | Not-found message and Timer link | Return to Timer | Recover to / | Yes | Yes |
| NAV-09 | global | Timer workspace lifetime | navigating within SPA | Existing scramble/clock/draft | Leave and return | Retain controller state; no duplicate solve | Yes | Yes |
| NAV-10 | global | Training workspace lifetime | navigating within SPA | Per-drill challenge/phase | Leave and return | Retain current attempt; shortcuts route-scoped | Yes | Yes |
| NAV-11 | global | Saved-history lifetime | reload/hydration | Saved solves/cards/attempts | Reopen app/account | Restore saved records independently of active workspace | Yes | Yes |
| NAV-12 | global | Accessibility | all interactive states | Names/roles/focus/disabled status | Keyboard or touch use | Reach real actions; text entry does not trigger global actions | Yes | Yes |
| NAV-13 | global | Reduced motion | system preference | Same controls and data | Use reduced motion | Meaning unchanged with reduced animation | Yes | Yes |
| NAV-14 | global | Runtime failure | uncaught render error | Error screen and reload | Reload application | Re-enter app without intentionally modifying saved data | Yes | Yes |
| NAV-15 | global | Metadata | route changes | Route title/canonical/indexing | Navigate | Preserve supported deep links and private-route noindex semantics | Yes | Yes |

## TMR: /

Source: `hooks/useTimer.ts; hooks/useTimerSession.ts; components/concepts/workspace/WorkspaceTimer.tsx`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| TMR-01 | / | Initial scramble | pending | Preparing scramble | Wait | New scramble and timing remain unavailable until ready | Yes | Yes |
| TMR-02 | / | New scramble | idle/stopped | Current sequence | Click New scramble or N | Request legal replacement; update exact cube state | Yes | Yes |
| TMR-03 | / | Request ordering | overlapping generation | Latest pending state | Receive delayed responses | Only latest request changes scramble/error/pending | Yes | Yes |
| TMR-04 | / | Initial generation failure | no scramble | Scramble unavailable | Retry New scramble | Keep timing unavailable until valid sequence | Yes | Yes |
| TMR-05 | / | Replacement failure | prior scramble exists | Prior sequence and New scramble failed | Retry | Preserve prior sequence and solve records | Yes | Yes |
| TMR-06 | / | Scramble reference | ready | Sequence and mathematical cube | Apply physically | Interpret in fixed white-top/green-front frame | Yes | Yes |
| TMR-07 | / | Cube rotation | desktop cube | Current scramble state | Drag cube | Change display angle only | Yes | Yes |
| TMR-08 | / | Sticker letters | cube available | Optional current scheme labels | Toggle Sticker letters | Same physical state with optional labeling | Yes | Yes |
| TMR-09 | / | Cube view reset | new state/saved view | Reset angle | Generate scramble/change view | Remove temporary rotation without changing mathematics | Yes | Yes |
| TMR-10 | / | Resting clock | idle | 0.00 | Press and hold timing input | Arm without saving solve | Yes | Yes |
| TMR-11 | / | Short hold | armed | Hold feedback | Release before threshold | Return to prior rest state without starting | Yes | Yes |
| TMR-12 | / | Ready hold | ready after ~280ms | Ready feedback and zero | Release | Start monotonic measurement | Yes | Yes |
| TMR-13 | / | Multiphase start | preference on | Memo active | Release ready input | Begin memo phase and total together | Yes | Yes |
| TMR-14 | / | Single-phase start | preference off | Single running clock | Release ready input | No memo split phase | Yes | Yes |
| TMR-15 | / | Memo transition | memo | Total and active memo | Space/pointer down | Freeze memo split; continue total into exec | Yes | Yes |
| TMR-16 | / | Stop execution | exec | Total and frozen memo | Space/pointer down | Stop total and create pending solve once | Yes | Yes |
| TMR-17 | / | Stop single phase | running | Total | Space/pointer down | Stop without introducing memo split | Yes | Yes |
| TMR-18 | / | Live clock on | active | Numeric total and allowed split | Wait | Display elapsed time without changing timing source | Yes | Yes |
| TMR-19 | / | Live clock off | active | Solve; phase without active numeric split | Continue timing | Hide live values; retain accurate internal measurement | Yes | Yes |
| TMR-20 | / | Stopped clock visibility | just stopped | Final total and optional split | Review result | Show numeric result even if live clock was hidden | Yes | Yes |
| TMR-21 | / | Input safety | key held/text entry | Existing focused control | Repeat Space/type | No duplicate stop/start; no text-field timing | Yes | Yes |
| TMR-22 | / | Pending result | post-stop | Recorded result | Wait ~520ms | Open reconstruction on same pending solve | Yes | Yes |
| TMR-23 | / | Result OK | reconstruction/details | Raw total | Choose OK or 1 | Clear penalty while retaining raw time | Yes | Yes |
| TMR-24 | / | Result +2 | reconstruction/details | Effective total and penalty | Choose +2 or 2 | Add 2000ms to effective total only | Yes | Yes |
| TMR-25 | / | Result DNF | reconstruction/details | DNF and recorded duration context | Choose DNF or 3 | Preserve raw duration and result distinction | Yes | Yes |
| TMR-26 | / | New-scramble lock | active/generating | Disabled control | Attempt regeneration | Active scramble cannot change via New scramble | Yes | Yes |
| TMR-27 | / | Overlay timing lock | draft/details/help/sessions open | Current overlay | Press Space | Do not arm background Timer | Yes | Yes |
| TMR-28 | / | Navigation while timing | active then away | Retained Timer state | Return to Timer | Clock/controller not recreated by page presentation | Yes | Yes |

## REC: / (reconstruction)

Source: `hooks/useReconstruction.ts; useTimerSession.ts; domain/bld/trace.ts; memoConventions.ts; components/reconstruction/*`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| REC-01 | / (reconstruction) | Initial reconstruction | open | Result/splits/initial cube | Inspect | Use stopped scramble and scheme snapshot | Yes | Yes |
| REC-02 | / (reconstruction) | Cube interpretation | any reconstruction step | Cube at start of memo | Rotate/display | Do not present target progression as face-turn playback | Yes | Yes |
| REC-03 | / (reconstruction) | Pending corner cycle | engine requests break | Corner sequence with pending slot | Choose valid sticker | Add physical corner break and retrace | Yes | Yes |
| REC-04 | / (reconstruction) | Pending edge cycle | engine requests break | Edge sequence with pending slot | Choose valid sticker | Add physical edge break and retrace | Yes | Yes |
| REC-05 | / (reconstruction) | Candidate buttons | break step | Valid labels | Click candidate | Commit physical candidate represented by label | Yes | Yes |
| REC-06 | / (reconstruction) | Cube candidate | break step | Highlighted valid stickers | Click highlighted sticker | Invoke same break selection authority | Yes | Yes |
| REC-07 | / (reconstruction) | Keyboard candidate focus | break step | Focused option | Arrow keys | Wrap focus among candidates without committing | Yes | Yes |
| REC-08 | / (reconstruction) | Keyboard candidate commit | break step | Focused candidate | Enter or matching token key | Select valid break and retrace | Yes | Yes |
| REC-09 | / (reconstruction) | Repeated cycles | further buffer returns | New valid candidates | Continue selecting | Preserve all physical choices in sequence | Yes | Yes |
| REC-10 | / (reconstruction) | Piece order | both pieces | Corners/Edges in preference order | Follow reconstruction | Preserve targets inside each section | Yes | Yes |
| REC-11 | / (reconstruction) | Raw versus M2 | compatible M2 + preference on | Execution representation | Inspect/choose | Raw IDs/tokens remain retained separately | Yes | Yes |
| REC-12 | / (reconstruction) | OP treatment | OP method | Raw-compatible sequence | Reconstruct | No M2 target swapping on OP | Yes | Yes |
| REC-13 | / (reconstruction) | Parity metadata | odd compatible M2 count | No required parity dialog | Save/inspect | Preserve internal parity without fabricated raw target | Yes | Yes |
| REC-14 | / (reconstruction) | Missing mnemonic | full pair without word | Pair/input/suggestion action | Enter word | Draft word for correct piece context | Yes | Yes |
| REC-15 | / (reconstruction) | Word suggestion | word stage | Suggested vocabulary | Request/pick suggestion | Opt-in draft update; no auto-filled saved record | Yes | Yes |
| REC-16 | / (reconstruction) | Skip word | word stage | Current sequence | Skip/Continue | Advance with blank allowed | Yes | Yes |
| REC-17 | / (reconstruction) | Duplicate word question | repeated same pair in one piece | One question | Advance | Avoid repeated missing-word questions for same piece/pair | Yes | Yes |
| REC-18 | / (reconstruction) | Trailing singleton | odd target length | Single target | Review | Do not invent a two-letter word slot | Yes | Yes |
| REC-19 | / (reconstruction) | Back | later word/review index | Prior step | Back | Return between indexed steps; not cycle-break undo | Yes | Yes |
| REC-20 | / (reconstruction) | Review memo | final review | Ordered pairs/words | Inspect | Retain distinction of edges/corners and historical used word | Yes | Yes |
| REC-21 | / (reconstruction) | Review inline edit | review | Existing/blank word | Edit and commit | Update draft used word only until finish | Yes | Yes |
| REC-22 | / (reconstruction) | Keep stored word | changed word | Stored and used values | Keep existing | Save solve word without changing database list | Yes | Yes |
| REC-23 | / (reconstruction) | Replace primary | changed word | Stored and used values | Use new word | Replace primary and retain later alternates | Yes | Yes |
| REC-24 | / (reconstruction) | Add alternate | changed word | Stored and used values | Add as alternate | Append case-insensitively new word | Yes | Yes |
| REC-25 | / (reconstruction) | New word summary | review | New words joining pairs | Save | Add nonempty new words to correct piece vocabulary | Yes | Yes |
| REC-26 | / (reconstruction) | Save reconstruction | review | Result/memo/choices | Save solve or Enter | Update pending solve; persist snapshots; close; new scramble | Yes | Yes |
| REC-27 | / (reconstruction) | Skip to save | unresolved/word step | Current partial trace | Skip to save | Finish immediately; no requirement to answer every question | Yes | Yes |
| REC-28 | / (reconstruction) | Escape save | any reconstruction step | Current draft | Escape | Same immediate finish path; not discard | Yes | Yes |
| REC-29 | / (reconstruction) | Partial skip caveat | pending break skipped | Partial targets/choices | Save immediately | Reflect actual partial data; do not claim full inferred human memo | Yes | Yes |
| REC-30 | / (reconstruction) | Historical snapshot | completed solve | Used words and scheme/execution identities | Later change vocabulary/settings | Preserve what the solve recorded | Yes | Yes |

## HIS: / (history/sessions)

Source: `components/timer/SessionManager.tsx; hooks/useHistoryCleanup.tsx; AppDataContext.tsx; utils/time.ts; WorkspaceSolveDetails.tsx`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| HIS-01 | / (history/sessions) | Session list | chooser open | Names/counts/current selection | Open Sessions | Show all saved Timer sessions | Yes | Yes |
| HIS-02 | / (history/sessions) | Select session | chooser | Target session | Select | Switch active identity and displayed solves; close chooser | Yes | Yes |
| HIS-03 | / (history/sessions) | Create session | nonempty new name | New session input | Create/Enter | Persist new session and activate it | Yes | Yes |
| HIS-04 | / (history/sessions) | Rename session | rename draft | Name input | Blur/Enter | Persist nonblank trimmed name | Yes | Yes |
| HIS-05 | / (history/sessions) | Cancel rename | rename draft | Original session | Escape | Abandon draft rename | Yes | Yes |
| HIS-06 | / (history/sessions) | Delete session ask | any selected session | Name and solve count | Delete session | Ask even for empty session | Yes | Yes |
| HIS-07 | / (history/sessions) | Delete session confirm | confirmation | Irreversible scope | Confirm | Remove session and its solves; retain usable fallback | Yes | Yes |
| HIS-08 | / (history/sessions) | Session delete shortcut | Sessions open | Active session | Shift+Backspace/Delete | Ask to delete active session rather than clear list only | Yes | Yes |
| HIS-09 | / (history/sessions) | History empty | no solves | No solves in this session | Time a solve | Keep clear action disabled | Yes | Yes |
| HIS-10 | / (history/sessions) | History nonempty | active session | Newest-first number/time/result | Select row | Open corresponding details | Yes | Yes |
| HIS-11 | / (history/sessions) | Latest memo access | desktop rest | Latest result and memo | Select latest | Open same saved details | Yes | Yes |
| HIS-12 | / (history/sessions) | Best | session data | Best effective non-DNF | Change result/history | Recalculate from active session | Yes | Yes |
| HIS-13 | / (history/sessions) | Mo3 | at least three | Latest-three mean or DNF | Change result/history | DNF if any of latest three DNF | Yes | Yes |
| HIS-14 | / (history/sessions) | Success fraction | session data | Non-DNF/total | Change result/history | Count +2 as non-DNF | Yes | Yes |
| HIS-15 | / (history/sessions) | Details content | solve selected | Date/scramble/cube/time/splits/memo | Inspect | Display record snapshots, not rewritten current words | Yes | Yes |
| HIS-16 | / (history/sessions) | Current-word difference | stored word changed | Used word and now-current note | Inspect | Distinguish historical and current vocabulary | Yes | Yes |
| HIS-17 | / (history/sessions) | Details penalty | selected solve | OK/+2/DNF | Select result/1/2/3 | Persist penalty for exact record | Yes | Yes |
| HIS-18 | / (history/sessions) | Close details | selected solve | Close and scrim | Close/Escape/scrim | Return to same Timer workspace | Yes | Yes |
| HIS-19 | / (history/sessions) | Delete row/details | selected solve | Exact solve action | Delete | Remove exact record directly as current implementation | Yes | Yes |
| HIS-20 | / (history/sessions) | Delete latest ask | at rest/nonempty | Latest record confirmation | Backspace/Delete | Confirm before removal; ignore typing/dialogs | Yes | Yes |
| HIS-21 | / (history/sessions) | Clear history ask | at rest/nonempty | Active session count/scope | Clear or Shift+Backspace/Delete | Confirm all active-session solves | Yes | Yes |
| HIS-22 | / (history/sessions) | Cancel cleanup | confirmation | Existing history | Cancel | Leave records unchanged | Yes | Yes |

## TRN: /training

Source: `useTrainingSession.ts; SessionWorkspaceContext.tsx; components/training/*; utils/challengeTargets.ts`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| TRN-01 | /training | Mode list | idle | Four current drills in defined order | Select mode | Choose distinct retained workspace; no legacy Full Memo | Yes | Yes |
| TRN-02 | /training | Scope | idle | Both/Edges/Corners | Change scope | Share scope across drills and invalidate affected setup/inputs | Yes | Yes |
| TRN-03 | /training | Mode/scope lock | active/report/review | Disabled selector or clock replacement | Attempt setup change | Retain immutable active challenge | Yes | Yes |
| TRN-04 | /training | Hold start | idle ready | Hold feedback | Hold/release Space or surface | Start only after ready threshold | Yes | Yes |
| TRN-05 | /training | Hold cancel | armed | Same setup | Early release/pointer leave/cancel | Remain idle without record | Yes | Yes |
| TRN-06 | /training | Help | idle | Selected mode steps | How it works | Explain actual drill with close affordance | Yes | Yes |
| TRN-07 | /training | Preparing execution scramble | exec/guided setup | Preparing scramble | Wait | Keep hold/New scramble disabled until exact challenge ready | Yes | Yes |
| TRN-08 | /training | New execution scramble | idle ready | Current scramble/cube | N/New scramble | Replace exact frozen challenge only before run | Yes | Yes |
| TRN-09 | /training | History restore | app/account hydration | Saved mode attempts | Reopen Training | Include persisted records; no seeded-preview overwrite | Yes | Yes |
| TRN-10 | /training | Drill stats | wide aside | Counts/fraction/mode-specific mean | Complete attempt | Use memo/trace/exec/total duration appropriate to drill | Yes | Yes |
| TRN-11 | /training | Delete attempt | wide history row | Exact record | Delete row | Remove exact attempt directly | Yes | Yes |
| TRN-12 | /training | Delete latest attempt | idle/nonempty | Confirmation | Backspace/Delete | Delete most recent current-drill record after confirm | Yes | Yes |
| TRN-13 | /training | Clear attempts | idle/nonempty | Current drill count/scope | Clear/Shift+Backspace | Confirm and remove current drill only | Yes | Yes |
| TRN-14 | /training | Review navigation | no pending edit | Frozen result | Next/Enter/scrim | Return idle; no automatic run | Yes | Yes |
| TRN-15 | /training | Review pending edit | nonempty word drafts | Unsaved count/Save/Cancel | Save/Cancel | Resolve words before Next/scrim | Yes | Yes |
| TRN-16 | /training | Review edit keys | pending | Same draft | Enter/Escape | Save/cancel rather than advance attempt | Yes | Yes |
| TRN-17 | /training | Per-mode lifetime | SPA route/drill navigation | Distinct challenge seeds/controllers | Leave/return | Do not substitute one drill challenge for another | Yes | Yes |
| TRN-18 | /training | Raw target modes | recall/trace | Factual tokens | Study/type | Never grade against M2 execution-swapped targets | Yes | Yes |
| TRN-19 | /training | Execution target modes | exec/guided | Prepared execution tokens | Execute | Apply compatible M2 preference without losing raw targets | Yes | Yes |
| TRN-20 | /training | Input safety | focused input | Typed content | Space/repeated Enter | No global start/extra record from typing | Yes | Yes |
| TRN-21 | /training | Duplicate guard | submit/report bursts | One current challenge | Repeated click/keypress | Persist at most one attempt | Yes | Yes |
| TRN-22 | /training | Responsive actions | narrow/short | Reachable primary footer | Scroll stage | Do not lose Submit/Stop/Next below scrolling content | Yes | Yes |

## EXE: /training (Execution Sprint)

Source: `ExecutionWorkspace.tsx; review/ExecReview.tsx; useTrainingSession.ts`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| EXE-01 | /training (Execution Sprint) | Display setup | idle | Letters/Words option | Choose display | Change provided memo format only | Yes | Yes |
| EXE-02 | /training (Execution Sprint) | Physical setup | idle | Scramble and matching cube | Apply scramble then start | Same physical state used by memo | Yes | Yes |
| EXE-03 | /training (Execution Sprint) | Active letters | active Letters | Execution token sequence and elapsed | Execute physically | Keep memo visible; no answer typing | Yes | Yes |
| EXE-04 | /training (Execution Sprint) | Active words | active Words | Effective words or fallback letters | Execute physically | Never omit pairs lacking mnemonics or trailing singleton | Yes | Yes |
| EXE-05 | /training (Execution Sprint) | Stop | active | Clock and Stop | Space/Stop/stage pointer | Freeze execution time and save initial attempt once | Yes | Yes |
| EXE-06 | /training (Execution Sprint) | Self-report | review | Solved/DNF | Click or S/D | Update exact newly saved attempt, not another history entry | Yes | Yes |
| EXE-07 | /training (Execution Sprint) | Review content | review | Total/targets/pairs/per-target/scramble/cube/memo | Inspect | Preserve cycle-break markers and effective words | Yes | Yes |
| EXE-08 | /training (Execution Sprint) | Next | review | Next | Advance | Return idle with next scramble; no auto-start | Yes | Yes |

## GDE: /training (Guided Solve)

Source: `GuidedSolveWorkspace.tsx; review/GuidedSolveReview.tsx; useTrainingSession.ts; utils/guidedSolve.ts`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| GDE-01 | /training (Guided Solve) | Setup | idle | Exact scramble and piece scope | Hold/release | Start memo for same frozen physical challenge | Yes | Yes |
| GDE-02 | /training (Guided Solve) | Memo | memo | Generated execution letter pairs and memo clock | Memorize | Preserve preference section ordering | Yes | Yes |
| GDE-03 | /training (Guided Solve) | Start execution | memo | Start execution | Space/action | Hide memo and freeze memo split | Yes | Yes |
| GDE-04 | /training (Guided Solve) | Execution | execution | Solving plus elapsed clocks | Execute physically | Keep memo hidden; retain total across split | Yes | Yes |
| GDE-05 | /training (Guided Solve) | Stop | execution | Stop | Space/action | Freeze total; enter report without persisting yet | Yes | Yes |
| GDE-06 | /training (Guided Solve) | Report Solved | report | Did you solve the cube? | Solved/S | Persist one successful attempt with timings/snapshots | Yes | Yes |
| GDE-07 | /training (Guided Solve) | Report DNF | report | Same report prompt | DNF/D | Persist one unsuccessful attempt, not zero time | Yes | Yes |
| GDE-08 | /training (Guided Solve) | Review | review | Total/result/memo/execution/scope/scramble/sequences | Inspect/Next | Preserve self-report and return idle; no arbitrary result editor | Yes | Yes |

## RCL: /training (Memo Recall)

Source: `MemoRecallWorkspace.tsx; review/RecallReview.tsx; utils/training.ts`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| RCL-01 | /training (Memo Recall) | Idle secrecy | idle | Solved/reference cube, no challenge answer | Hold/release | Generate and reveal next raw challenge | Yes | Yes |
| RCL-02 | /training (Memo Recall) | Study | active | Raw grouped letters and matching cube | Memorize | Measure memo duration | Yes | Yes |
| RCL-03 | /training (Memo Recall) | Done studying | active | Ready | Space/Enter/Ready | Hide letters, dim cube, freeze memo; focus recall input | Yes | Yes |
| RCL-04 | /training (Memo Recall) | Recall input | recall | Piece-specific inputs and recall clock | Type tokens | Preserve custom-token interpretation | Yes | Yes |
| RCL-05 | /training (Memo Recall) | Multiple input fields | both scope | Current/next piece field | Enter | Focus next field; final Enter submits | Yes | Yes |
| RCL-06 | /training (Memo Recall) | Show answer | recall | Current typed answer | Show answer/Escape | Submit attempt including blanks; not free unrecorded hint | Yes | Yes |
| RCL-07 | /training (Memo Recall) | Review evaluation | review | Expected/yours, correct/wrong/missing/extra | Inspect | Position-based comparison with actual typed content | Yes | Yes |
| RCL-08 | /training (Memo Recall) | Review timing | review | Memo and recall; target fraction | Inspect | Saved duration/mean remains memo time | Yes | Yes |
| RCL-09 | /training (Memo Recall) | Word subset | review | Worth a look versus all words | Show all/Show fewer | Preserve missing/missed pair inclusion | Yes | Yes |
| RCL-10 | /training (Memo Recall) | Missing-word draft | review | No word add and suggestions | Enter/pick word | Stage piece-specific draft without immediate write | Yes | Yes |
| RCL-11 | /training (Memo Recall) | Commit review words | pending drafts | Unsaved count/Save | Save | Write nonempty words; mark saved; permit Next | Yes | Yes |
| RCL-12 | /training (Memo Recall) | Cancel review words | pending drafts | Draft values | Cancel/Escape | Discard drafts and permit Next | Yes | Yes |

## TRC: /training (Trace Sprint)

Source: `TraceSprintWorkspace.tsx; SplitStage.tsx; ChallengeCubes.tsx; review/TraceReview.tsx`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| TRC-01 | /training (Trace Sprint) | Challenge reveal | active | Front/back views of one state | Start | No provided target answer during tracing | Yes | Yes |
| TRC-02 | /training (Trace Sprint) | Linked cube views | active | Visible face labels/cues | Rotate cube | Preserve shared physical state and linked opposite view | Yes | Yes |
| TRC-03 | /training (Trace Sprint) | Target entry | active | Corners/Edges inputs | Type | Use raw trace and user scheme for evaluation | Yes | Yes |
| TRC-04 | /training (Trace Sprint) | Submit | active | Trace clock/input | Enter final field/Submit | Freeze timing and lock answer; one record | Yes | Yes |
| TRC-05 | /training (Trace Sprint) | Review | review | Correct/Incorrect; targets/accuracy/per-target | Inspect | Display expected/yours including missing and extra tokens | Yes | Yes |
| TRC-06 | /training (Trace Sprint) | Next | review | Next | Advance | Return idle without mnemonic editing or physical self-report | Yes | Yes |

## PAR: /pairs

Source: `pages/LetterPairs.tsx; components/pairs/*; utils/pairs.ts; AppDataContext.tsx`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| PAR-01 | /pairs | First-token browser | ready | Token rail and fill counts | Select first token | Show combinations for current scheme/scope | Yes | Yes |
| PAR-02 | /pairs | Scope browser | ready | Shared/Edges/Corners | Change scope | Recompute eligible axes and effective words | Yes | Yes |
| PAR-03 | /pairs | Diagonal | same token twice | Not a pair/disabled row | Try to edit | Do not open normal pair editor | Yes | Yes |
| PAR-04 | /pairs | Empty vocabulary | no words | Empty rows/No mnemonics yet | Open row | Allow first mnemonic creation | Yes | Yes |
| PAR-05 | /pairs | Keyboard row navigation | browser focus | Focused row/group | Arrows/Home/End | Move focus without saving words | Yes | Yes |
| PAR-06 | /pairs | Keyboard token navigation | browser focus | First token/pair | Brackets/PageUp/PageDown/type pair | Jump scheme-aware selection | Yes | Yes |
| PAR-07 | /pairs | Open editor | valid pair | Pair/usage/scope | Click/Enter | Show draft inspector; return focus on close | Yes | Yes |
| PAR-08 | /pairs | Edit shared primary | shared tab | Primary/alternates | Type | Stage default mnemonic | Yes | Yes |
| PAR-09 | /pairs | Inherited piece | no override | Uses shared/current word | Inspect | Resolve shared default accurately | Yes | Yes |
| PAR-10 | /pairs | Start override | inherited piece | Different word action | Activate | Create empty piece draft; no implicit shared append | Yes | Yes |
| PAR-11 | /pairs | Edit override | explicit piece tab | Piece primary/alternates | Type | Change only that piece's draft | Yes | Yes |
| PAR-12 | /pairs | Remove override | override tab | Use shared instead | Activate | Restore inherited effective list after save | Yes | Yes |
| PAR-13 | /pairs | Add alternate | editable tab | Alternate input | Enter/blur | Stage trimmed word, preserve primary order | Yes | Yes |
| PAR-14 | /pairs | Promote alternate | alternate exists | Alternate list | Click alternate | Swap primary and preserve other words | Yes | Yes |
| PAR-15 | /pairs | Remove primary | primary exists | Remove | Activate | Promote first alternate and announce change | Yes | Yes |
| PAR-16 | /pairs | Remove alternate | alternate exists | Remove word action | Activate | Remove exact draft alternate | Yes | Yes |
| PAR-17 | /pairs | Suggestions | editor | Suggest words/More | Open and choose | Explicit opt-in; stage suggestion only | Yes | Yes |
| PAR-18 | /pairs | Save | editor draft | Primary/alternates/overrides | Save/primary Enter | Normalize blanks/case-insensitive duplicates and persist | Yes | Yes |
| PAR-19 | /pairs | Empty save | all lists empty | Empty draft | Save | Remove entry rather than retain meaningless words | Yes | Yes |
| PAR-20 | /pairs | Cancel editor | dirty draft | Cancel/Close | Cancel/Escape | Discard unsaved draft and restore browser focus | Yes | Yes |
| PAR-21 | /pairs | Clear pair ask | saved entry | Word count/all scopes | Clear pair | Confirm before removing primary/alternates/overrides | Yes | Yes |
| PAR-22 | /pairs | Clear first-token ask | any saved section | First token and scope of deletion | Clear section | Confirm all entries with first token across all scopes | Yes | Yes |
| PAR-23 | /pairs | Override indication | scoped list | Inherited/edge/corner hints | Inspect | Do not confuse shared displayed word with override | Yes | Yes |
| PAR-24 | /pairs | Legacy records | migrated vocabulary | Effective shared/override values | Browse/edit | Honor adapter conversion; no retired strategy selector | Yes | Yes |
| PAR-25 | /pairs | Multi-character tokens | custom scheme | Explicit token boundaries | Navigate/edit | Do not split physical tokens by character | Yes | Yes |
| PAR-26 | /pairs | Responsive browser | mobile | Horizontal token rail and scroll list | Scroll/select | Keep all tokens and editor actions accessible | Yes | Yes |

## CRD: /flashcards

Source: `pages/Flashcards.tsx; hooks/useFlashcards.ts`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| CRD-01 | /flashcards | Empty cards | no eligible saved pair | No pairs yet/link | Add first mnemonic | Navigate to Letter Pairs | Yes | Yes |
| CRD-02 | /flashcards | Eligibility | pair data/current lettering | Pair/piece variants | Load card | Require two distinct valid piece tokens and effective word | Yes | Yes |
| CRD-03 | /flashcards | Eligible count | shared identical answers | Deduplicated card count | Inspect count | Count distinct pair/answer lists, retain piece variants internally | Yes | Yes |
| CRD-04 | /flashcards | Random selection | question/next | Random eligible pair/piece | Answer prior card | Uniform variants; exclude same variant when alternatives exist | Yes | Yes |
| CRD-05 | /flashcards | Question | hidden answer | Pair and Edge/Corner | Reveal/Space/Enter | Show effective primary and alternates | Yes | Yes |
| CRD-06 | /flashcards | Revealed | answer visible | Effective words | Remembered/Enter/Space | Record self-report then next question | Yes | Yes |
| CRD-07 | /flashcards | Forgot | answer visible | Same answer | Forgot/F | Record forgot; do not alter sampling weights | Yes | Yes |
| CRD-08 | /flashcards | Hold/fast-input safety | card just shown/key repeats | Current card | Hold key/answer before ~220ms | Avoid accidental repeated records | Yes | Yes |
| CRD-09 | /flashcards | Edit primary | revealed | Mnemonic input | Edit/E | Stage inline editing; disable answer buttons | Yes | Yes |
| CRD-10 | /flashcards | Save primary | editing nonblank | Draft word | Save/Enter | Write actual override-or-shared source list | Yes | Yes |
| CRD-11 | /flashcards | Add alternate | revealed | Alternate input/current primary | Add alternate/A then Save | Append case-insensitively new nonblank word to effective source | Yes | Yes |
| CRD-12 | /flashcards | Cancel inline edit | editing/adding | Draft input | Cancel/Escape | Return revealed without word change | Yes | Yes |
| CRD-13 | /flashcards | Recent cards | wide sidebar | At most 200 restored saved records | Select history row | Reopen pair in revealed state | Yes | Yes |
| CRD-14 | /flashcards | Counters | wide sidebar | Seen/remembered/forgot | Answer | Update saved attempts and encounter/forgotten counts | Yes | Yes |
| CRD-15 | /flashcards | Remove history row | recent record | Exact record delete | Remove | Delete exact attempt ID; retain words/counters | Yes | Yes |
| CRD-16 | /flashcards | Delete latest confirm | question/revealed | Latest card confirmation | Backspace/Delete | Remove latest only after confirm | Yes | Yes |
| CRD-17 | /flashcards | Clear cards confirm | nonempty | Recent-history scope | Clear/Shift+Backspace/Delete | Remove all flashcard attempts after confirm | Yes | Yes |
| CRD-18 | /flashcards | Card invalidation | vocabulary/scheme changed | Current card validity | Edit external data | Replace ineligible card except during active word editing | Yes | Yes |
| CRD-19 | /flashcards | No scope filter | current screen | No filter controls | Practice | Do not invent Both/Edges/Corners UI from initializer prop | Yes | Yes |
| CRD-20 | /flashcards | Mobile presentation | below lg | Pair/answer/actions | Reveal/edit/respond | Preserve real card actions despite hidden current sidebar | Yes | Yes |

## SET: /settings

Source: `pages/Settings.tsx; components/settings/*; repository.ts; utils/methodBuffers.ts`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| SET-01 | /settings | Account hydration | owner switching/loading | Loading account settings | Wait | Do not edit stale account draft | Yes | Yes |
| SET-02 | /settings | Section access | ready | Six settings sections | Select section | Scroll to selected content with current marker | Yes | Yes |
| SET-03 | /settings | Configurator modes | ready | Overview/Lettering/Buffers/Cube view | Select mode | Show correct controls without committing draft | Yes | Yes |
| SET-04 | /settings | Sticker token | lettering | Current token and piece/face | Edit up to 3 chars | Uppercase/no whitespace; draft physical sticker label | Yes | Yes |
| SET-05 | /settings | Duplicate/unlabelled | lettering | Also on/Unlabelled indication | Edit token | Inform without invented hard uniqueness validation | Yes | Yes |
| SET-06 | /settings | Sticker navigation | lettering | Selected physical sticker | Previous/Next/Enter/Tab | Move same-piece sticker selection | Yes | Yes |
| SET-07 | /settings | Scheme name | non-Speffz | Name input | Edit | Persist with setup Save | Yes | Yes |
| SET-08 | /settings | Speffz reset | custom | Overwrite confirmation | Use Speffz/confirm | Reset draft labels while retaining pairs | Yes | Yes |
| SET-09 | /settings | Edge buffer | edge-buffer mode | Directed sticker/common choices | Select | Stage physical buffer rather than token-only value | Yes | Yes |
| SET-10 | /settings | Corner buffer | corner-buffer mode | Directed sticker/common choices | Select | Stage physical buffer rather than unordered cubie | Yes | Yes |
| SET-11 | /settings | Cube top | Cube view | Six top colors | Select top | Retain/adjust front to legal adjacent orientation | Yes | Yes |
| SET-12 | /settings | Cube front | Cube view | Four enabled adjacent colors | Select front | Reject same/opposite top by disabled control | Yes | Yes |
| SET-13 | /settings | Adopt rotated view | valid rotated cube | Use this view | Activate | Stage live view without changing raw state/buffer | Yes | Yes |
| SET-14 | /settings | Reset rotation/view | rotated/nonstandard | Reset/standard reference | Activate | Restore display angle or white-top/green-front draft | Yes | Yes |
| SET-15 | /settings | Edge method | Methods | OP/M2 | Change | Choose view-relative conventional buffer once | Yes | Yes |
| SET-16 | /settings | Corner method | Methods | OP only | Inspect/select | Do not add unsupported methods | Yes | Yes |
| SET-17 | /settings | M2 preference | Methods | Automatically swap M2 targets toggle | Toggle | Persist immediately; effect only compatible M2 execution | Yes | Yes |
| SET-18 | /settings | Memo order | Methods | Corners first/Edges first | Choose | Persist immediately; reorder piece sections only | Yes | Yes |
| SET-19 | /settings | Live Timer preference | Timer | On/off | Toggle | Persist immediately; mask active Timer values only | Yes | Yes |
| SET-20 | /settings | Multiphase preference | Timer | On/off | Toggle | Persist immediately; next Timer run uses corresponding lifecycle | Yes | Yes |
| SET-21 | /settings | Dirty setup | labels/buffers/method/view differ | Unsaved changes/Save/Discard | Save | Commit setup/view through existing store | Yes | Yes |
| SET-22 | /settings | Discard setup | dirty | Same draft | Discard | Restore setup/view; do not undo immediate prefs | Yes | Yes |
| SET-23 | /settings | Leave dirty setup | app-bar navigation | Stay/Discard/Save and leave | Choose | Stay, discard-and-navigate, or save-and-navigate | Yes | Yes |
| SET-24 | /settings | First-use setup access | desktop section rail/direct URL | Run first-use setup | Open | Reach separate wizard; not a modal setting | Yes | Yes |
| SET-25 | /settings | Export | Data | Export backup | Export | Download versioned JSON of actual current workspace | Yes | Yes |
| SET-26 | /settings | Import preview | chosen valid JSON ≤25MB | Counts/date/setup/conflicts | Inspect | No data write before confirmation | Yes | Yes |
| SET-27 | /settings | Import keep mine | valid preview | Default merge strategy | Import | Use existing merge with local precedence | Yes | Yes |
| SET-28 | /settings | Import prefer backup | valid preview | Backup-precedence option | Import | Use existing merge with backup precedence | Yes | Yes |
| SET-29 | /settings | Import replace | valid preview | Replacement option/Replace my data | Confirm | Replace via existing parser/store behavior | Yes | Yes |
| SET-30 | /settings | Invalid import | parse/schema/size failure | File/problems/choose another | Close/reselect | Preserve existing workspace | Yes | Yes |
| SET-31 | /settings | Clear all pairs | nonempty vocabulary | Count-bearing warning | Clear all/confirm | Remove all saved words/alternates/overrides only | Yes | Yes |
| SET-32 | /settings | Clear disabled | empty vocabulary | Disabled clear action | Inspect | No misleading destructive action | Yes | Yes |
| SET-33 | /settings | Support | ready | Give feedback | Open | Show unsent feedback sheet | Yes | Yes |
| SET-34 | /settings | Admin support access | role admin | New feedback count/Open inbox | Open inbox | Reach protected admin destination | Yes | Yes |
| SET-35 | /settings | Owner isolation | account changes | Hydrated new draft | Wait/edit | Do not persist previous owner's setup into new account | Yes | Yes |

## AUT: /signin; /settings Account

Source: `hooks/useSignInFlow.ts; AccountSection.tsx; components/auth/*; Store.tsx`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| AUT-01 | /signin; /settings Account | Guest | signed out | Sign in to sync; local explanation | Continue practice | Keep normal functionality available | Yes | Yes |
| AUT-02 | /signin; /settings Account | Unconfigured server | no Supabase | Local explanation | Practice | Device-only operation; no false sync success | Yes | Yes |
| AUT-03 | /signin; /settings Account | WCA sign-in | configured guest | Continue with WCA | Start | Use existing server OAuth destination | Yes | Yes |
| AUT-04 | /signin; /settings Account | Google sign-in | configured guest | Continue with Google | Start | Use existing Supabase OAuth return | Yes | Yes |
| AUT-05 | /signin; /settings Account | Provider pending | redirecting | Pending provider/disabled choices | Cancel where offered | Reset local pending UI without fake signed-in account | Yes | Yes |
| AUT-06 | /signin; /settings Account | Guest exit | standalone sign-in | Continue without signing in | Activate | Return Timer without account requirement | Yes | Yes |
| AUT-07 | /signin; /settings Account | Migration dialog | meaningful guest data after auth | Pair/solve counts and two choices | Open/review | Do not silently merge/discard guest data | Yes | Yes |
| AUT-08 | /signin; /settings Account | Merge device data | migration | Merge into my account | Continue | Existing merge retains differences as alternates | Yes | Yes |
| AUT-09 | /signin; /settings Account | Use account data | migration | Use account data/continue account | Choose | Retain device guest copy; no invented automatic file download | Yes | Yes |
| AUT-10 | /signin; /settings Account | Identity | authenticated | Name/detail/provider/initials | Inspect | Respect WCA ID versus Google email | Yes | Yes |
| AUT-11 | /signin; /settings Account | Synced | saved | Last-tried indicator | Inspect | Show actual store status | Yes | Yes |
| AUT-12 | /signin; /settings Account | Saving | cloud work/loading | Progress status | Wait | Do not claim saved before real completion | Yes | Yes |
| AUT-13 | /signin; /settings Account | Offline | unsynced offline | Kept-here explanation | Reconnect | Existing store retries without losing local data | Yes | Yes |
| AUT-14 | /signin; /settings Account | Sync failed | error | Failure/last try/detail | Retry | Invoke actual repository retry and preserve device copy | Yes | Yes |
| AUT-15 | /signin; /settings Account | Sign out ask | authenticated | Sign out confirmation | Sign out | Confirm before actual auth transition | Yes | Yes |
| AUT-16 | /signin; /settings Account | Sign out result | confirmed | Guest/new owner state | Continue | Preserve owner-isolated device caches | Yes | Yes |
| AUT-17 | /signin; /settings Account | OAuth error limitation | flow error set | No current rendered error outlet | Integration review | Do not describe nonexistent banner as existing functionality | Yes | Yes |
| AUT-18 | /signin; /settings Account | Dormant conflict limitation | declared UI branch only | Literal conflict example not Store-emitted | Integration review | Do not invent fixed-count conflict resolution workflow | Yes | Yes |

## SUP: /settings Support; /admin/feedback

Source: `FeedbackSheet.tsx; FeedbackInbox.tsx; FeedbackDetail.tsx; lib/feedback.ts`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| SUP-01 | /settings Support; /admin/feedback | Feedback category | sheet open | Bug/Feature request/General | Choose | Use real category; bug-specific content conditional | Yes | Yes |
| SUP-02 | /settings Support; /admin/feedback | Feedback message | idle | Required Message | Type | Enable send only for nonblank message | Yes | Yes |
| SUP-03 | /settings Support; /admin/feedback | Guest contact | signed out | Optional email | Enter or leave blank | Optional reply contact; no sign-in requirement | Yes | Yes |
| SUP-04 | /settings Support; /admin/feedback | Authenticated attribution | signed in | Attached account identity | Compose | Use account identity; omit guest contact form | Yes | Yes |
| SUP-05 | /settings Support; /admin/feedback | Bug screenshot | Bug | Add/preview/remove image | Choose/remove | Attach only selected bug image; existing backend validates | Yes | Yes |
| SUP-06 | /settings Support; /admin/feedback | Technical disclosure | Bug | What's included | Expand/collapse | Show source/build/device/viewport/drill context, no automatic answers | Yes | Yes |
| SUP-07 | /settings Support; /admin/feedback | Send pending | sending | Sending/disabled send | Wait | Guard duplicate submission and closing | Yes | Yes |
| SUP-08 | /settings Support; /admin/feedback | Send failed | failure | Retained draft and Try again | Retry | Resubmit without losing message/image | Yes | Yes |
| SUP-09 | /settings Support; /admin/feedback | Send success | sent | Confirmation | Wait/close | Auto-close/reset after success; do not actually send audit feedback | Yes | Yes |
| SUP-10 | /settings Support; /admin/feedback | Admin access guard | guest/non-admin | Redirect to Settings | Open inbox URL | No admin records/actions or role inferred from identity | Yes | Yes |
| SUP-11 | /settings Support; /admin/feedback | Inbox type filter | admin | All/Bugs/Feature requests/General | Filter | Narrow existing records | Yes | Yes |
| SUP-12 | /settings Support; /admin/feedback | Inbox status filter | admin | Open/statuses/Everything | Filter | Open excludes archived; exact status filters remain distinct | Yes | Yes |
| SUP-13 | /settings Support; /admin/feedback | Inbox search | admin | Search feedback input | Type | Search message/contact/identity/source | Yes | Yes |
| SUP-14 | /settings Support; /admin/feedback | Inbox empty | no records/no matches | Appropriate empty message | Change filters | Distinguish no feedback from no match | Yes | Yes |
| SUP-15 | /settings Support; /admin/feedback | Feedback detail | admin record selected | Message/image/source/user/date/context | Open | Show exact authorized record | Yes | Yes |
| SUP-16 | /settings Support; /admin/feedback | Status update | admin detail | New/Reviewing/Planned/Resolved/Archived | Select | Persist status through existing server authority | Yes | Yes |
| SUP-17 | /settings Support; /admin/feedback | Private note draft | admin detail | Note/Save note/Cancel | Edit/save/cancel | Persist only deliberate note save; note admin-only | Yes | Yes |
| SUP-18 | /settings Support; /admin/feedback | Archive | nonarchived detail | Archive | Activate | Mark archived and close | Yes | Yes |
| SUP-19 | /settings Support; /admin/feedback | Restore | archived detail | Restore | Activate | Return status to New | Yes | Yes |
| SUP-20 | /settings Support; /admin/feedback | Permanent delete ask | admin detail | Irreversible confirmation | Delete permanently | Ask before real record deletion | Yes | Yes |

## ONB: /setup

Source: `pages/Setup.tsx; StickerEditor.tsx; BufferPanel.tsx`.

| ID | Route | Feature | State | Data shown | User action | Required result | Presentation may change | Semantics fixed |
|---|---|---|---|---|---|---|---|---|
| ONB-01 | /setup | Lettering step | initial | Speffz/Custom and cube | Choose | Initialize wizard draft; custom enables sticker editing | Yes | Yes |
| ONB-02 | /setup | Custom wizard labels | Custom | Selected sticker/token | Edit/navigate | Same token constraints as Settings | Yes | Yes |
| ONB-03 | /setup | Edge step | after lettering | Edge buffer/cube/common choices | Select/Continue | Stage physical edge buffer | Yes | Yes |
| ONB-04 | /setup | Corner step | after edge | Corner buffer/cube/common choices | Select/Continue | Stage physical corner buffer | Yes | Yes |
| ONB-05 | /setup | Ready summary | final | Scheme/buffers/fixed scramble reference | Start timing | Save setup and return Timer | Yes | Yes |
| ONB-06 | /setup | Back | later step | Previous wizard stage | Back | Retain wizard draft while revisiting | Yes | Yes |
| ONB-07 | /setup | Use defaults | any step | Use defaults | Activate | Save default setup and go Timer | Yes | Yes |
| ONB-08 | /setup | Wizard sign-in | wizard shell | Sign in link | Open | Reach standalone provider flow | Yes | Yes |

---

<!-- Source section: 11_INTEGRATION_GUARDRAILS.md -->

# Integration guardrails

**CURRENT BLINDSOLVE = FUNCTIONAL SOURCE OF TRUTH. MAGIC PATTERNS = FUTURE PRESENTATION SOURCE OF TRUTH. PRESERVE CAPABILITY, NOT CURRENT PRESENTATION.**

Magic Patterns may radically change every visual surface and component boundary. Prototype implementations must not replace the production behavioral authorities below.

| Responsibility | Existing authority to retain and reconnect | What the prototype must not decide |
|---|---|---|
| Cube mathematics, notation, legal scrambles | `domain/bld/cubing.ts`, cubing package, `utils/cube.ts`, `configureCubingSearch.ts` | Fake random move strings, invented state/diagram correspondence, camera observation claims |
| Raw BLD trace | `domain/bld/trace.ts`, `types.ts`, `speffz.ts` | Target order, valid breaks, solved-piece/cycle behavior, physical buffer identity |
| M2 transforms / parity | `domain/bld/memoConventions.ts`, `orientation.ts`, audited fixtures | Label-based swaps, changing raw trace, adding parity targets, manually remapping saved buffers when camera view changes |
| OP treatment | Production trace/configuration and supported method enums | New corner methods, M2 swaps applied to OP, fabricated algorithm execution |
| Restricted drill scrambles | `utils/randomStateScramble.ts`, `useExecScramble.ts`, `utils/bld.ts` | 'Edges only' scrambles that disturb corners, unrelated displayed memo/cube/scramble, nonlegal states |
| Target representation/order | `utils/challengeTargets.ts`, `guidedSolve.ts` | Treating raw and execution arrays as interchangeable; reversing sequence instead of reordering sections |
| Timer gesture/state/time | `useTimer.ts`, `useHoldStart.ts`, `useTimerSession.ts` | Resetting clock when remounting presentation, measuring via decorative animation, exposing live split while hidden, duplicate stop records |
| Reconstruction save | `useReconstruction.ts`, `useTimerSession.ts`, `utils/reconstruction.ts` | Rebuilding trace from visible text, confusing candidate focus with committed choice, overwriting raw memo with M2 execution letters |
| Pair semantics and tokenization | `utils/pairs.ts`, `AppDataContext.tsx`, `domain/letterPairs` | Joining token IDs ambiguously, forgetting inheritance, adding overrides to shared instead of replacing, flattening primary/alternate order |
| Training result evaluation | `useTrainingSession.ts`, `utils/training.ts` | Calling self-report objective accuracy; adding alternative-answer acceptance, changing memo duration to total, duplicate submission |
| Flashcard sampling/history | `useFlashcards.ts`, current saved attempt IDs | Adding spaced repetition, miscounting shared variants, treating timestamps as record identity, resetting saved history on mount |
| Sessions/statistics | `AppDataContext.tsx`, `utils/time.ts`, repository | New averaging definitions, changing DNF/+2 arithmetic, cross-session history leakage |
| Persistence / backup | `app/Store.tsx`, `lib/repository.ts`, `utils/backup.ts` | New localStorage keys/schema, silent destructive import, losing version migrations or historical snapshots |
| Sync and ownership | Store epochs/pending changes, `lib/cloudLock.ts`, record sync RPCs and migrations | Merging guest/account state automatically, writing account A changes under B, replaying stale cross-tab revisions, green fake sync badges |
| Auth | `lib/supabase.ts`, `useSignInFlow.ts`, Supabase/WCA server functions | Simulated authentication as production, client secrets, frontend-only account ownership or admin grants |
| Feedback / admin | `lib/feedback.ts`, server submit boundary, DB roles/RLS, screenshot storage | Granting role from email/name, bypassing attachment validation or rate limits, shipping sample private feedback as real |
| Routing / SEO / deployment | `magic/App.tsx`, `src/seo`, build scripts, headers and redirects | Broken existing deep links, making private routes indexable, changing CSP/Cloudflare or deployment configuration for design convenience |

## Suggested integration contract, without prescribing UI architecture

Keep the existing controllers/data sources as authorities. New components should receive current state and invoke existing actions. A design prototype can show explicitly labeled sample data; it must not invent production backend semantics. When connecting the new presentation, map each contract ID to a screen/action, then run the existing regression checks plus actual keyboard/touch flows.

A visual component may be split/combined/replaced freely, but state lifetime must remain above transient renderers where necessary. Recomposition must not restart an active Timer, replace the challenge on resize, discard an unsaved word, or create a new record when entering review. Accessible names/roles, focus visibility, reduced motion, text-input shortcut suppression and reachable footer actions remain functional requirements even when markup changes.

## Snapshot and evidence rules

- Saved mnemonic, scheme, and execution-target snapshots explain what was used in that solve; current preferences/database are not substitutes.
- View rotation is presentation, while physical directed buffers and raw cube state are domain facts.
- A reported success is not camera verification. A traced target sequence is not the human's measured face-turn sequence.
- Existing shortcomings documented here do not authorize prototype code to silently change their underlying behavior. Make any later behavior change explicit and separately reviewed.
- Do not copy csTimer GPL implementation into this codebase. No new dependency or licensing decision is needed for this handoff. The design prototype must not become the authority for cubing library APIs, RLS, synchronization or authentication.

This package is objective discovery. It intentionally contains no final Magic Patterns visual-design prompt.

---

<!-- Source section: 12_CURRENT_VS_OLD_MAGIC_PATTERNS_DELTA.md -->

# Current versus old Magic Patterns: historical safety net

History was used to find omissions, not as the product specification. The final audited tree at `2eeab8872d3a8106a0ef0b711b8108407e85c887` controls every current claim.

## Integration points

- `a47f3e9`: checkpoint before final Magic Patterns frontend migration.
- **`f442305be6f93fb8e443e3bf3c15c3bb0c9da5d6`**, 26 September 2026: earliest repository introduction of `src/magic/App.tsx`; commit 'integrate latest Magic Patterns frontend'. Added the Magic shell, main pages/components/hooks and reference screenshots; replaced old App composition.
- `00cd6eb31b7ec39fb1a2329ece611abf3115a345`, 27 September: 'Use the final Magic frontend', broader revised components, backup import/export, practice/reference refinements and preview seeds.
- `ef3fb5d`, 27 September: 'Use the final Magic refinements'. This is another presentation milestone, not a reason to freeze the earlier functional list.

## Changes designers are likely to miss

| Later commits / era | Current consequence that must survive |
|---|---|
| `8252a25`, `18e7be0`, `1e1c9a3` | Real persistence, WCA/Google OAuth, corrected server callback rather than sample auth UI |
| `6ea4eea`, `2ad03fe`, `01766bf` | Local-first synchronization with visible retry/status and owner-isolated hydrated settings; deliberate guest migration |
| `8db488d`, `28994db`, `50136af` | Security/CSP/worker and abuse boundaries; prototype code must not replace these |
| `83727e2`, `0abfd71`, `764b3f2` | Cross-tab conflict replay prevention, serialized account cloud work, no-op revision handling |
| `d93ef84` | Synchronous duplicate-attempt prevention |
| `9627bd2` | Show live timer preference: hidden active clock and split without losing timing |
| `1846a5c`, `51bf368`, `61b1784`, `12fbc7f` | M2 target preference, physical-frame transforms, explicit raw/execution distinction and internal parity metadata |
| `37e4e1a`, `84169d7`, `4b01902` | Removed unfinished convention/orientation/parity controls; current methods only M2/OP edges and OP corners; scope simplification |
| `009438b` | Guided Solve replaces Full Memo, with memo/execution/self-report/save lifecycle |
| `e7bbe94` | Timer and separate Training workspaces survive SPA navigation; shared piece scope but distinct challenges |
| `61214e4`, `8c078d0` | Interaction and mobile composition refinements, supported method/view semantics, history/cleanup and navigation reliability |
| `b6cded8` | Signed-out users skip admin RPC probing |
| `bd47b1e`, `685d88f` | Route metadata/static fallbacks, crawler discovery, noindex previews with preserved security headers |
| `fb2884a`, `b97b1e3`, merge `8fd10f4` | Training/Flashcard histories derive from saved store after load/account hydration; seeded result preview cannot edit an unrelated saved attempt; Timer banner removed |
| `64eaabc`, merge `2eeab88` | Concise titles, removal of About page, legacy About redirect, removal of visible M2-execution helper labels while preserving internal representation |

## Development branch is not production truth

The starting checkout `dev@2b0e69e` includes clean-room timing concept work: Relay, Lucent, Tempo, Folio, Kinetic and their preview machinery. Separate `design/timing-concept-*` branches also exist. Those explorations are **not current production user modes** and must not be added as a theme selector in the redesign contract. Main uses WorkspaceTimer/Reconstruction/SolveDetails. Dev's source paths and newer-looking concept UIs are not authority for current production routes or saved-history restoration.

Likewise older `src/pages`, `src/features/timer`, old screenshots, manifest seeds, and backend/CubeIQ planning do not establish routed BlindSolve capabilities. Historical Full Memo, broader method enums and removed preference controls are explicitly excluded from the active product.

## Production attribution

Initial Git status was clean. Remote reads found main had advanced to `2eeab88`; fetch updated the remote-tracking ref only. Checked-out branch and source were not switched or edited. CI config runs test/lint/build/E2E on main/dev pushes and PRs. Deployment was not triggered. Public production HTML names hashed assets but no commit SHA, and the GitHub connector could not access commit status (404). Exact deployed SHA remains an attribution limit; exact source baseline and live observed behavior are recorded separately.

---

<!-- Source section: 13_UI_COPY_AND_TERMINOLOGY.md -->

# UI copy inventory

Semantic correctness is mandatory; exact wording is mandatory only where it conveys a precise result/action or the integration relies on an accessible name. The designer may improve helper copy without inventing capabilities. No aesthetic language or final visual prompt is provided here.

## A. Terms whose meaning must remain correct

| Terms / current labels | Required meaning |
|---|---|
| Timer; 3BLD | Physical 3×3 blindfolded timing, not camera/CFOP analysis |
| Scramble; New scramble; Preparing scramble… | Sequence to apply physically and matching mathematical state; pending replacement is not a new solved state |
| Memo; execution; multiphase | Memo ends at recorded split; execution is remaining duration; total continues across split |
| OK; +2; DNF | Unpenalized, two-second penalty, did not finish; preserve raw time |
| Best; mo3; success | Exact non-DNF/effective-time/three-latest definitions in Timer document |
| Sessions; Today | Persistent Timer grouping; not Training drill history |
| Solve; attempt; card | Distinct record types with different cleanup scopes |
| Corners; Edges; Both; All | Piece types; All in Guided review means same scope as Both |
| Buffer; edge buffer; corner buffer | Physical directed sticker, not token, unordered cubie name or camera facing |
| Lettering; Speffz; Custom; Token; Unlabelled | Labels on directed stickers; 1–3-character custom tokens supported |
| OP; M2 | Supported methods; do not replace with invented method list |
| Automatically swap M2 targets | Execution convention transformation of affected second targets, not raw trace mutation |
| Cycle break; cycle-break sticker | Choice of a valid new-cycle starting sticker, not random error/penalty |
| Raw targets; execution targets; parity | Domain distinctions; not necessarily all visible labels in audited main |
| Letter pair; mnemonic; primary; alternate | Pair-to-word association and ordered effective words |
| Shared; Uses shared; Edges; Corners; override | Exact fallback/replacement model, not automatically combined lists |
| Execution Sprint | Execute physical solve while reading provided memo; self-report |
| Guided Solve | Memorize generated memo then execute, self-report after stop |
| Memo Recall | Study raw letters then type from memory; objective token comparison |
| Trace Sprint | Read matching cube views into raw targets; objective token comparison |
| Ready; Start execution; Stop; Submit; Show answer; Next | Different phase-specific actions; Show answer submits current recall |
| Solved; DNF | Self-report in physical drills, not proof from sensors |
| Correct; Incorrect; expected / yours; targets; accuracy; per target | Typed-target evaluation, not physical cube result |
| Reveal; Remembered; Forgot | Card answer reveal then self-reported recall; not adaptive mastery |
| Merge; replace; Discard; Save and leave; Clear all; Delete permanently | Distinct data consequences. Counts and scope must be explicit |
| Local; Synced; Saving; Offline; Sync failed; Retry | Truthful data/account states, not decorative status badges |
| WCA; Google | The only current account providers |
| Bug; Feature request; General feedback; New; Reviewing; Planned; Resolved; Archived | Feedback categories/statuses; 'private note' stays admin-only |

## B. Labels/helper wording that may be rewritten or removed safely

Examples include 'Scramble your cube, then solve it blind while reading the memo on screen', 'How it works', 'Turn the cube to how you like to see it', 'Change any of this … in Settings', 'Worth a look', 'Every pair has a word', 'No word · add', 'Not in your letter pairs yet', 'join your letter pairs', 'Stored on this device until you do', and 'Nothing new'. Preserve the underlying instructions, empty state or action where needed; these specific sentences and their visual placement are not a design requirement.

Current count labels such as 'No mnemonics yet', 'No pairs yet', 'No attempts yet', 'No solves in this session' may be rewritten, but the state must still be recognizable and offer its real next action. 'now [word]' may be rephrased while retaining the distinction between historical snapshot and current vocabulary.

Error wording may be clarified while retaining consequence/recovery: Scramble unavailable / New scramble failed; Couldn’t send feedback / Try again; Can’t import this file / Choose another file; Loading account settings; storage unavailable/export-backup advice; global Unable to display this screen / Reload application.

## Copy requiring special care

Do not propagate misleading helper promises as functionality: migration's 'you’ll be asked' conflicts with automatic alternate preservation; 'backup file' is not an implemented automatic download in that choice; pair usage copy says solves but the counter also reflects flashcards. The dormant fixed '3 pairs changed' conflict wording is not real current state. The latest main removed generic M2 execution-target helper labels; their absence does not erase domain semantics. Do not restore About text, old Full Memo copy, generic learning streaks, AI coaching, dashboards or motivational scaffolding as discovered requirements.

---

<!-- Source section: 14_SCREENSHOT_INDEX.md -->

# Screenshot reference index

**87 newly captured screenshots.** Functional evidence only; these are not visual inspiration.

Production URL: `https://blindsolve.com`. Local origin: `http://127.0.0.1:5184`, unmodified audited main with no Supabase configuration and disposable data. Local times/answers are synthetic audit interactions, not physical solve measurements. No authenticated/admin screenshot has been fabricated.

Names use measured viewport dimensions. Some 390×844 captures return a 390×843 JPEG raster; the separate raster column records this. Capture 10/11 used the browser’s default 1280×720 and are labeled accordingly. Matrix screenshots cover the five primary routes at all six requested sizes.

See `screenshots/screenshot-manifest.json` for image hashes, `responsive-measurements.json` for live inner dimensions/navigation bounds, and `route-checks.json` for observed redirects/not-found.

| Screenshot | Origin | Functional state | Viewport | JPEG raster |
|---|---|---|---|---|
| [01-production-timer-idle-1440x900.jpg](screenshots/01-production-timer-idle-1440x900.jpg) | Live production | production timer idle | 1440×900 | 1440×900 |
| [02-production-shortcuts-1440x900.jpg](screenshots/02-production-shortcuts-1440x900.jpg) | Live production | production shortcuts | 1440×900 | 1440×900 |
| [03-production-timer-active-1440x900.jpg](screenshots/03-production-timer-active-1440x900.jpg) | Live production | production timer active | 1440×900 | 1440×900 |
| [04-production-timer-execution-1440x900.jpg](screenshots/04-production-timer-execution-1440x900.jpg) | Live production | production timer execution | 1440×900 | 1440×900 |
| [05-production-timer-stopped-1440x900.jpg](screenshots/05-production-timer-stopped-1440x900.jpg) | Live production | production timer stopped | 1440×900 | 1440×900 |
| [06-production-reconstruction-1440x900.jpg](screenshots/06-production-reconstruction-1440x900.jpg) | Live production | production reconstruction | 1440×900 | 1440×900 |
| [07-production-reconstruction-390x844.jpg](screenshots/07-production-reconstruction-390x844.jpg) | Live production | production reconstruction | 390×844 | 390×843 |
| [08-production-reconstruction-900x560.jpg](screenshots/08-production-reconstruction-900x560.jpg) | Live production | production reconstruction | 900×560 | 900×560 |
| [09-production-reconstruction-word-1440x900.jpg](screenshots/09-production-reconstruction-word-1440x900.jpg) | Live production | production reconstruction word | 1440×900 | 1440×900 |
| [10-local-reconstruction-review-1280x720.jpg](screenshots/10-local-reconstruction-review-1280x720.jpg) | Unmodified main, isolated local guest | local reconstruction review | 1280×720 | 1280×720 |
| [11-local-solve-details-1280x720.jpg](screenshots/11-local-solve-details-1280x720.jpg) | Unmodified main, isolated local guest | local solve details | 1280×720 | 1280×720 |
| [12-production-letter-pairs-1440x900.jpg](screenshots/12-production-letter-pairs-1440x900.jpg) | Live production | production letter pairs | 1440×900 | 1440×900 |
| [13-production-pair-editor-1440x900.jpg](screenshots/13-production-pair-editor-1440x900.jpg) | Live production | production pair editor | 1440×900 | 1440×900 |
| [14-production-pair-suggestions-1440x900.jpg](screenshots/14-production-pair-suggestions-1440x900.jpg) | Live production | production pair suggestions | 1440×900 | 1440×900 |
| [15-production-pair-editor-1440x900.jpg](screenshots/15-production-pair-editor-1440x900.jpg) | Live production | production pair editor | 1440×900 | 1440×900 |
| [16-production-flashcards-empty-1440x900.jpg](screenshots/16-production-flashcards-empty-1440x900.jpg) | Live production | production flashcards empty | 1440×900 | 1440×900 |
| [17-local-solve-details-390x844.jpg](screenshots/17-local-solve-details-390x844.jpg) | Unmodified main, isolated local guest | local solve details | 390×844 | 390×843 |
| [18-production-account-and-data-1440x900.jpg](screenshots/18-production-account-and-data-1440x900.jpg) | Live production | production account and data | 1440×900 | 1440×900 |
| [19-production-feedback-1440x900.jpg](screenshots/19-production-feedback-1440x900.jpg) | Live production | production feedback | 1440×900 | 1440×900 |
| [20-production-feedback-320x568.jpg](screenshots/20-production-feedback-320x568.jpg) | Live production | production feedback | 320×568 | 320×568 |
| [21-local-execution-setup-1440x900.jpg](screenshots/21-local-execution-setup-1440x900.jpg) | Unmodified main, isolated local guest | local execution setup | 1440×900 | 1440×900 |
| [22-local-execution-active-1440x900.jpg](screenshots/22-local-execution-active-1440x900.jpg) | Unmodified main, isolated local guest | local execution active | 1440×900 | 1440×900 |
| [23-local-execution-review-1440x900.jpg](screenshots/23-local-execution-review-1440x900.jpg) | Unmodified main, isolated local guest | local execution review | 1440×900 | 1440×900 |
| [24-local-guided-setup-1440x900.jpg](screenshots/24-local-guided-setup-1440x900.jpg) | Unmodified main, isolated local guest | local guided setup | 1440×900 | 1440×900 |
| [25-local-guided-memo-1440x900.jpg](screenshots/25-local-guided-memo-1440x900.jpg) | Unmodified main, isolated local guest | local guided memo | 1440×900 | 1440×900 |
| [26-local-guided-execution-1440x900.jpg](screenshots/26-local-guided-execution-1440x900.jpg) | Unmodified main, isolated local guest | local guided execution | 1440×900 | 1440×900 |
| [27-local-guided-execution-320x568.jpg](screenshots/27-local-guided-execution-320x568.jpg) | Unmodified main, isolated local guest | local guided execution | 320×568 | 320×568 |
| [28-local-guided-report-320x568.jpg](screenshots/28-local-guided-report-320x568.jpg) | Unmodified main, isolated local guest | local guided report | 320×568 | 320×568 |
| [29-local-guided-review-320x568.jpg](screenshots/29-local-guided-review-320x568.jpg) | Unmodified main, isolated local guest | local guided review | 320×568 | 320×568 |
| [30-local-recall-study-1440x900.jpg](screenshots/30-local-recall-study-1440x900.jpg) | Unmodified main, isolated local guest | local recall study | 1440×900 | 1440×900 |
| [31-local-recall-input-1440x900.jpg](screenshots/31-local-recall-input-1440x900.jpg) | Unmodified main, isolated local guest | local recall input | 1440×900 | 1440×900 |
| [32-local-recall-review-1440x900.jpg](screenshots/32-local-recall-review-1440x900.jpg) | Unmodified main, isolated local guest | local recall review | 1440×900 | 1440×900 |
| [33-local-recall-review-390x844.jpg](screenshots/33-local-recall-review-390x844.jpg) | Unmodified main, isolated local guest | local recall review | 390×844 | 390×843 |
| [34-local-trace-active-1440x900.jpg](screenshots/34-local-trace-active-1440x900.jpg) | Unmodified main, isolated local guest | local trace active | 1440×900 | 1440×900 |
| [35-local-trace-active-320x568.jpg](screenshots/35-local-trace-active-320x568.jpg) | Unmodified main, isolated local guest | local trace active | 320×568 | 320×568 |
| [36-local-trace-review-320x568.jpg](screenshots/36-local-trace-review-320x568.jpg) | Unmodified main, isolated local guest | local trace review | 320×568 | 320×568 |
| [37-local-flashcard-question-1440x900.jpg](screenshots/37-local-flashcard-question-1440x900.jpg) | Unmodified main, isolated local guest | local flashcard question | 1440×900 | 1440×900 |
| [38-local-flashcard-revealed-1440x900.jpg](screenshots/38-local-flashcard-revealed-1440x900.jpg) | Unmodified main, isolated local guest | local flashcard revealed | 1440×900 | 1440×900 |
| [39-local-flashcard-revealed-320x568.jpg](screenshots/39-local-flashcard-revealed-320x568.jpg) | Unmodified main, isolated local guest | local flashcard revealed | 320×568 | 320×568 |
| [40-local-flashcard-edit-320x568.jpg](screenshots/40-local-flashcard-edit-320x568.jpg) | Unmodified main, isolated local guest | local flashcard edit | 320×568 | 320×568 |
| [41-local-live-timer-hidden-1440x900.jpg](screenshots/41-local-live-timer-hidden-1440x900.jpg) | Unmodified main, isolated local guest | local live timer hidden | 1440×900 | 1440×900 |
| [42-local-sessions-1440x900.jpg](screenshots/42-local-sessions-1440x900.jpg) | Unmodified main, isolated local guest | local sessions | 1440×900 | 1440×900 |
| [43-local-session-delete-confirm-1440x900.jpg](screenshots/43-local-session-delete-confirm-1440x900.jpg) | Unmodified main, isolated local guest | local session delete confirm | 1440×900 | 1440×900 |
| [44-local-settings-cube-view-1440x900.jpg](screenshots/44-local-settings-cube-view-1440x900.jpg) | Unmodified main, isolated local guest | local settings cube view | 1440×900 | 1440×900 |
| [45-local-settings-dirty-1440x900.jpg](screenshots/45-local-settings-dirty-1440x900.jpg) | Unmodified main, isolated local guest | local settings dirty | 1440×900 | 1440×900 |
| [46-local-settings-leave-confirm-1440x900.jpg](screenshots/46-local-settings-leave-confirm-1440x900.jpg) | Unmodified main, isolated local guest | local settings leave confirm | 1440×900 | 1440×900 |
| [47-local-speffz-confirm-1440x900.jpg](screenshots/47-local-speffz-confirm-1440x900.jpg) | Unmodified main, isolated local guest | local speffz confirm | 1440×900 | 1440×900 |
| [48-local-backup-invalid-split-1440x900.jpg](screenshots/48-local-backup-invalid-split-1440x900.jpg) | Unmodified main, isolated local guest | local backup invalid split | 1440×900 | 1440×900 |
| [49-local-clear-pairs-confirm-1440x900.jpg](screenshots/49-local-clear-pairs-confirm-1440x900.jpg) | Unmodified main, isolated local guest | local clear pairs confirm | 1440×900 | 1440×900 |
| [50-local-backup-preview-1440x900.jpg](screenshots/50-local-backup-preview-1440x900.jpg) | Unmodified main, isolated local guest | local backup preview | 1440×900 | 1440×900 |
| [51-local-backup-preview-320x568.jpg](screenshots/51-local-backup-preview-320x568.jpg) | Unmodified main, isolated local guest | local backup preview | 320×568 | 320×568 |
| [matrix-flashcards-1024x768.jpg](screenshots/matrix-flashcards-1024x768.jpg) | Live production | matrix flashcards | 1024×768 | 1024×768 |
| [matrix-flashcards-1280x720.jpg](screenshots/matrix-flashcards-1280x720.jpg) | Live production | matrix flashcards | 1280×720 | 1280×720 |
| [matrix-flashcards-1440x900.jpg](screenshots/matrix-flashcards-1440x900.jpg) | Live production | matrix flashcards | 1440×900 | 1440×900 |
| [matrix-flashcards-320x568.jpg](screenshots/matrix-flashcards-320x568.jpg) | Live production | matrix flashcards | 320×568 | 320×568 |
| [matrix-flashcards-390x844.jpg](screenshots/matrix-flashcards-390x844.jpg) | Live production | matrix flashcards | 390×844 | 390×843 |
| [matrix-flashcards-900x560.jpg](screenshots/matrix-flashcards-900x560.jpg) | Live production | matrix flashcards | 900×560 | 900×560 |
| [matrix-pairs-1024x768.jpg](screenshots/matrix-pairs-1024x768.jpg) | Live production | matrix pairs | 1024×768 | 1024×768 |
| [matrix-pairs-1280x720.jpg](screenshots/matrix-pairs-1280x720.jpg) | Live production | matrix pairs | 1280×720 | 1280×720 |
| [matrix-pairs-1440x900.jpg](screenshots/matrix-pairs-1440x900.jpg) | Live production | matrix pairs | 1440×900 | 1440×900 |
| [matrix-pairs-320x568.jpg](screenshots/matrix-pairs-320x568.jpg) | Live production | matrix pairs | 320×568 | 320×568 |
| [matrix-pairs-390x844.jpg](screenshots/matrix-pairs-390x844.jpg) | Live production | matrix pairs | 390×844 | 390×843 |
| [matrix-pairs-900x560.jpg](screenshots/matrix-pairs-900x560.jpg) | Live production | matrix pairs | 900×560 | 900×560 |
| [matrix-settings-1024x768.jpg](screenshots/matrix-settings-1024x768.jpg) | Live production | matrix settings | 1024×768 | 1024×768 |
| [matrix-settings-1280x720.jpg](screenshots/matrix-settings-1280x720.jpg) | Live production | matrix settings | 1280×720 | 1280×720 |
| [matrix-settings-1440x900.jpg](screenshots/matrix-settings-1440x900.jpg) | Live production | matrix settings | 1440×900 | 1440×900 |
| [matrix-settings-320x568.jpg](screenshots/matrix-settings-320x568.jpg) | Live production | matrix settings | 320×568 | 320×568 |
| [matrix-settings-390x844.jpg](screenshots/matrix-settings-390x844.jpg) | Live production | matrix settings | 390×844 | 390×843 |
| [matrix-settings-900x560.jpg](screenshots/matrix-settings-900x560.jpg) | Live production | matrix settings | 900×560 | 900×560 |
| [matrix-timer-1024x768.jpg](screenshots/matrix-timer-1024x768.jpg) | Live production | matrix timer | 1024×768 | 1024×768 |
| [matrix-timer-1280x720.jpg](screenshots/matrix-timer-1280x720.jpg) | Live production | matrix timer | 1280×720 | 1280×720 |
| [matrix-timer-1440x900.jpg](screenshots/matrix-timer-1440x900.jpg) | Live production | matrix timer | 1440×900 | 1440×900 |
| [matrix-timer-320x568.jpg](screenshots/matrix-timer-320x568.jpg) | Live production | matrix timer | 320×568 | 320×568 |
| [matrix-timer-390x844.jpg](screenshots/matrix-timer-390x844.jpg) | Live production | matrix timer | 390×844 | 390×843 |
| [matrix-timer-900x560.jpg](screenshots/matrix-timer-900x560.jpg) | Live production | matrix timer | 900×560 | 900×560 |
| [matrix-training-1024x768.jpg](screenshots/matrix-training-1024x768.jpg) | Live production | matrix training | 1024×768 | 1024×768 |
| [matrix-training-1280x720.jpg](screenshots/matrix-training-1280x720.jpg) | Live production | matrix training | 1280×720 | 1280×720 |
| [matrix-training-1440x900.jpg](screenshots/matrix-training-1440x900.jpg) | Live production | matrix training | 1440×900 | 1440×900 |
| [matrix-training-320x568.jpg](screenshots/matrix-training-320x568.jpg) | Live production | matrix training | 320×568 | 320×568 |
| [matrix-training-390x844.jpg](screenshots/matrix-training-390x844.jpg) | Live production | matrix training | 390×844 | 390×843 |
| [matrix-training-900x560.jpg](screenshots/matrix-training-900x560.jpg) | Live production | matrix training | 900×560 | 900×560 |
| [production-setup-1440x900.jpg](screenshots/production-setup-1440x900.jpg) | Live production | production setup | 1440×900 | 1440×900 |
| [production-setup-320x568.jpg](screenshots/production-setup-320x568.jpg) | Live production | production setup | 320×568 | 320×568 |
| [production-setup-390x844.jpg](screenshots/production-setup-390x844.jpg) | Live production | production setup | 390×844 | 390×843 |
| [production-signin-1440x900.jpg](screenshots/production-signin-1440x900.jpg) | Live production | production signin | 1440×900 | 1440×900 |
| [production-signin-320x568.jpg](screenshots/production-signin-320x568.jpg) | Live production | production signin | 320×568 | 320×568 |
| [production-signin-390x844.jpg](screenshots/production-signin-390x844.jpg) | Live production | production signin | 390×844 | 390×843 |

## Representative references

The production sequence 01–09 covers Timer idle, keyboard help, active memo/execution, stopped result, cycle breaks and mnemonic entry. Local 10–11/17 covers final reconstruction review and saved solve details. Production 12–20 covers pair browser/editor/suggestions, empty cards, guest account and unsent feedback. Local 21–40 covers all four training modes and card question/reveal/edit. Local 41–51 covers hidden live clock, session controls/confirmation, Settings draft/leave/reset, and valid/invalid backup and clear-pairs confirmations. Production Setup/Sign-in files capture safe guest-access states. The matrix includes desktop/mobile navigation on every primary route.

Some files show intermediate focus or animation, reflecting the actual current app. The screenshot set does not claim authenticated sync/admin mutation coverage, artificial network failures or all combinatorial configuration states.

---

<!-- Source section: 15_VALIDATION_AND_LIMITATIONS.md -->

# Completeness validation and limits

Baseline: `2eeab8872d3a8106a0ef0b711b8108407e85c887`. This is a documentation audit, not a release or implementation acceptance test.

## Coverage checks

| Comparison | Outcome |
|---|---|
| Route definitions | Eight screen routes, `/memo` and `/about` redirects, wildcard not-found accounted for. Production guest admin redirect and both legacy URLs exercised |
| Routed page tree | Timer, Training, LetterPairs, Flashcards, Settings, Setup, SignIn, FeedbackInbox covered. Older unrouted `src/pages`/`src/features` excluded |
| Major child components | Timer workspace/history/reconstruction/details, sessions, all four training workspaces/reviews, pair editor/suggestions, card inline editing, settings configurator/panels/account/backup, feedback sheet/admin detail, shared overlays and error boundary checked |
| Settings definitions/defaults | Every visible field mapped against Prefs/BldSetup and repository defaults: tokens/name/reset, both buffers, view top/front/adopt/reset, edge/corner methods, M2 toggle, memo order, live clock, multiphase. Retired fields explicitly excluded |
| Tests | Existing tests inspected for contract evidence; all **195 tests in 36 files passed** against temporary main source. Initial sandbox run could not collect tests because of temporary-file EPERM; the permitted rerun passed |
| Build | TypeScript, Vite production build and SEO output generation passed in the isolated main copy. Its CSS asset name `style-BZVYYi60.css` matches live production; the unconfigured local JS asset differs, so this does not certify the deployed commit. Existing chunk-size/third-party annotation warnings did not prevent the build |
| Existing E2E assertions | Reviewed current-main E2E for route layout, mobile navigation, pair editing/clears, cards, held shortcuts, shared count semantics, drill lifecycles, persistence, input guards, suggestions, support, view/method semantics, Timer reconstruction/live masking, auth providers, accessibility and requested sizes |
| Git history | First Magic entry identified at f442305; final Magic migration/follow-up and all relevant later main changes inspected; cached refs refreshed; dev-only concepts excluded |
| Screenshots | New captures only; production/local origin labeled, dimensions indexed, six-size production matrix measured; selected captures visually checked for actual content |
| Mutation boundary | No application source/UI/config/migrations changed; no deployment or real feedback submission; only documentation/reference output added |

The complete E2E suite was **not run** in this task. Manual browser flows exercised the Timer split/stop/reconstruction, local reconstruction save/skip and details, all four drills and their reviews, local card creation/reveal/edit/respond, Settings draft/leave/reset confirmations, valid/invalid backup preview, session deletion confirmation without delete, feedback draft without send, and live route/responsive inspection. These are audit examples, not physical cube correctness measurements.

## What remains code-audited rather than live exercised

- Google/WCA completion, fresh authenticated account creation, signed-in sync/offline/retry under real credentials, account-to-account isolation in a live session, guest merge after actual provider return, sign-out of a real account.
- Admin inbox with actual authorized data, status/note/archive/restore/delete mutations and private screenshot access. Guest redirect was observed; no admin identity was fabricated.
- Real feedback send/success, screenshot upload to production, network fault injection and real storage exhaustion. Source-defined UI states are documented without claiming they were all captured.
- Initial/replacement scramble failure injection, precise latest-request ordering under artificial delays, every buffer/label/method combination. Existing tests and source supply evidence; browser interaction did not exhaust all combinations.
- Real mobile devices, software keyboard occlusion, screen reader use, zoom, camera/hardware input. The current app has no camera or Bluetooth workflow to exercise.
- Independent Cloudflare deployment commit certification. Current remote main is exact and behavior agrees with live production, but no deployment SHA was returned.

## Findings retained without changing the app

1. `flow.error` is stored but not rendered on current auth surfaces.
2. AccountSection's literal conflict display is dormant; the actual Store merges conflicts as alternates. Guest-migration helper wording also exceeds actual behavior.
3. Reconstruction is static-state target reconstruction, not move playback. Skip may save partial unresolved trace while marking reconstruction complete.
4. Timer/Training/Flashcards differ in which reference/history areas disappear on mobile; do not codify hidden access as a capability deletion.
5. `short:hidden` in Timer has no configured Tailwind variant; do not assume functioning short-height hiding.
6. One synthetic Timer record failed its own backup preview with `Invalid timing split`; parser exact-sum validation and independently rounded Timer split fields explain a plausible cause. The symptom was observed; no production frequency/impact was measured and no fix made.
7. Valid backup preview extends outside the 320×568 viewport vertically. Width containment alone does not establish usable dialogs.

## Final forgotten-capability pass

The question was: **If a designer deleted the existing UI tomorrow and only had this package, what could they forget?** The final pass explicitly checked: live-clock masking including splits; request ordering; per-drill retained workspaces/shared scope; exactly-once submissions; Guided report-before-save; effective pair overrides and legacy collapse; card count versus physical sampling variants; history restoration; historical mnemonic snapshots; direct versus confirmed deletion paths; session fallback; Settings immediate versus staged saves; view-relative method selection and fixed physical buffers; raw versus M2 targets and hidden parity metadata; skip's true behavior; optional setup; guest access; provider-only auth; noindex/deep links; feedback disclosure/admin actions; focus/keyboard/mobile actions. These are represented in focused documents and the functional contract.

## Automatic approval review

Further reconstruction progression on the live production tab was rejected by automatic approval review because it could save or alter a solve using invented audit words. That live action was stopped. Saved-state inspection continued in an unconfigured temporary local copy with disposable guest data. No permission is needed to use the delivered handoff; completing the remaining authenticated/live mutation checks would require an explicitly authorized test account/workflow.
