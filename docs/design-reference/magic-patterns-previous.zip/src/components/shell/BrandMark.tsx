import React from 'react';

/** BlindSolve mark: a 3×3 face with the buffer sticker lit. */
export function BrandMark({ size = 20 }: {size?: number;}) {
  const cell = size / 3.6;
  const gap = (size - cell * 3) / 2;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden>
      {Array.from({ length: 9 }).map((_, i) => {
        const x = i % 3 * (cell + gap);
        const y = Math.floor(i / 3) * (cell + gap);
        const lit = i === 7;
        return (
          <rect
            key={i}
            x={x}
            y={y}
            width={cell}
            height={cell}
            rx={cell * 0.22}
            fill={lit ? '#7FE0C4' : '#ECEAE4'}
            opacity={lit ? 1 : 0.85} />);


      })}
    </svg>);

}