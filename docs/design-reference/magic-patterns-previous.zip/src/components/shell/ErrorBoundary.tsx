import React from 'react';
import { BrandMark } from './BrandMark';

interface State {
  error: Error | null;
}

export class ErrorBoundary extends React.Component<{children: React.ReactNode;}, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="flex h-dvh w-full items-center justify-center bg-bg px-6 text-fg">
        <div className="max-w-sm">
          <BrandMark size={22} />
          <h1 className="mt-6 text-xl font-semibold tracking-[-0.02em]">BlindSolve hit an error</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">Your saved solves, pairs and settings are untouched.</p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-6 h-10 rounded-md bg-fg px-4 text-sm font-medium text-bg hover:bg-white">
            
            Reload
          </button>
        </div>
      </div>);

  }
}