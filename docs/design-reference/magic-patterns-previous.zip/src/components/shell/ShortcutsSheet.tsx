import React from 'react';
import { useLocation } from 'react-router-dom';
import { useChrome } from '../../contexts/ChromeContext';
import { shortcutsByRoute } from '../../data/navigation';
import { Sheet } from '../ui/Sheet';

export function ShortcutsSheet() {
  const { shortcutsOpen, setShortcutsOpen } = useChrome();
  const { pathname } = useLocation();
  const groups = shortcutsByRoute[pathname] ?? [];
  return (
    <Sheet open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} title="Keyboard shortcuts" widthClass="md:w-[380px]">
      {groups.length === 0 && <p className="text-sm text-muted">This page has no shortcuts beyond ? for this sheet.</p>}
      <div className="space-y-6">
        {groups.map((g) =>
        <section key={g.title}>
            <h3 className="mb-2 text-[12px] font-medium text-faint">{g.title}</h3>
            <ul className="divide-y divide-line">
              {g.items.map((it) =>
            <li key={it.label} className="flex items-center justify-between gap-4 py-2.5">
                  <span className="text-[13.5px] text-fg">{it.label}</span>
                  <span className="flex shrink-0 gap-1">
                    {it.keys.map((k) =>
                <kbd
                  key={k}
                  className="inline-flex h-6 min-w-[24px] items-center justify-center rounded border border-line-strong px-1.5 font-mono text-[11.5px] text-muted">
                  
                        {k}
                      </kbd>
                )}
                  </span>
                </li>
            )}
            </ul>
          </section>
        )}
        <p className="text-[12.5px] text-faint">Press ? anywhere to open this. Shortcuts pause while typing.</p>
      </div>
    </Sheet>);

}