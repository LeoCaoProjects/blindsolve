import React from 'react';
import { GalleryVerticalEndIcon, SlidersHorizontalIcon, TargetIcon, TimerIcon, TypeIcon } from 'lucide-react';
import { NavItem } from '../../data/navigation';

const MAP = {
  timer: TimerIcon,
  training: TargetIcon,
  pairs: TypeIcon,
  cards: GalleryVerticalEndIcon,
  settings: SlidersHorizontalIcon
};

export function NavIcon({ icon, className }: {icon: NavItem['icon'];className?: string;}) {
  const Icon = MAP[icon];
  return <Icon className={className} strokeWidth={1.75} aria-hidden />;
}