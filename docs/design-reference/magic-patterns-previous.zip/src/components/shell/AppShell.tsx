import React, { useEffect, useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '../../contexts/AppStore';
import { useChrome } from '../../contexts/ChromeContext';
import { isTypingTarget, overlayOpen } from '../../utils/dom';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { NavRail } from './NavRail';
import { MobileDock } from './MobileDock';
import { ShortcutsSheet } from './ShortcutsSheet';

const TITLES: Record<string, string> = {
  '/': 'Timer',
  '/training': 'Training',
  '/pairs': 'Letter Pairs',
  '/flashcards': 'Flashcards',
  '/settings': 'Settings',
  '/admin/feedback': 'Feedback inbox'
};

export function AppShell() {
  const store = useStore();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { setShortcutsOpen } = useChrome();
  const [pendingTo, setPendingTo] = useState<string | null>(null);

  useEffect(() => {
    document.title = `${TITLES[pathname] ?? 'Page not found'} · BlindSolve`;
  }, [pathname]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === '?' && !isTypingTarget(e.target) && !overlayOpen()) {
        e.preventDefault();
        setShortcutsOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [setShortcutsOpen]);

  const onNav = (e: React.MouseEvent, to: string) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    if (store.settingsDirty && pathname === '/settings' && to !== '/settings') {
      e.preventDefault();
      setPendingTo(to);
    }
  };

  const leave = (mode: 'save' | 'discard') => {
    if (mode === 'save') store.leaveHandlers.current?.save();else
    store.leaveHandlers.current?.discard();
    const to = pendingTo;
    setPendingTo(null);
    if (to) navigate(to);
  };

  return (
    <div className="flex h-dvh w-full flex-col overflow-hidden bg-bg text-fg md:flex-row">
      <NavRail onNav={onNav} />
      <main className="relative min-h-0 min-w-0 flex-1 overflow-hidden">
        <Outlet />
      </main>
      <MobileDock onNav={onNav} />
      <ShortcutsSheet />
      <ConfirmDialog
        open={pendingTo !== null}
        title="Save setup changes?"
        confirmLabel="Save and leave"
        cancelLabel="Stay"
        tone="primary"
        extraAction={{ label: 'Discard', onClick: () => leave('discard') }}
        onConfirm={() => leave('save')}
        onCancel={() => setPendingTo(null)}>
        
        Lettering, buffers, methods or Cube View have unsaved changes.
      </ConfirmDialog>
    </div>);

}