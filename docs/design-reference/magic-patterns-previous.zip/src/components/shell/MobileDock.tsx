import React from 'react';
import { NavLink } from 'react-router-dom';
import { useChrome } from '../../contexts/ChromeContext';
import { primaryNav, settingsNav } from '../../data/navigation';
import { NavIcon } from './NavIcon';

/** Phone navigation. Keeps its space during a solve (no layout jump) but fades out of the way. */
export function MobileDock({ onNav }: {onNav: (e: React.MouseEvent, to: string) => void;}) {
  const { quiet } = useChrome();
  const items = [...primaryNav, settingsNav];
  return (
    <nav
      aria-label="Primary"
      className={`shrink-0 border-t border-line bg-bg pb-[env(safe-area-inset-bottom)] transition-opacity duration-200 ease-out md:hidden ${
      quiet ? 'pointer-events-none opacity-0' : ''}`
      }>
      
      <ul className="grid h-14 grid-cols-5">
        {items.map((item) =>
        <li key={item.to}>
            <NavLink
            to={item.to}
            end={item.to === '/'}
            onClick={(e) => onNav(e, item.to)}
            className={({ isActive }) =>
            `flex h-full flex-col items-center justify-center gap-1 transition-colors duration-150 ${
            isActive ? 'text-fg' : 'text-faint'}`

            }>
            
              <NavIcon icon={item.icon} className="h-[19px] w-[19px]" />
              <span className="text-[10.5px] font-medium leading-none">{item.short}</span>
            </NavLink>
          </li>
        )}
      </ul>
    </nav>);

}