import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { KeyboardIcon } from 'lucide-react';
import { useChrome } from '../../contexts/ChromeContext';
import { NavItem, primaryNav, settingsNav } from '../../data/navigation';
import { NavIcon } from './NavIcon';
import { BrandMark } from './BrandMark';
import { AccountDot } from './AccountDot';

type OnNav = (e: React.MouseEvent, to: string) => void;

function RailLink({ item, onNav }: {item: NavItem;onNav: OnNav;}) {
  return (
    <NavLink
      to={item.to}
      end={item.to === '/'}
      onClick={(e) => onNav(e, item.to)}
      className={({ isActive }) =>
      `group flex w-14 flex-col items-center gap-1 rounded-lg py-2 transition-colors duration-150 ease-out ${
      isActive ? 'bg-raised text-fg' : 'text-faint hover:text-fg'}`

      }>
      
      <NavIcon icon={item.icon} className="h-[18px] w-[18px]" />
      <span className="text-[10.5px] font-medium leading-none tracking-[-0.005em]">{item.short}</span>
    </NavLink>);

}

/** Desktop/tablet spine. Quiet during a live solve; still reachable on hover/focus. */
export function NavRail({ onNav }: {onNav: OnNav;}) {
  const { quiet, setShortcutsOpen } = useChrome();
  return (
    <nav
      aria-label="Primary"
      className={`hidden w-[72px] shrink-0 flex-col items-center border-r border-line bg-bg py-3 transition-opacity duration-200 ease-out focus-within:opacity-100 md:flex ${
      quiet ? 'opacity-[0.12] hover:opacity-100' : ''}`
      }>
      
      <Link to="/" onClick={(e) => onNav(e, '/')} aria-label="BlindSolve — Timer" className="mb-3 flex h-10 w-10 items-center justify-center">
        <BrandMark size={20} />
      </Link>
      <ul className="flex flex-col gap-0.5">
        {primaryNav.map((item) =>
        <li key={item.to}>
            <RailLink item={item} onNav={onNav} />
          </li>
        )}
      </ul>
      <div className="mt-auto flex flex-col items-center gap-0.5">
        <button
          type="button"
          onClick={() => setShortcutsOpen(true)}
          aria-label="Keyboard shortcuts (?)"
          title="Keyboard shortcuts  ?"
          className="flex h-10 w-14 items-center justify-center rounded-lg text-faint transition-colors duration-150 hover:text-fg">
          
          <KeyboardIcon className="h-[18px] w-[18px]" strokeWidth={1.75} />
        </button>
        <RailLink item={settingsNav} onNav={onNav} />
        <Link
          to="/settings#account"
          onClick={(e) => onNav(e, '/settings')}
          aria-label="Account and sync"
          className="mt-1 flex h-10 w-10 items-center justify-center rounded-lg hover:bg-raised">
          
          <AccountDot />
        </Link>
      </div>
    </nav>);

}