import React from 'react';
import { useStore } from '../../contexts/AppStore';

const LABEL = {
  synced: 'Synced',
  saving: 'Saving',
  offline: 'Offline',
  failed: 'Sync failed'
};

const COLOR = {
  synced: 'bg-signal',
  saving: 'bg-muted animate-pulse',
  offline: 'bg-warn',
  failed: 'bg-danger'
};

/** Truthful sync indicator — reflects store status only. */
export function AccountDot() {
  const { account } = useStore();
  const signedIn = account.mode === 'signedIn' || account.mode === 'admin';
  if (!signedIn) {
    return (
      <span className="flex h-7 w-7 items-center justify-center rounded-full border border-dashed border-line-strong text-[10px] text-faint">
        <span className="sr-only">Guest, data on this device</span>
        <span aria-hidden>—</span>
      </span>);

  }
  return (
    <span className="relative flex h-7 w-7 items-center justify-center rounded-full bg-raised text-[10.5px] font-semibold text-fg">
      <span aria-hidden>LC</span>
      <span
        className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-bg ${COLOR[account.sync]}`}
        aria-hidden />
      
      <span className="sr-only">{LABEL[account.sync]}</span>
    </span>);

}

export const SYNC_LABEL = LABEL;