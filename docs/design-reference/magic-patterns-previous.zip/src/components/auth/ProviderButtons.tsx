import React from 'react';
import { Loader2Icon } from 'lucide-react';

type Provider = 'WCA' | 'Google';

interface ProviderButtonsProps {
  pending: Provider | null;
  onStart: (p: Provider) => void;
  onCancel: () => void;
  size?: 'md' | 'lg';
}

function WcaMark() {
  return (
    <svg viewBox="0 0 20 20" className="h-4 w-4" aria-hidden>
      <rect x="1" y="1" width="8" height="8" rx="1.5" fill="#2D6BDB" />
      <rect x="11" y="1" width="8" height="8" rx="1.5" fill="#D6363C" />
      <rect x="1" y="11" width="8" height="8" rx="1.5" fill="#F2CF3A" />
      <rect x="11" y="11" width="8" height="8" rx="1.5" fill="#1E9E5A" />
    </svg>);

}

function GoogleMark() {
  return (
    <svg viewBox="0 0 20 20" className="h-4 w-4" aria-hidden>
      <path fill="#EA4335" d="M10 4.1c1.6 0 2.7.7 3.3 1.3l2.4-2.3C14.2 1.7 12.3.9 10 .9 6.4.9 3.4 3 2 6l2.8 2.2C5.5 5.8 7.6 4.1 10 4.1z" />
      <path fill="#4285F4" d="M19.1 10.2c0-.7-.1-1.3-.2-1.9H10v3.6h5.1c-.2 1.2-.9 2.2-1.9 2.9l2.8 2.2c1.7-1.6 3.1-3.9 3.1-6.8z" />
      <path fill="#FBBC05" d="M4.8 11.8a5.5 5.5 0 0 1 0-3.6L2 6a9.1 9.1 0 0 0 0 8.1l2.8-2.3z" />
      <path fill="#34A853" d="M10 19.1c2.5 0 4.5-.8 6-2.2l-2.8-2.2c-.8.5-1.8.9-3.2.9-2.4 0-4.5-1.6-5.2-3.9L2 14.1c1.4 3 4.4 5 8 5z" />
    </svg>);

}

export function ProviderButtons({ pending, onStart, onCancel, size = 'md' }: ProviderButtonsProps) {
  const h = size === 'lg' ? 'h-12 text-[15px]' : 'h-10 text-sm';
  const providers: {id: Provider;label: string;mark: React.ReactNode;}[] = [
  { id: 'WCA', label: 'Continue with WCA', mark: <WcaMark /> },
  { id: 'Google', label: 'Continue with Google', mark: <GoogleMark /> }];

  return (
    <div className="space-y-2">
      {providers.map((p) =>
      <button
        key={p.id}
        type="button"
        disabled={pending !== null}
        onClick={() => onStart(p.id)}
        className={`flex w-full items-center gap-3 rounded-md border border-line bg-raised px-4 font-medium text-fg transition-[background-color,border-color,opacity] duration-150 hover:border-line-strong hover:bg-hover disabled:opacity-50 ${h}`}>
        
          {pending === p.id ? <Loader2Icon className="h-4 w-4 animate-spin" /> : p.mark}
          {pending === p.id ? `Opening ${p.id}…` : p.label}
        </button>
      )}
      {pending &&
      <button type="button" onClick={onCancel} className="h-9 w-full text-[13px] text-muted hover:text-fg">
          Cancel
        </button>
      }
    </div>);

}