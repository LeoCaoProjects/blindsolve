import React, { useState } from 'react';
import { useStore } from '../../contexts/AppStore';
import { ConfirmDialog } from '../ui/ConfirmDialog';

/** Shown after sign-in when this device has meaningful guest data. Never merges or discards silently. */
export function MigrationDialog({ open, onDone }: {open: boolean;onDone: () => void;}) {
  const store = useStore();
  const [choice, setChoice] = useState<'merge' | 'account'>('merge');
  const pairs = Object.keys(store.pairs).length;
  const solves = store.solves.length;

  return (
    <ConfirmDialog
      open={open}
      title="This device has practice data"
      confirmLabel="Continue"
      cancelLabel="Use account data"
      tone="primary"
      onCancel={() => {
        setChoice('account');
        onDone();
      }}
      onConfirm={onDone}>
      
      <p>
        {pairs} letter pairs and {solves} solves were saved here before you signed in.
      </p>
      <div role="radiogroup" aria-label="Device data" className="mt-4 space-y-2">
        {(
        [
        { id: 'merge', title: 'Merge into my account', text: 'Differing words are kept as alternates.' },
        { id: 'account', title: 'Use my account’s data', text: 'A copy of this device’s data stays on this device.' }] as
        const).
        map((o) =>
        <button
          key={o.id}
          type="button"
          role="radio"
          aria-checked={choice === o.id}
          onClick={() => setChoice(o.id)}
          className={`flex w-full items-start gap-3 rounded-md border p-3 text-left transition-colors duration-150 ${
          choice === o.id ? 'border-fg/70 bg-raised' : 'border-line hover:border-line-strong'}`
          }>
          
            <span
            className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${
            choice === o.id ? 'border-fg' : 'border-line-strong'}`
            }>
            
              {choice === o.id && <span className="h-2 w-2 rounded-full bg-fg" />}
            </span>
            <span>
              <span className="block text-[14px] text-fg">{o.title}</span>
              <span className="block text-[12.5px] text-muted">{o.text}</span>
            </span>
          </button>
        )}
      </div>
    </ConfirmDialog>);

}