import React, { useRef } from 'react';
import { twMerge } from 'tailwind-merge';

export interface SegmentOption<T extends string> {
  value: T;
  label: React.ReactNode;
  disabled?: boolean;
  tone?: 'default' | 'warn' | 'danger' | 'signal';
  hint?: string;
}

interface SegmentedProps<T extends string> {
  value: T;
  onChange: (v: T) => void;
  options: SegmentOption<T>[];
  label: string;
  disabled?: boolean;
  size?: 'sm' | 'md';
  className?: string;
  stretch?: boolean;
}

const toneOn = {
  default: 'bg-fg text-bg',
  warn: 'bg-warn text-bg',
  danger: 'bg-danger text-bg',
  signal: 'bg-signal text-signal-ink'
};

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  label,
  disabled,
  size = 'md',
  className,
  stretch
}: SegmentedProps<T>) {
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const onKey = (e: React.KeyboardEvent, i: number) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    e.preventDefault();
    const dir = e.key === 'ArrowRight' ? 1 : -1;
    for (let k = 1; k <= options.length; k++) {
      const j = (i + dir * k + options.length) % options.length;
      if (!options[j].disabled) {
        onChange(options[j].value);
        refs.current[j]?.focus();
        break;
      }
    }
  };
  return (
    <div
      role="radiogroup"
      aria-label={label}
      aria-disabled={disabled || undefined}
      className={twMerge(
        'inline-flex rounded-md border border-line bg-surface p-0.5',
        stretch && 'flex w-full',
        disabled && 'opacity-50',
        className
      )}>
      
      {options.map((o, i) => {
        const on = o.value === value;
        return (
          <button
            key={o.value}
            ref={(el) => refs.current[i] = el}
            type="button"
            role="radio"
            aria-checked={on}
            title={o.hint}
            tabIndex={on ? 0 : -1}
            disabled={disabled || o.disabled}
            onClick={() => onChange(o.value)}
            onKeyDown={(e) => onKey(e, i)}
            className={twMerge(
              'whitespace-nowrap rounded-[5px] font-medium transition-[background-color,color] duration-150 ease-out disabled:cursor-not-allowed',
              size === 'sm' ? 'h-7 px-2.5 text-[12.5px]' : 'h-9 px-3.5 text-[13.5px]',
              stretch && 'flex-1',
              on ? toneOn[o.tone ?? 'default'] : 'text-muted hover:text-fg',
              !on && o.disabled && 'text-faint/60 hover:text-faint/60'
            )}>
            
            {o.label}
          </button>);

      })}
    </div>);

}