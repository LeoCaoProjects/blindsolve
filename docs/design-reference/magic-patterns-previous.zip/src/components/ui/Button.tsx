import React, { forwardRef } from 'react';
import { twMerge } from 'tailwind-merge';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'signal' | 'quiet';
type Size = 'sm' | 'md' | 'lg' | 'icon' | 'icon-sm';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const base =
'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium select-none ' +
'transition-[background-color,color,border-color,opacity,transform] duration-150 ease-out ' +
'active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none';

const variants: Record<Variant, string> = {
  primary: 'bg-fg text-bg hover:bg-white',
  secondary: 'bg-raised text-fg border border-line hover:border-line-strong hover:bg-hover',
  ghost: 'text-muted hover:text-fg hover:bg-raised',
  quiet: 'text-fg hover:bg-raised',
  danger: 'bg-danger/10 text-danger border border-danger/30 hover:bg-danger/20',
  signal: 'bg-signal text-signal-ink hover:bg-[#93E8D0]'
};

const sizes: Record<Size, string> = {
  sm: 'h-8 px-3 text-[13px]',
  md: 'h-10 px-4 text-sm',
  lg: 'h-12 px-5 text-[15px]',
  icon: 'h-10 w-10',
  'icon-sm': 'h-8 w-8'
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
{ variant = 'secondary', size = 'md', className, type = 'button', ...rest },
ref)
{
  return <button ref={ref} type={type} className={twMerge(base, variants[variant], sizes[size], className)} {...rest} />;
});