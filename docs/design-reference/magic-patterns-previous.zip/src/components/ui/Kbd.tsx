import React from 'react';
import { twMerge } from 'tailwind-merge';

export function Kbd({ children, className }: {children: React.ReactNode;className?: string;}) {
  return (
    <kbd
      className={twMerge(
        'hidden md:inline-flex h-5 min-w-[20px] items-center justify-center rounded border border-line-strong px-1 font-mono text-[11px] leading-none text-muted',
        className
      )}>
      
      {children}
    </kbd>);

}