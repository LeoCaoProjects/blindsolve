import React from 'react';

interface ToggleProps {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  id?: string;
  disabled?: boolean;
}

export function Toggle({ checked, onChange, label, id, disabled }: ToggleProps) {
  return (
    <button
      id={id}
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-10 shrink-0 items-center rounded-full border transition-[background-color,border-color] duration-150 ease-out disabled:opacity-40 ${
      checked ? 'border-signal bg-signal' : 'border-line-strong bg-raised'}`
      }>
      
      <span
        className={`inline-block h-4 w-4 rounded-full transition-transform duration-150 ease-out ${
        checked ? 'translate-x-[19px] bg-signal-ink' : 'translate-x-[3px] bg-muted'}`
        } />
      
    </button>);

}