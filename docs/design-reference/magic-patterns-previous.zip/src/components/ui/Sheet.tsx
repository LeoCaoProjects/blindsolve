import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { XIcon } from 'lucide-react';
import { twMerge } from 'tailwind-merge';
import { useIsDesktop } from '../../hooks/useMediaQuery';

interface SheetProps {
  open: boolean;
  onClose: () => void;
  title: React.ReactNode;
  meta?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
  /** auto: right panel ≥768px, bottom sheet on phones. full: full-screen on phones. */
  variant?: 'auto' | 'full';
  widthClass?: string;
  dismissible?: boolean;
  onScrim?: () => void;
  bodyClassName?: string;
}

const EASE = [0.23, 1, 0.32, 1] as const;

export function Sheet({
  open,
  onClose,
  title,
  meta,
  children,
  footer,
  variant = 'auto',
  widthClass = 'md:w-[440px]',
  dismissible = true,
  onScrim,
  bodyClassName
}: SheetProps) {
  const desktop = useIsDesktop();
  const panelRef = useRef<HTMLDivElement>(null);
  const restoreRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    restoreRef.current = document.activeElement as HTMLElement;
    const t = window.setTimeout(() => {
      const auto = panelRef.current?.querySelector<HTMLElement>('[data-autofocus]');
      (auto ?? panelRef.current)?.focus();
    }, 30);
    return () => {
      window.clearTimeout(t);
      restoreRef.current?.focus?.();
    };
  }, [open]);

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      if (dismissible) onClose();
    }
    if (e.key === 'Tab' && panelRef.current) {
      const f = panelRef.current.querySelectorAll<HTMLElement>(
        'button:not([disabled]), [href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (!f.length) return;
      const first = f[0];
      const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };

  const full = variant === 'full' && !desktop;
  const motionProps = desktop ?
  { initial: { x: 32, opacity: 0 }, animate: { x: 0, opacity: 1 }, exit: { x: 32, opacity: 0 } } :
  { initial: { y: 40, opacity: 0 }, animate: { y: 0, opacity: 1 }, exit: { y: 40, opacity: 0 } };

  return createPortal(
    <AnimatePresence>
      {open &&
      <div className="fixed inset-0 z-50" data-overlay="open" onKeyDown={onKeyDown}>
          <motion.button
          type="button"
          aria-label="Close"
          tabIndex={-1}
          className="absolute inset-0 h-full w-full cursor-default bg-black/60"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          onClick={() => onScrim ? onScrim() : dismissible && onClose()} />
        
          <motion.div
          ref={panelRef}
          role="dialog"
          aria-modal="true"
          aria-label={typeof title === 'string' ? title : undefined}
          tabIndex={-1}
          {...motionProps}
          transition={{ duration: 0.24, ease: EASE }}
          className={twMerge(
            'absolute flex flex-col bg-surface outline-none',
            full ?
            'inset-0' :
            'inset-x-0 bottom-0 max-h-[92dvh] rounded-t-xl border-t border-line pb-[env(safe-area-inset-bottom)]',
            'md:inset-y-0 md:left-auto md:right-0 md:bottom-auto md:max-h-none md:rounded-none md:border-l md:border-t-0',
            widthClass
          )}>
          
            {!desktop && !full && <div aria-hidden className="mx-auto mt-2 h-1 w-9 rounded-full bg-line-strong" />}
            <header className="flex items-start gap-3 px-5 pb-3 pt-4 md:pt-5">
              <div className="min-w-0 flex-1">
                <h2 className="text-[15px] font-semibold tracking-[-0.01em] text-fg">{title}</h2>
                {meta && <div className="mt-0.5 text-[13px] text-muted">{meta}</div>}
              </div>
              {dismissible &&
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="-mr-2 -mt-1 inline-flex h-9 w-9 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-raised hover:text-fg">
              
                  <XIcon className="h-4 w-4" />
                </button>
            }
            </header>
            <div className={twMerge('min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-5', bodyClassName)}>
              {children}
            </div>
            {footer && <footer className="border-t border-line px-5 py-3">{footer}</footer>}
          </motion.div>
        </div>
      }
    </AnimatePresence>,
    document.body
  );
}