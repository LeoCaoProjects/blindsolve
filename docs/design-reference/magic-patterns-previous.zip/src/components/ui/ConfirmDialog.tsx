import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Button } from './Button';

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  children?: React.ReactNode;
  confirmLabel: string;
  cancelLabel?: string;
  tone?: 'danger' | 'primary';
  onConfirm: () => void;
  onCancel: () => void;
  extraAction?: {label: string;onClick: () => void;};
  confirmDisabled?: boolean;
}

export function ConfirmDialog({
  open,
  title,
  children,
  confirmLabel,
  cancelLabel = 'Cancel',
  tone = 'danger',
  onConfirm,
  onCancel,
  extraAction,
  confirmDisabled
}: ConfirmDialogProps) {
  const cancelRef = useRef<HTMLButtonElement>(null);
  const restore = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    restore.current = document.activeElement as HTMLElement;
    const t = window.setTimeout(() => cancelRef.current?.focus(), 30);
    return () => {
      window.clearTimeout(t);
      restore.current?.focus?.();
    };
  }, [open]);

  return createPortal(
    <AnimatePresence>
      {open &&
      <div
        className="fixed inset-0 z-[60] flex items-center justify-center p-4"
        data-overlay="open"
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.stopPropagation();
            onCancel();
          }
        }}>
        
          <motion.div
          className="absolute inset-0 bg-black/70"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.16 }}
          onClick={onCancel} />
        
          <motion.div
          role="alertdialog"
          aria-modal="true"
          aria-label={title}
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
          className="relative flex max-h-[calc(100dvh-2rem)] w-full max-w-[400px] flex-col rounded-lg border border-line bg-surface">
          
            <div className="min-h-0 overflow-y-auto px-5 pb-2 pt-5">
              <h2 className="text-[15px] font-semibold text-fg">{title}</h2>
              {children && <div className="mt-2 text-[13.5px] leading-relaxed text-muted">{children}</div>}
            </div>
            <div className="flex flex-wrap justify-end gap-2 px-5 pb-5 pt-3">
              <Button ref={cancelRef} variant="ghost" onClick={onCancel}>
                {cancelLabel}
              </Button>
              {extraAction &&
            <Button variant="secondary" onClick={extraAction.onClick}>
                  {extraAction.label}
                </Button>
            }
              <Button variant={tone === 'danger' ? 'danger' : 'primary'} onClick={onConfirm} disabled={confirmDisabled}>
                {confirmLabel}
              </Button>
            </div>
          </motion.div>
        </div>
      }
    </AnimatePresence>,
    document.body
  );
}