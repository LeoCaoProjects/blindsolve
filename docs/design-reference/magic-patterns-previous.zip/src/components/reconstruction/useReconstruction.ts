import { useMemo, useState } from 'react';
import { useStore } from '../../contexts/AppStore';
import { reconstructionSample } from '../../data/reconstructionSample';
import { MemoPair, SolveMemo } from '../../types/domain';
import { effectiveWords, hasOverride, normalizeWords, pairKey } from '../../utils/pairs';

/**
 * PRESENTATION DRAFT for reconstruction. Production useReconstruction.ts + trace engine
 * own break candidates, retracing and vocabulary writes. This mirrors the states only.
 */

export type Piece = 'corners' | 'edges';
export type Decision = 'keep' | 'replace' | 'alternate';

export interface DraftPair {
  piece: Piece;
  tokens: string[];
  breaks: number[];
  key: string | null; // pair key for full pairs
  existing: string | undefined;
}

export function useReconstruction() {
  const store = useStore();
  const order: Piece[] = store.prefs.memoOrder === 'corners' ? ['corners', 'edges'] : ['edges', 'corners'];
  const [breaks, setBreaks] = useState<Record<Piece, string | null>>({ corners: null, edges: null });
  const [words, setWords] = useState<Record<string, string>>({});
  const [decisions, setDecisions] = useState<Record<string, Decision>>({});
  const [wordIdx, setWordIdx] = useState(0);

  const pendingPiece = order.find((p) => breaks[p] === null) ?? null;

  const sequences = useMemo(() => {
    const out = {} as Record<Piece, {tokens: string[];breakIdx: number[];pending: boolean;}>;
    (['corners', 'edges'] as Piece[]).forEach((p) => {
      const s = reconstructionSample[p];
      const chosen = breaks[p];
      const cand = s.candidates.find((c) => c.token === chosen);
      out[p] = {
        tokens: cand ? [...s.prefix, cand.token, ...cand.tail] : [...s.prefix],
        breakIdx: cand ? [s.prefix.length] : [],
        pending: !cand
      };
    });
    return out;
  }, [breaks]);

  const pairs = useMemo(() => {
    const out: DraftPair[] = [];
    order.forEach((piece) => {
      const { tokens, breakIdx } = sequences[piece];
      for (let i = 0; i < tokens.length; i += 2) {
        const t = tokens.slice(i, i + 2);
        const key = t.length === 2 ? pairKey(t[0], t[1]) : null;
        const existing = key ? effectiveWords(store.pairs[key], piece)[0] : undefined;
        out.push({
          piece,
          tokens: t,
          breaks: breakIdx.filter((b) => b >= i && b < i + 2).map((b) => b - i),
          key,
          existing
        });
      }
    });
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sequences, store.pairs, store.prefs.memoOrder]);

  const missing = useMemo(() => {
    if (pendingPiece) return [];
    const seen = new Set<string>();
    return pairs.filter((p) => {
      if (!p.key || p.existing) return false;
      const id = `${p.piece}:${p.key}`;
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });
  }, [pairs, pendingPiece]);

  const stage: 'break' | 'words' | 'review' = pendingPiece ? 'break' : wordIdx < missing.length ? 'words' : 'review';
  const draftId = (p: DraftPair) => `${p.piece}:${p.key}`;
  const valueFor = (p: DraftPair) => words[draftId(p)] ?? p.existing ?? '';
  const isChanged = (p: DraftPair) => {
    const v = (words[draftId(p)] ?? '').trim();
    return !!p.existing && !!v && v.toLowerCase() !== p.existing.toLowerCase();
  };
  const isNew = (p: DraftPair) => !p.existing && !!(words[draftId(p)] ?? '').trim();

  const chooseBreak = (piece: Piece, token: string) => setBreaks((b) => ({ ...b, [piece]: token }));

  const buildMemo = (): SolveMemo => {
    const memo: SolveMemo = { corners: [], edges: [] };
    pairs.forEach((p) => {
      const mp: MemoPair = { tokens: p.tokens, word: p.key ? valueFor(p).trim() : '', breaks: p.breaks.length ? p.breaks : undefined };
      memo[p.piece].push(mp);
    });
    return memo;
  };

  const commitVocabulary = () => {
    const done = new Set<string>();
    pairs.forEach((p) => {
      if (!p.key) return;
      const id = draftId(p);
      if (done.has(id)) return;
      done.add(id);
      const word = (words[id] ?? '').trim();
      const entry = store.pairs[p.key];
      if (isNew(p)) {
        const base = entry ?? { shared: [], usage: 0 };
        store.savePair(p.key, { ...base, [p.piece]: normalizeWords([word, ...(base[p.piece] as string[] ?? [])]) });
        return;
      }
      if (isChanged(p) && entry) {
        const d = decisions[id] ?? 'keep';
        if (d === 'keep') return;
        const source: 'shared' | Piece = hasOverride(entry, p.piece) ? p.piece : 'shared';
        const list = entry[source] as string[] ?? [];
        const next = d === 'replace' ? [word, ...list.slice(1)] : [...list, word];
        store.savePair(p.key, { ...entry, [source]: normalizeWords(next) });
      }
    });
  };

  return {
    order,
    stage,
    pendingPiece,
    sequences,
    pairs,
    missing,
    wordIdx,
    setWordIdx,
    words,
    setWord: (p: DraftPair, v: string) => setWords((w) => ({ ...w, [draftId(p)]: v })),
    decisions,
    setDecision: (p: DraftPair, d: Decision) => setDecisions((x) => ({ ...x, [draftId(p)]: d })),
    draftId,
    valueFor,
    isChanged,
    isNew,
    chooseBreak,
    buildMemo,
    commitVocabulary
  };
}

export type ReconstructionDraft = ReturnType<typeof useReconstruction>;