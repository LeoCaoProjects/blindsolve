import React from 'react';
import { useStore } from '../../contexts/AppStore';
import { Segmented } from '../ui/Segmented';
import { Decision, ReconstructionDraft } from './useReconstruction';

const M2_SWAP: Record<string, string> = { C: 'W', W: 'C', I: 'S', S: 'I' };

export function ReviewStep({ draft }: {draft: ReconstructionDraft;}) {
  const { prefs, setup } = useStore();
  const newWords = draft.pairs.filter((p) => draft.isNew(p));
  const m2Active = prefs.m2Swap && setup.edgeMethod === 'M2';
  const edgeTokens = draft.sequences.edges.tokens;

  return (
    <section aria-labelledby="review-title" className="space-y-6">
      <h3 id="review-title" className="sr-only">
        Review memo
      </h3>
      {draft.order.map((piece) => {
        const rows = draft.pairs.filter((p) => p.piece === piece);
        return (
          <div key={piece}>
            <h4 className="mb-1 text-[12px] font-medium text-faint">{piece === 'corners' ? 'Corners' : 'Edges'}</h4>
            <ul className="divide-y divide-line">
              {rows.map((p, i) =>
              <li key={i} className="py-1.5">
                  <div className="flex items-center gap-4">
                    <span className="w-12 shrink-0 font-mono text-[16px] tracking-[0.06em] text-fg">
                      {p.tokens.map((t, k) =>
                    <span key={k} className={p.breaks.includes(k) ? 'underline decoration-signal decoration-2 underline-offset-[5px]' : ''}>
                          {t}
                        </span>
                    )}
                    </span>
                    {p.key ?
                  <input
                    value={draft.valueFor(p)}
                    onChange={(e) => draft.setWord(p, e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
                    aria-label={`Word for ${p.tokens.join('')}`}
                    placeholder="—"
                    className="h-9 min-w-0 flex-1 rounded-md border border-transparent bg-transparent px-2 font-serif text-[17px] italic text-fg placeholder:not-italic placeholder:text-faint hover:border-line focus:border-line-strong focus:bg-bg focus:outline-none" /> :


                  <span className="px-2 text-[12.5px] text-faint">single target</span>
                  }
                    {draft.isNew(p) && <span className="shrink-0 text-[11.5px] font-medium text-signal">new</span>}
                  </div>
                  {draft.isChanged(p) &&
                <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-2 pl-16">
                      <span className="text-[12.5px] text-muted">
                        Saved: <span className="font-serif italic text-fg">{p.existing}</span>
                      </span>
                      <Segmented<Decision>
                    size="sm"
                    label={`Vocabulary for ${p.tokens.join('')}`}
                    value={draft.decisions[draft.draftId(p)] ?? 'keep'}
                    onChange={(d) => draft.setDecision(p, d)}
                    options={[
                    { value: 'keep', label: 'Keep existing' },
                    { value: 'replace', label: 'Use new word' },
                    { value: 'alternate', label: 'Add as alternate' }]
                    } />
                  
                    </div>
                }
                </li>
              )}
            </ul>
            {piece === 'edges' && m2Active &&
            <p className="mt-2 font-mono text-[13px] tracking-[0.06em] text-muted">
                <span className="mr-3 font-sans text-[12px] tracking-normal text-faint">Execution</span>
                {edgeTokens.map((t, i) =>
              <span key={i} className={i % 2 === 1 && M2_SWAP[t] ? 'text-signal' : ''}>
                    {i % 2 === 1 && M2_SWAP[t] ? M2_SWAP[t] : t}
                    {i % 2 === 1 ? ' ' : ''}
                  </span>
              )}
              </p>
            }
          </div>);

      })}
      {newWords.length > 0 &&
      <p className="text-[13px] text-muted">
          Adds {newWords.map((p) => `“${draft.valueFor(p).trim()}”`).join(', ')} to your letter pairs.
        </p>
      }
    </section>);

}