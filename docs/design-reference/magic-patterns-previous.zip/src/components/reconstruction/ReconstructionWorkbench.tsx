import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckIcon, ChevronDownIcon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { useTimer } from '../../contexts/TimerContext';
import { Face } from '../../types/cube';
import { Penalty } from '../../types/domain';
import { scrambleState } from '../../utils/cube';
import { formatMs, formatResult } from '../../utils/time';
import { isTypingTarget } from '../../utils/dom';
import { SPEFFZ, letterIndexOf, slotKind, stickerKey } from '../../utils/lettering';
import { useIsDesktop } from '../../hooks/useMediaQuery';
import { reconstructionSample } from '../../data/reconstructionSample';
import { Button } from '../ui/Button';
import { Segmented } from '../ui/Segmented';
import { CubeFigure } from '../cube/CubeFigure';
import { PENALTY_OPTIONS } from '../timer/penaltyOptions';
import { useReconstruction } from './useReconstruction';
import { SequenceStrip } from './SequenceStrip';
import { BreakStep } from './BreakStep';
import { WordStep } from './WordStep';
import { ReviewStep } from './ReviewStep';

const STAGES = [
{ id: 'break', label: 'Cycle breaks' },
{ id: 'words', label: 'Words' },
{ id: 'review', label: 'Review' }] as
const;

export function ReconstructionWorkbench({ solveId }: {solveId: string;}) {
  const store = useStore();
  const timer = useTimer();
  const desktop = useIsDesktop();
  const draft = useReconstruction();
  const solve = store.solves.find((s) => s.id === solveId);
  const [cubeOpen, setCubeOpen] = useState(false);
  const cube = useMemo(() => scrambleState(solve?.scramble ?? null), [solve?.scramble]);
  const n = store.sessionSolves.length;

  const save = useCallback(() => {
    if (!solve) return;
    draft.commitVocabulary();
    store.updateSolve(solve.id, { memo: draft.buildMemo() });
    timer.finishReconstruction();
  }, [draft, solve, store, timer]);

  const advanceWord = () => draft.setWordIdx(draft.wordIdx + 1);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        save();
        return;
      }
      if (isTypingTarget(e.target)) return;
      const map: Record<string, Penalty> = { '1': 'ok', '2': '+2', '3': 'dnf' };
      if (map[e.key] && solve) store.updateSolve(solve.id, { penalty: map[e.key] });
      if (e.key === 'Enter' && draft.stage === 'review' && !(e.target as HTMLElement).closest('button')) {
        e.preventDefault();
        save();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [save, draft.stage, solve, store]);

  const highlights = useMemo(() => {
    if (!draft.pendingPiece) return undefined;
    const kind = draft.pendingPiece === 'corners' ? 'corner' : 'edge';
    return new Set(reconstructionSample[draft.pendingPiece].candidates.map((c) => stickerKey(kind, SPEFFZ.indexOf(c.token))));
  }, [draft.pendingPiece]);

  const onSticker = (face: Face, index: number) => {
    if (!draft.pendingPiece) return;
    const kind = slotKind(index);
    const token = kind === 'center' ? undefined : (kind === 'corner' ? store.scheme.corners : store.scheme.edges)[letterIndexOf(face, index)];
    if (token) draft.chooseBreak(draft.pendingPiece, token);
  };

  if (!solve) return null;
  const stageIdx = STAGES.findIndex((s) => s.id === draft.stage);

  const cubeEl = (size: number) =>
  <CubeFigure
    state={cube}
    scheme={store.scheme}
    viewTop={store.setup.viewTop}
    viewFront={store.setup.viewFront}
    size={size}
    label="Cube at start of memo"
    showLabels
    highlights={highlights}
    onSticker={draft.pendingPiece ? onSticker : undefined}
    isClickable={(f, i) => !!highlights?.has(`${f}${i}`)} />;



  return (
    <motion.div
      role="dialog"
      aria-modal="true"
      aria-label="Reconstruction"
      data-overlay="open"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 12 }}
      transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
      className="fixed inset-0 z-40 flex flex-col bg-bg md:left-[72px] md:flex-row">
      
      {/* Result + cube */}
      <aside className="shrink-0 border-b border-line px-4 pb-3 pt-4 md:flex md:w-[340px] md:flex-col md:overflow-y-auto md:border-b-0 md:border-r md:px-8 md:pb-8 md:pt-8 lg:w-[400px]">
        <div className="flex items-baseline justify-between gap-3">
          <span className="text-[12.5px] text-faint">Solve {n}</span>
          {solve.multiphase && solve.memoMs !== undefined &&
          <span className="tnum font-mono text-[12.5px] text-muted md:hidden">
              {formatMs(solve.memoMs)} · {formatMs(solve.execMs ?? 0)}
            </span>
          }
        </div>
        <div className="mt-1 flex flex-wrap items-center justify-between gap-x-4 gap-y-2 md:block">
          <div
            className={`tnum font-mono text-[34px] font-medium leading-none tracking-[-0.04em] md:text-[56px] ${
            solve.penalty === 'dnf' ? 'text-danger' : 'text-fg'}`
            }>
            
            {formatResult(solve)}
          </div>
          {solve.multiphase && solve.memoMs !== undefined &&
          <dl className="tnum mt-3 hidden gap-6 font-mono text-[13.5px] md:flex">
              <div>
                <dt className="font-sans text-[11.5px] text-faint">Memo</dt>
                <dd className="text-muted">{formatMs(solve.memoMs)}</dd>
              </div>
              <div>
                <dt className="font-sans text-[11.5px] text-faint">Exec</dt>
                <dd className="text-muted">{formatMs(solve.execMs ?? 0)}</dd>
              </div>
            </dl>
          }
          <Segmented
            className="md:mt-5"
            size={desktop ? 'md' : 'sm'}
            label="Result"
            value={solve.penalty}
            onChange={(p) => store.updateSolve(solve.id, { penalty: p })}
            options={PENALTY_OPTIONS} />
          
        </div>

        {desktop ?
        <div className="mt-8 flex flex-1 items-center justify-center">{cubeEl(260)}</div> :

        <>
            <button
            type="button"
            onClick={() => setCubeOpen((o) => !o)}
            aria-expanded={cubeOpen}
            className="mt-3 flex h-8 items-center gap-1.5 text-[12.5px] text-muted hover:text-fg">
            
              <ChevronDownIcon className={`h-3.5 w-3.5 transition-transform duration-150 ${cubeOpen ? 'rotate-180' : ''}`} />
              {cubeOpen ? 'Hide cube' : draft.pendingPiece ? 'Show cube to pick on stickers' : 'Show cube'}
            </button>
            {cubeOpen && <div className="flex justify-center pb-1">{cubeEl(190)}</div>}
          </>
        }
      </aside>

      {/* Steps */}
      <section className="flex min-h-0 flex-1 flex-col">
        <div className="flex items-center gap-3 px-4 pt-3 md:px-10 md:pt-8">
          <ol className="flex min-w-0 items-center gap-3.5 md:gap-5" aria-label="Reconstruction progress">
            {STAGES.map((s, i) =>
            <li
              key={s.id}
              aria-current={i === stageIdx ? 'step' : undefined}
              className={`flex items-center gap-1 whitespace-nowrap text-[12.5px] md:text-[13px] ${
              i === stageIdx ? 'font-medium text-fg' : i < stageIdx ? 'text-muted' : 'text-faint'}`
              }>
              
                {i < stageIdx && <CheckIcon className="h-3.5 w-3.5 text-signal" aria-hidden />}
                {s.id === 'break' ?
              <>
                    <span className="md:hidden">Breaks</span>
                    <span className="hidden md:inline">{s.label}</span>
                  </> :

              s.label
              }
              </li>
            )}
          </ol>
          {draft.stage !== 'review' &&
          <button
            type="button"
            onClick={save}
            title="Esc"
            className="ml-auto h-8 shrink-0 whitespace-nowrap rounded-md px-2 text-[12.5px] text-muted hover:bg-raised hover:text-fg md:text-[13px]">
            
              Skip to save
            </button>
          }
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 pb-6 pt-5 md:px-10 md:pt-8">
          <div className="max-w-[640px]">
            {draft.stage !== 'review' &&
            <div className="mb-8">
                <SequenceStrip draft={draft} />
              </div>
            }
            {draft.stage === 'break' && draft.pendingPiece &&
            <BreakStep piece={draft.pendingPiece} onChoose={(t) => draft.chooseBreak(draft.pendingPiece!, t)} />
            }
            {draft.stage === 'words' && <WordStep draft={draft} onNext={advanceWord} />}
            {draft.stage === 'review' && <ReviewStep draft={draft} />}
          </div>
        </div>

        <footer
          className={`flex items-center gap-2 border-t border-line px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:px-10 ${
          draft.stage === 'break' ? 'hidden' : ''}`
          }>
          
          {draft.stage === 'words' && draft.wordIdx > 0 || draft.stage === 'review' && draft.missing.length > 0 ?
          <Button variant="ghost" onClick={() => draft.setWordIdx(Math.max(0, draft.wordIdx - 1))}>
              Back
            </Button> :
          null}
          <div className="ml-auto flex items-center gap-2">
            {draft.stage === 'words' &&
            <>
                <Button
                variant="secondary"
                onClick={() => {
                  const cur = draft.missing[draft.wordIdx];
                  if (cur) draft.setWord(cur, '');
                  advanceWord();
                }}>
                
                  Skip word
                </Button>
                <Button variant="primary" onClick={advanceWord}>
                  Continue
                </Button>
              </>
            }
            {draft.stage === 'review' &&
            <Button variant="primary" onClick={save}>
                Save solve <span className="hidden font-mono text-[11px] opacity-50 md:inline">↵</span>
              </Button>
            }
          </div>
        </footer>
      </section>
    </motion.div>);

}