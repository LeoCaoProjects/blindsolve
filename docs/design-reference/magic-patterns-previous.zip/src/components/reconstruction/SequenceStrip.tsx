import React from 'react';
import { ReconstructionDraft } from './useReconstruction';

/** Memo order as traced so far. Pending slot marks where the cycle break goes. */
export function SequenceStrip({ draft }: {draft: ReconstructionDraft;}) {
  return (
    <div className="space-y-2.5">
      {draft.order.map((piece) => {
        const seq = draft.sequences[piece];
        const groups: {t: string;i: number;}[][] = [];
        seq.tokens.forEach((t, i) => {
          if (i % 2 === 0) groups.push([]);
          groups[groups.length - 1].push({ t, i });
        });
        const isPending = draft.pendingPiece === piece;
        return (
          <div key={piece} className="flex items-baseline gap-4">
            <span className="w-14 shrink-0 text-[12px] font-medium text-faint">{piece === 'corners' ? 'Corners' : 'Edges'}</span>
            <div className="flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1.5 font-mono text-[17px] tracking-[0.06em] md:text-[19px]">
              {groups.map((g, gi) =>
              <span key={gi} className="whitespace-nowrap text-fg">
                  {g.map(({ t, i }) =>
                <span
                  key={i}
                  className={seq.breakIdx.includes(i) ? 'underline decoration-signal decoration-2 underline-offset-[6px]' : ''}>
                  
                      {t}
                    </span>
                )}
                </span>
              )}
              {seq.pending &&
              <span
                aria-label="Cycle break needed"
                className={`inline-flex h-7 w-6 items-center justify-center rounded border border-dashed ${
                isPending ? 'border-signal text-signal' : 'border-line-strong text-faint'}`
                }>
                
                  ?
                </span>
              }
            </div>
          </div>);

      })}
    </div>);

}