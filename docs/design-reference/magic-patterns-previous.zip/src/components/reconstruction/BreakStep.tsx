import React, { useEffect, useRef, useState } from 'react';
import { reconstructionSample } from '../../data/reconstructionSample';
import { SPEFFZ, stickerName } from '../../utils/lettering';
import { isTypingTarget } from '../../utils/dom';
import { Piece } from './useReconstruction';

interface BreakStepProps {
  piece: Piece;
  onChoose: (token: string) => void;
}

export function BreakStep({ piece, onChoose }: BreakStepProps) {
  const candidates = reconstructionSample[piece].candidates;
  const [focus, setFocus] = useState(0);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const kind = piece === 'corners' ? 'corner' : 'edge';

  useEffect(() => {
    setFocus(0);
    const t = window.setTimeout(() => refs.current[0]?.focus(), 40);
    return () => window.clearTimeout(t);
  }, [piece]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target) || e.metaKey || e.ctrlKey) return;
      if (e.key.length === 1) {
        const hit = candidates.find((c) => c.token.toLowerCase() === e.key.toLowerCase());
        if (hit) {
          e.preventDefault();
          onChoose(hit.token);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [candidates, onChoose]);

  const move = (dir: number) => {
    const n = (focus + dir + candidates.length) % candidates.length;
    setFocus(n);
    refs.current[n]?.focus();
  };

  return (
    <section aria-labelledby="break-title">
      <h3 id="break-title" className="text-[15px] font-semibold tracking-[-0.01em] text-fg">
        {piece === 'corners' ? 'Corner' : 'Edge'} cycle break
      </h3>
      <p className="mt-1 text-[13.5px] text-muted">Which target did you use? Pick it here or on the cube.</p>
      <div
        className="mt-4 flex flex-wrap gap-2"
        role="group"
        aria-label="Valid cycle-break targets"
        onKeyDown={(e) => {
          if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            e.preventDefault();
            move(1);
          }
          if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            e.preventDefault();
            move(-1);
          }
        }}>
        
        {candidates.map((c, i) =>
        <button
          key={c.token}
          ref={(el) => refs.current[i] = el}
          type="button"
          tabIndex={i === focus ? 0 : -1}
          onFocus={() => setFocus(i)}
          onClick={() => onChoose(c.token)}
          className="flex h-[68px] w-[68px] flex-col items-center justify-center gap-1 rounded-lg border border-line bg-raised transition-[background-color,border-color] duration-150 hover:border-signal/60 hover:bg-hover focus-visible:border-signal">
          
            <span className="font-mono text-[24px] font-medium leading-none text-fg">{c.token}</span>
            <span className="font-mono text-[10.5px] text-faint">{stickerName(kind, SPEFFZ.indexOf(c.token))}</span>
          </button>
        )}
      </div>
    </section>);

}