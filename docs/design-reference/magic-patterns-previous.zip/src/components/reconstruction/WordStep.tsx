import React, { useEffect, useRef, useState } from 'react';
import { suggestWords } from '../../utils/pairs';
import { ReconstructionDraft } from './useReconstruction';

export function WordStep({ draft, onNext }: {draft: ReconstructionDraft;onNext: () => void;}) {
  const current = draft.missing[draft.wordIdx];
  const [page, setPage] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setPage(null);
    const t = window.setTimeout(() => inputRef.current?.focus(), 40);
    return () => window.clearTimeout(t);
  }, [draft.wordIdx]);

  if (!current) return null;
  const value = draft.words[draft.draftId(current)] ?? '';
  const suggestions = page !== null ? suggestWords(current.tokens[0], current.tokens[1], page) : [];

  return (
    <section aria-labelledby="word-title">
      <div className="flex items-baseline justify-between gap-4">
        <h3 id="word-title" className="flex items-baseline gap-3">
          <span className="font-mono text-[32px] font-medium leading-none tracking-[0.06em] text-fg">
            {current.tokens.join('')}
          </span>
          <span className="text-[13px] text-muted">{current.piece === 'corners' ? 'Corners' : 'Edges'} · no word yet</span>
        </h3>
        <span className="tnum font-mono text-[12px] text-faint">
          {draft.wordIdx + 1}/{draft.missing.length}
        </span>
      </div>

      <label className="mt-5 block">
        <span className="sr-only">Word you used</span>
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => draft.setWord(current, e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              onNext();
            }
          }}
          placeholder="Word you used"
          className="h-14 w-full border-b border-line-strong bg-transparent font-serif text-[26px] italic text-fg placeholder:font-sans placeholder:text-[15px] placeholder:not-italic placeholder:text-faint focus:border-signal focus:outline-none" />
        
      </label>

      <div className="mt-4">
        {page === null ?
        <button
          type="button"
          onClick={() => setPage(0)}
          className="h-8 rounded-md text-[13px] text-muted underline decoration-line-strong underline-offset-4 hover:text-fg">
          
            Suggest words
          </button> :

        <div className="flex flex-wrap items-center gap-1.5">
            {suggestions.map((s) =>
          <button
            key={s}
            type="button"
            onClick={() => draft.setWord(current, s)}
            className="h-8 rounded-md border border-line px-3 font-serif text-[15px] italic text-fg hover:border-line-strong hover:bg-raised">
            
                {s}
              </button>
          )}
            <button type="button" onClick={() => setPage((p) => (p ?? 0) + 1)} className="h-8 px-2 text-[13px] text-muted hover:text-fg">
              More
            </button>
          </div>
        }
      </div>
    </section>);

}