import React, { useMemo } from 'react';
import { CubeState, Face, FaceColor, Scheme } from '../../types/cube';
import { applyView, KEY_GRID, viewRotation } from '../../utils/cube';
import { labelAt } from '../../utils/lettering';
import { Cube3D } from './Cube3D';
import { CubeNet } from './CubeNet';

interface CubeFigureProps {
  state: CubeState;
  scheme: Scheme;
  viewTop: FaceColor;
  viewFront: FaceColor;
  size?: number;
  label: string;
  showLabels?: boolean;
  /** reference-frame sticker keys */
  highlights?: Set<string>;
  selected?: string | null;
  onSticker?: (face: Face, index: number) => void;
  isClickable?: (face: Face, index: number) => boolean;
  resetKey?: unknown;
  view?: 'front' | 'back';
  dim?: boolean;
  flat?: boolean;
  draggable?: boolean;
  linkedOffset?: {x: number;y: number;};
  onRotate?: (o: {x: number;y: number;}) => void;
  /** override label lookup (e.g. draft lettering) */
  labelFor?: (face: Face, index: number) => string | undefined;
}

/**
 * Applies the saved Cube View to any reference-frame cube and keeps labels,
 * highlights and clicks tied to physical reference stickers.
 */
export function CubeFigure({
  state,
  scheme,
  viewTop,
  viewFront,
  size = 220,
  label,
  showLabels,
  highlights,
  selected,
  onSticker,
  isClickable,
  resetKey,
  view,
  dim,
  flat,
  draggable,
  linkedOffset,
  onRotate,
  labelFor
}: CubeFigureProps) {
  const seq = useMemo(() => viewRotation(viewTop, viewFront), [viewTop, viewFront]);
  const shown = useMemo(() => applyView(state, seq), [state, seq]);
  const keys = useMemo(() => applyView(KEY_GRID, seq), [seq]);

  const ref = (f: Face, i: number) => {
    const k = keys[f][i];
    return { face: k[0] as Face, index: Number(k.slice(1)) };
  };
  const labels = (f: Face, i: number) => {
    const r = ref(f, i);
    return labelFor ? labelFor(r.face, r.index) : labelAt(scheme, r.face, r.index);
  };
  const shownHighlights = useMemo(() => {
    if (!highlights) return undefined;
    const out = new Set<string>();
    (Object.keys(keys) as Face[]).forEach((f) =>
    keys[f].forEach((k, i) => {
      if (highlights.has(k)) out.add(`${f}${i}`);
    })
    );
    return out;
  }, [highlights, keys]);
  const shownSelected = useMemo(() => {
    if (!selected) return null;
    for (const f of Object.keys(keys) as Face[]) {
      const i = keys[f].indexOf(selected);
      if (i >= 0) return `${f}${i}`;
    }
    return null;
  }, [selected, keys]);

  if (flat) {
    return (
      <CubeNet
        state={shown}
        cell={Math.round(size / 13)}
        label={label}
        labels={showLabels ? labels : undefined}
        highlights={shownHighlights} />);


  }

  return (
    <Cube3D
      state={shown}
      size={size}
      label={label}
      labels={labels}
      showLabels={showLabels}
      highlights={shownHighlights}
      selected={shownSelected}
      onSticker={onSticker ? (f, i) => {const r = ref(f, i);onSticker(r.face, r.index);} : undefined}
      isClickable={isClickable ? (f, i) => {const r = ref(f, i);return isClickable(r.face, r.index);} : undefined}
      resetKey={`${String(resetKey)}-${viewTop}${viewFront}`}
      view={view}
      dim={dim}
      draggable={draggable}
      linkedOffset={linkedOffset}
      onRotate={onRotate} />);


}