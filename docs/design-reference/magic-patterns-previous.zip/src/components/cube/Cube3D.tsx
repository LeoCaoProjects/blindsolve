import React, { useEffect, useRef, useState } from 'react';
import { CubeState, Face, FaceColor } from '../../types/cube';
import { FACES } from '../../utils/cube';

interface Cube3DProps {
  state: CubeState;
  size?: number;
  label: string;
  labels?: (face: Face, index: number) => string | undefined;
  showLabels?: boolean;
  highlights?: Set<string>;
  selected?: string | null;
  isClickable?: (face: Face, index: number) => boolean;
  onSticker?: (face: Face, index: number) => void;
  view?: 'front' | 'back';
  resetKey?: unknown;
  draggable?: boolean;
  dim?: boolean;
  /** offset applied on top of the base view, for linked companion cubes */
  linkedOffset?: {x: number;y: number;};
  onRotate?: (offset: {x: number;y: number;}) => void;
}

export const STICKER_HEX: Record<FaceColor, string> = {
  W: '#EEEDE7',
  Y: '#F2CF3A',
  G: '#1E9E5A',
  B: '#2D6BDB',
  R: '#D6363C',
  O: '#EE8424'
};

const DARK_TEXT: Record<FaceColor, boolean> = { W: true, Y: true, O: true, G: false, B: false, R: false };

const FACE_TRANSFORM: Record<Face, string> = {
  F: 'rotateY(0deg)',
  B: 'rotateY(180deg)',
  R: 'rotateY(90deg)',
  L: 'rotateY(-90deg)',
  U: 'rotateX(90deg)',
  D: 'rotateX(-90deg)'
};

export function Cube3D({
  state,
  size = 220,
  label,
  labels,
  showLabels,
  highlights,
  selected,
  isClickable,
  onSticker,
  view = 'front',
  resetKey,
  draggable = true,
  dim,
  linkedOffset,
  onRotate
}: Cube3DProps) {
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const drag = useRef<{x: number;y: number;ox: number;oy: number;} | null>(null);

  useEffect(() => setOffset({ x: 0, y: 0 }), [resetKey]);

  const active = linkedOffset ?? offset;
  const base = view === 'front' ? { x: -26, y: -36 } : { x: 26, y: 144 };
  const rx = Math.max(-88, Math.min(88, base.x + active.x));
  const ry = base.y + active.y;
  const s = Math.round(size * 0.56);
  const half = s / 2;
  const gap = Math.max(2, Math.round(s * 0.028));
  const radius = Math.max(2, Math.round(s * 0.035));

  const onPointerDown = (e: React.PointerEvent) => {
    if (!draggable) return;
    drag.current = { x: e.clientX, y: e.clientY, ox: active.x, oy: active.y };
    const move = (ev: PointerEvent) => {
      if (!drag.current) return;
      const dx = ev.clientX - drag.current.x;
      const dy = ev.clientY - drag.current.y;
      if (Math.abs(dx) + Math.abs(dy) < 4) return;
      const next = { x: drag.current.ox - dy * 0.5, y: drag.current.oy + dx * 0.5 };
      setOffset(next);
      onRotate?.(next);
    };
    const up = () => {
      drag.current = null;
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  return (
    <div
      role="img"
      aria-label={label}
      onPointerDown={onPointerDown}
      className={`relative shrink-0 select-none ${draggable ? 'cursor-grab active:cursor-grabbing' : ''}`}
      style={{
        width: size,
        height: size,
        perspective: size * 5,
        opacity: dim ? 0.08 : 1,
        transition: 'opacity 200ms ease-out',
        touchAction: draggable ? 'none' : 'auto'
      }}>
      
      <div
        className="absolute"
        style={{
          width: s,
          height: s,
          left: (size - s) / 2,
          top: (size - s) / 2,
          transformStyle: 'preserve-3d',
          transform: `rotateX(${rx}deg) rotateY(${ry}deg)`
        }}>
        
        {FACES.map((face) =>
        <div
          key={face}
          className="absolute inset-0 grid grid-cols-3"
          style={{
            transform: `${FACE_TRANSFORM[face]} translateZ(${half}px)`,
            backfaceVisibility: 'hidden',
            background: '#050606',
            gap,
            padding: gap,
            borderRadius: radius * 1.6
          }}>
          
            {state[face].map((color, i) => {
            const key = `${face}${i}`;
            const text = showLabels && labels ? labels(face, i) : undefined;
            const clickable = !!onSticker && (!isClickable || isClickable(face, i));
            const hl = highlights?.has(key);
            const sel = selected === key;
            const style: React.CSSProperties = {
              background: STICKER_HEX[color],
              borderRadius: radius,
              boxShadow: sel ?
              `inset 0 0 0 ${Math.max(2, gap)}px #0C0D0E, 0 0 0 2px #ECEAE4` :
              hl ?
              `inset 0 0 0 ${Math.max(2, gap)}px #0C0D0E, 0 0 0 2px #7FE0C4` :
              undefined,
              color: DARK_TEXT[color] ? 'rgba(12,13,14,0.82)' : 'rgba(255,255,255,0.92)',
              fontSize: Math.max(8, Math.round(s * 0.11)),
              opacity: highlights && highlights.size > 0 && !hl && !sel && i !== 4 ? 0.55 : 1
            };
            const content = text ? <span className="font-mono font-semibold leading-none">{text}</span> : null;
            return clickable ?
            <button
              key={i}
              type="button"
              aria-label={`${face} sticker ${text ?? i}`}
              onPointerDown={(e) => e.stopPropagation()}
              onClick={() => onSticker?.(face, i)}
              className="flex items-center justify-center outline-none focus-visible:brightness-110"
              style={style}>
              
                  {content}
                </button> :

            <div key={i} className="flex items-center justify-center" style={style}>
                  {content}
                </div>;

          })}
          </div>
        )}
      </div>
    </div>);

}