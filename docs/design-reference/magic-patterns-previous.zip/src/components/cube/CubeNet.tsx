import React from 'react';
import { CubeState, Face } from '../../types/cube';
import { STICKER_HEX } from './Cube3D';

interface CubeNetProps {
  state: CubeState;
  cell?: number;
  label: string;
  labels?: (face: Face, index: number) => string | undefined;
  highlights?: Set<string>;
}

const LAYOUT: {face: Face;col: number;row: number;}[] = [
{ face: 'U', col: 1, row: 0 },
{ face: 'L', col: 0, row: 1 },
{ face: 'F', col: 1, row: 1 },
{ face: 'R', col: 2, row: 1 },
{ face: 'B', col: 3, row: 1 },
{ face: 'D', col: 1, row: 2 }];


/** Flat unfolded net — compact, readable at small sizes, all six faces at once. */
export function CubeNet({ state, cell = 8, label, labels, highlights }: CubeNetProps) {
  const g = Math.max(1, Math.round(cell / 8));
  const face = cell * 3 + g * 4;
  return (
    <div
      role="img"
      aria-label={label}
      className="relative shrink-0"
      style={{ width: face * 4 + g * 3, height: face * 3 + g * 2 }}>
      
      {LAYOUT.map(({ face: f, col, row }) =>
      <div
        key={f}
        className="absolute grid grid-cols-3"
        style={{
          left: col * (face + g),
          top: row * (face + g),
          width: face,
          height: face,
          gap: g,
          padding: g,
          background: '#050606',
          borderRadius: Math.max(1, g * 1.5)
        }}>
        
          {state[f].map((c, i) => {
          const t = labels?.(f, i);
          const hl = highlights?.has(`${f}${i}`);
          return (
            <div
              key={i}
              className="flex items-center justify-center font-mono font-semibold leading-none"
              style={{
                background: STICKER_HEX[c],
                borderRadius: Math.max(1, g),
                fontSize: Math.max(7, cell * 0.5),
                color: c === 'W' || c === 'Y' || c === 'O' ? 'rgba(12,13,14,0.8)' : 'rgba(255,255,255,0.9)',
                boxShadow: hl ? '0 0 0 2px #7FE0C4' : undefined,
                opacity: highlights && highlights.size && !hl && i !== 4 ? 0.5 : 1
              }}>
              
                {t}
              </div>);

        })}
        </div>
      )}
    </div>);

}