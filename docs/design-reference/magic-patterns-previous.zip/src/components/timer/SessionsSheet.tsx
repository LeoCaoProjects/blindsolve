import React, { useState } from 'react';
import { CheckIcon, PencilIcon, PlusIcon, Trash2Icon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { Sheet } from '../ui/Sheet';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { Button } from '../ui/Button';

export function SessionsSheet({ open, onClose }: {open: boolean;onClose: () => void;}) {
  const store = useStore();
  const [renaming, setRenaming] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');
  const [newName, setNewName] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const counts = (id: string) => store.solves.filter((s) => s.sessionId === id).length;
  const toDelete = store.sessions.find((s) => s.id === deleteId);

  const commitRename = () => {
    if (renaming && renameDraft.trim()) store.renameSession(renaming, renameDraft);
    setRenaming(null);
  };

  const create = () => {
    if (!newName.trim()) return;
    store.createSession(newName);
    setNewName('');
    onClose();
  };

  return (
    <>
      <Sheet
        open={open}
        onClose={onClose}
        title="Sessions"
        widthClass="md:w-[400px]"
        footer={
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            create();
          }}>
          
            <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="New session"
            aria-label="New session name"
            className="h-10 min-w-0 flex-1 rounded-md border border-line bg-bg px-3 text-sm text-fg placeholder:text-faint focus:border-line-strong focus:outline-none" />
          
            <Button type="submit" variant="primary" disabled={!newName.trim()}>
              <PlusIcon className="h-4 w-4" /> Create
            </Button>
          </form>
        }>
        
        <ul
          className="-mx-2"
          onKeyDown={(e) => {
            if ((e.key === 'Backspace' || e.key === 'Delete') && e.shiftKey && !(e.target as HTMLElement).matches('input')) {
              e.preventDefault();
              setDeleteId(store.activeSessionId);
            }
          }}>
          
          {store.sessions.map((s) => {
            const active = s.id === store.activeSessionId;
            return (
              <li key={s.id} className="group flex items-center gap-1 rounded-md hover:bg-raised">
                {renaming === s.id ?
                <input
                  autoFocus
                  value={renameDraft}
                  onChange={(e) => setRenameDraft(e.target.value)}
                  onBlur={commitRename}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') commitRename();
                    if (e.key === 'Escape') {
                      e.stopPropagation();
                      setRenaming(null);
                    }
                  }}
                  aria-label="Session name"
                  className="m-1 h-9 flex-1 rounded-md border border-line-strong bg-bg px-2 text-sm text-fg focus:outline-none" /> :


                <button
                  type="button"
                  aria-current={active}
                  data-autofocus={active || undefined}
                  onClick={() => {
                    store.selectSession(s.id);
                    onClose();
                  }}
                  className="flex h-11 min-w-0 flex-1 items-center gap-3 px-2 text-left">
                  
                    <span className="flex h-4 w-4 items-center justify-center">
                      {active && <CheckIcon className="h-4 w-4 text-signal" />}
                    </span>
                    <span className={`truncate text-[14px] ${active ? 'font-medium text-fg' : 'text-muted'}`}>{s.name}</span>
                    <span className="tnum ml-auto font-mono text-[12px] text-faint">{counts(s.id)}</span>
                  </button>
                }
                <button
                  type="button"
                  aria-label={`Rename ${s.name}`}
                  onClick={() => {
                    setRenaming(s.id);
                    setRenameDraft(s.name);
                  }}
                  className="flex h-9 w-9 items-center justify-center rounded-md text-faint hover:text-fg">
                  
                  <PencilIcon className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  aria-label={`Delete ${s.name}`}
                  onClick={() => setDeleteId(s.id)}
                  className="mr-1 flex h-9 w-9 items-center justify-center rounded-md text-faint hover:text-danger">
                  
                  <Trash2Icon className="h-3.5 w-3.5" />
                </button>
              </li>);

          })}
        </ul>
      </Sheet>
      <ConfirmDialog
        open={!!toDelete}
        title={`Delete “${toDelete?.name ?? ''}”?`}
        confirmLabel="Delete session"
        onCancel={() => setDeleteId(null)}
        onConfirm={() => {
          if (deleteId) store.deleteSession(deleteId);
          setDeleteId(null);
        }}>
        
        {toDelete && counts(toDelete.id) > 0 ?
        `This removes the session and its ${counts(toDelete.id)} solves. This can’t be undone.` :
        'This session has no solves. This can’t be undone.'}
      </ConfirmDialog>
    </>);

}