import React from 'react';
import { ChevronsUpDownIcon, Trash2Icon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { formatMs, formatResult, sessionStats } from '../../utils/time';

interface HistoryPanelProps {
  onOpenSessions: () => void;
  onOpenSolve: (id: string) => void;
  onAskClear: () => void;
}

export function HistoryPanel({ onOpenSessions, onOpenSolve, onAskClear }: HistoryPanelProps) {
  const { sessions, activeSessionId, sessionSolves, deleteSolve, prefs } = useStore();
  const session = sessions.find((s) => s.id === activeSessionId);
  const stats = sessionStats(sessionSolves);
  const latest = sessionSolves[0];
  const total = sessionSolves.length;
  const latestWords = latest ?
  (prefs.memoOrder === 'corners' ? [...latest.memo.corners, ...latest.memo.edges] : [...latest.memo.edges, ...latest.memo.corners]).
  filter((p) => p.tokens.length === 2).
  map((p) => p.word || '—') :
  [];

  return (
    <div className="flex h-full min-h-0 flex-col">
      <button
        type="button"
        onClick={onOpenSessions}
        className="group -mx-2 flex items-center gap-2 rounded-md px-2 py-1.5 text-left transition-colors duration-150 hover:bg-raised">
        
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[15px] font-semibold tracking-[-0.01em] text-fg">{session?.name}</span>
          <span className="block text-[12.5px] text-muted">
            {total} {total === 1 ? 'solve' : 'solves'}
          </span>
        </span>
        <ChevronsUpDownIcon className="h-4 w-4 text-faint group-hover:text-fg" aria-hidden />
        <span className="sr-only">Sessions</span>
      </button>

      <dl className="mt-4 grid grid-cols-3 gap-3 border-y border-line py-3">
        <Stat label="Best" value={stats.best !== null ? formatMs(stats.best) : '—'} />
        <Stat label="Mo3" value={stats.mo3 === null ? '—' : stats.mo3 === 'dnf' ? 'DNF' : formatMs(stats.mo3)} />
        <Stat label="Success" value={total ? `${stats.success}/${stats.total}` : '—'} />
      </dl>

      {latest && latestWords.length > 0 &&
      <button
        type="button"
        onClick={() => onOpenSolve(latest.id)}
        className="-mx-2 mt-3 rounded-md px-2 py-2 text-left transition-colors duration-150 hover:bg-raised">
        
          <span className="block text-[12px] font-medium text-faint">Last memo</span>
          <span className="mt-1 line-clamp-2 block font-serif text-[15px] italic leading-snug text-muted">
            {latestWords.join(' · ')}
          </span>
        </button>
      }

      <div className="mt-3 min-h-0 flex-1 overflow-y-auto overscroll-contain">
        {total === 0 ?
        <p className="py-6 text-[13px] text-faint">No solves in this session</p> :

        <ol className="-mx-2">
            {sessionSolves.map((s, i) =>
          <li key={s.id} className="group relative flex items-center">
                <button
              type="button"
              onClick={() => onOpenSolve(s.id)}
              className="flex h-10 flex-1 items-center gap-3 rounded-md px-2 text-left transition-colors duration-150 hover:bg-raised">
              
                  <span className="tnum w-7 font-mono text-[12px] text-faint">{total - i}</span>
                  <span
                className={`tnum font-mono text-[14.5px] ${
                s.penalty === 'dnf' ? 'text-danger' : s.penalty === '+2' ? 'text-warn' : 'text-fg'}`
                }>
                
                    {formatResult(s)}
                  </span>
                  {s.memoMs !== undefined && s.multiphase &&
              <span className="tnum ml-auto pr-8 font-mono text-[11.5px] text-faint">
                      {formatMs(s.memoMs)} · {formatMs(s.execMs ?? 0)}
                    </span>
              }
                </button>
                <button
              type="button"
              onClick={() => deleteSolve(s.id)}
              aria-label={`Delete solve ${total - i}`}
              className="absolute right-1 flex h-8 w-8 items-center justify-center rounded-md text-faint opacity-0 transition-opacity duration-150 hover:text-danger focus-visible:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100">
              
                  <Trash2Icon className="h-3.5 w-3.5" />
                </button>
              </li>
          )}
          </ol>
        }
      </div>

      <div className="mt-2 border-t border-line pt-2">
        <button
          type="button"
          onClick={onAskClear}
          disabled={total === 0}
          className="h-8 rounded-md px-2 text-[12.5px] text-faint transition-colors duration-150 hover:text-danger disabled:pointer-events-none disabled:opacity-40">
          
          Clear session
        </button>
      </div>
    </div>);

}

function Stat({ label, value }: {label: string;value: string;}) {
  return (
    <div>
      <dt className="text-[11.5px] text-faint">{label}</dt>
      <dd className="tnum mt-0.5 font-mono text-[15px] text-fg">{value}</dd>
    </div>);

}