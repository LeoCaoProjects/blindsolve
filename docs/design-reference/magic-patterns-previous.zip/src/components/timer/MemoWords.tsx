import React from 'react';
import { MemoOrder, MemoPair, PairDB, SolveMemo } from '../../types/domain';
import { effectiveWords, pairKey } from '../../utils/pairs';

interface MemoWordsProps {
  memo: SolveMemo;
  order: MemoOrder;
  pairs?: PairDB;
  showNow?: boolean;
}

export function PairTokens({ pair, className = '' }: {pair: MemoPair;className?: string;}) {
  return (
    <span className={`font-mono font-medium tracking-[0.04em] ${className}`}>
      {pair.tokens.map((t, i) =>
      <span key={i} className={pair.breaks?.includes(i) ? 'underline decoration-signal decoration-2 underline-offset-[5px]' : ''}>
          {t}
        </span>
      )}
    </span>);

}

/** Historical memo snapshot. Words shown are what the solve recorded. */
export function MemoWords({ memo, order, pairs, showNow }: MemoWordsProps) {
  const sections: {key: 'corners' | 'edges';label: string;}[] =
  order === 'corners' ?
  [
  { key: 'corners', label: 'Corners' },
  { key: 'edges', label: 'Edges' }] :

  [
  { key: 'edges', label: 'Edges' },
  { key: 'corners', label: 'Corners' }];

  const empty = memo.corners.length === 0 && memo.edges.length === 0;
  if (empty) return <p className="text-[13px] text-faint">No memo recorded for this solve.</p>;

  return (
    <div className="space-y-4">
      {sections.map(({ key, label }) =>
      <div key={key}>
          <h4 className="mb-1.5 text-[12px] font-medium text-faint">{label}</h4>
          {memo[key].length === 0 ?
        <p className="text-[13px] text-faint">Solved</p> :

        <ul className="grid grid-cols-[3.25rem_1fr] gap-x-3 gap-y-1">
              {memo[key].map((p, i) => {
            const now =
            showNow && pairs && p.tokens.length === 2 ?
            effectiveWords(pairs[pairKey(p.tokens[0], p.tokens[1])], key)[0] :
            undefined;
            const differs = now && p.word && now.toLowerCase() !== p.word.toLowerCase();
            return (
              <li key={i} className="contents">
                    <PairTokens pair={p} className="text-[14px] text-fg" />
                    <span className="min-w-0 truncate text-[15px]">
                      {p.tokens.length < 2 ?
                  <span className="text-faint" /> :
                  p.word ?
                  <span className="font-serif italic text-fg">{p.word}</span> :

                  <span className="text-faint">—</span>
                  }
                      {differs && <span className="ml-2 text-[12px] text-faint">now {now}</span>}
                    </span>
                  </li>);

          })}
            </ul>
        }
        </div>
      )}
    </div>);

}