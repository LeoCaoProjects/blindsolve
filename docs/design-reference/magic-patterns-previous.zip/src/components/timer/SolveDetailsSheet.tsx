import React, { useEffect, useMemo } from 'react';
import { Trash2Icon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { Penalty } from '../../types/domain';
import { scrambleState } from '../../utils/cube';
import { formatDate, formatMs, formatResult } from '../../utils/time';
import { isTypingTarget } from '../../utils/dom';
import { Sheet } from '../ui/Sheet';
import { Segmented } from '../ui/Segmented';
import { Button } from '../ui/Button';
import { CubeFigure } from '../cube/CubeFigure';
import { ScrambleText } from './ScrambleText';
import { MemoWords } from './MemoWords';
import { PENALTY_OPTIONS } from './penaltyOptions';

export function SolveDetailsSheet({ solveId, onClose }: {solveId: string | null;onClose: () => void;}) {
  const store = useStore();
  const solve = store.solves.find((s) => s.id === solveId);
  const n = solve ? store.sessionSolves.length - store.sessionSolves.findIndex((s) => s.id === solve.id) : 0;
  const cube = useMemo(() => scrambleState(solve?.scramble ?? null), [solve?.scramble]);

  useEffect(() => {
    if (!solve) return;
    const onKey = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target)) return;
      const map: Record<string, Penalty> = { '1': 'ok', '2': '+2', '3': 'dnf' };
      if (map[e.key]) store.updateSolve(solve.id, { penalty: map[e.key] });
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [solve, store]);

  return (
    <Sheet
      open={!!solve}
      onClose={onClose}
      title={solve ? `Solve ${n}` : ''}
      meta={solve ? formatDate(solve.date) : undefined}
      widthClass="md:w-[460px]"
      footer={
      solve &&
      <div className="flex justify-between">
            <Button
          variant="ghost"
          className="text-faint hover:text-danger"
          onClick={() => {
            store.deleteSolve(solve.id);
            onClose();
          }}>
          
              <Trash2Icon className="h-4 w-4" /> Delete solve
            </Button>
            <Button variant="secondary" onClick={onClose}>
              Close
            </Button>
          </div>

      }>
      
      {solve &&
      <div className="space-y-7">
          <section>
            <div
            className={`tnum font-mono text-[44px] font-medium leading-none tracking-[-0.04em] ${
            solve.penalty === 'dnf' ? 'text-danger' : 'text-fg'}`
            }>
            
              {formatResult(solve)}
            </div>
            {solve.penalty !== 'ok' &&
          <p className="tnum mt-2 font-mono text-[12.5px] text-faint">Recorded {formatMs(solve.rawMs)}</p>
          }
            {solve.multiphase && solve.memoMs !== undefined &&
          <p className="tnum mt-2 font-mono text-[13px] text-muted">
                Memo {formatMs(solve.memoMs)} <span className="text-faint">·</span> Exec {formatMs(solve.execMs ?? 0)}
              </p>
          }
            <Segmented
            className="mt-4"
            label="Result"
            value={solve.penalty}
            onChange={(p) => store.updateSolve(solve.id, { penalty: p })}
            options={PENALTY_OPTIONS} />
          
          </section>

          <section className="flex gap-4">
            <div className="min-w-0 flex-1">
              <h3 className="mb-1.5 text-[12px] font-medium text-faint">Scramble</h3>
              <ScrambleText scramble={solve.scramble} size="sm" />
            </div>
            <CubeFigure
            state={cube}
            scheme={store.scheme}
            viewTop={store.setup.viewTop}
            viewFront={store.setup.viewFront}
            size={120}
            label="Cube after scramble"
            draggable />
          
          </section>

          <section>
            <h3 className="mb-3 text-[12px] font-medium text-faint">Memo</h3>
            <MemoWords memo={solve.memo} order={store.prefs.memoOrder} pairs={store.pairs} showNow />
          </section>
        </div>
      }
    </Sheet>);

}