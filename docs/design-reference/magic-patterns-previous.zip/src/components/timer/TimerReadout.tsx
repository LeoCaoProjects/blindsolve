import React, { useEffect, useState } from 'react';
import { TimerPhase, TimerResult } from '../../contexts/TimerContext';
import { HoldState } from '../../hooks/useHoldToStart';
import { formatMs } from '../../utils/time';

interface TimerReadoutProps {
  phase: TimerPhase;
  hold: HoldState;
  startAt: number;
  splitAt: number | null;
  result: TimerResult | null;
  resultText?: string;
  showLive: boolean;
  multiphase: boolean;
}

function useNow(active: boolean) {
  const [now, setNow] = useState(() => performance.now());
  useEffect(() => {
    if (!active) return;
    let raf = 0;
    const tick = () => {
      setNow(performance.now());
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active]);
  return now;
}

export function TimerReadout({ phase, hold, startAt, splitAt, result, resultText, showLive, multiphase }: TimerReadoutProps) {
  const live = phase === 'memo' || phase === 'exec' || phase === 'running';
  const now = useNow(live && showLive);
  const elapsed = live ? now - startAt : 0;

  let main: string;
  if (live) main = showLive ? formatMs(Math.max(0, elapsed)) : 'Solve';else
  if (phase === 'stopped' && result) main = resultText ?? formatMs(result.totalMs);else
  main = '0.00';

  const color =
  hold === 'ready' ? 'text-signal' : hold === 'armed' ? 'text-faint' : main === 'DNF' ? 'text-danger' : 'text-fg';

  const memoSplit = splitAt !== null ? splitAt - startAt : null;
  const showPhases = live && (phase === 'memo' || phase === 'exec') || phase === 'stopped' && result?.memoMs !== undefined;
  const idleMultiphase = !live && phase !== 'stopped' && hold === 'idle';

  return (
    <div className="flex flex-col items-center">
      <div
        role="timer"
        aria-live="off"
        className={`tnum font-medium leading-none transition-colors duration-100 ${color} ${
        main === 'Solve' ? 'font-sans tracking-[-0.03em]' : 'font-mono tracking-[-0.045em]'} text-[clamp(64px,19vw,104px)] md:text-[clamp(88px,11vw,184px)] short:md:text-[clamp(72px,9vw,128px)]`
        }>
        
        {main}
      </div>

      <div className="mt-5 h-7 short:mt-3" aria-live="polite">
        {showPhases &&
        <div className="flex items-center gap-6 font-mono text-[13px] md:text-[14px]">
            <PhaseMark
            label="Memo"
            active={phase === 'memo'}
            value={
            phase === 'stopped' ?
            result?.memoMs !== undefined ?
            formatMs(result.memoMs) :
            undefined :
            phase === 'exec' && showLive && memoSplit !== null ?
            formatMs(memoSplit) :
            undefined
            } />
          
            <PhaseMark
            label="Exec"
            active={phase === 'exec'}
            value={phase === 'stopped' && result?.execMs !== undefined ? formatMs(result.execMs) : undefined} />
          
          </div>
        }
        {idleMultiphase && !multiphase && <span className="text-[12.5px] text-faint">Single phase</span>}
      </div>
    </div>);

}

function PhaseMark({ label, active, value }: {label: string;active: boolean;value?: string;}) {
  return (
    <span className={`flex items-baseline gap-2 ${active ? 'text-fg' : 'text-faint'}`}>
      <span className="relative font-sans text-[12px] font-medium uppercase tracking-[0.08em]">
        {label}
        <span
          aria-hidden
          className={`absolute -bottom-1.5 left-0 h-[2px] w-full rounded-full transition-opacity duration-150 ${
          active ? 'bg-signal opacity-100' : 'opacity-0'}`
          } />
        
      </span>
      {value && <span className="tnum text-muted">{value}</span>}
    </span>);

}