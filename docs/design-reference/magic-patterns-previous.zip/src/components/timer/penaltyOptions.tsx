import React from 'react';
import { SegmentOption } from '../ui/Segmented';
import { Penalty } from '../../types/domain';

export const PENALTY_OPTIONS: SegmentOption<Penalty>[] = [
{ value: 'ok', label: <span>OK <span className="ml-1 hidden font-mono text-[10.5px] opacity-50 md:inline">1</span></span> },
{ value: '+2', label: <span>+2 <span className="ml-1 hidden font-mono text-[10.5px] opacity-50 md:inline">2</span></span>, tone: 'warn' },
{ value: 'dnf', label: <span>DNF <span className="ml-1 hidden font-mono text-[10.5px] opacity-50 md:inline">3</span></span>, tone: 'danger' }];