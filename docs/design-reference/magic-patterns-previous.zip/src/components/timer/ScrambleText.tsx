import React from 'react';
import { twMerge } from 'tailwind-merge';

interface ScrambleTextProps {
  scramble: string | null;
  preparing?: boolean;
  className?: string;
  size?: 'lg' | 'md' | 'sm';
}

const SIZE = {
  lg: 'text-[17px] sm:text-[20px] lg:text-[23px] short:lg:text-[19px] leading-[1.55]',
  md: 'text-[15px] sm:text-[17px] leading-[1.55]',
  sm: 'text-[13px] leading-[1.6]'
};

/** Moves never break internally; lines wrap only between moves. */
export function ScrambleText({ scramble, preparing, className, size = 'lg' }: ScrambleTextProps) {
  if (!scramble) {
    return (
      <p className={twMerge('font-mono text-faint', SIZE[size], className)} aria-live="polite">
        {preparing ? 'Preparing scramble…' : '—'}
      </p>);

  }
  const moves = scramble.split(/\s+/);
  return (
    <p
      className={twMerge(
        'font-mono tracking-[0.01em] text-fg transition-opacity duration-150',
        SIZE[size],
        preparing && 'opacity-40',
        className
      )}
      aria-label={`Scramble: ${scramble}`}>
      
      {moves.map((m, i) =>
      <span key={i} className="mr-[0.55em] inline-block whitespace-nowrap">
          {m}
        </span>
      )}
    </p>);

}