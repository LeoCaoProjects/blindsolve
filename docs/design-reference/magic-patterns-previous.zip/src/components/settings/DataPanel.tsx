import React, { useRef, useState } from 'react';
import { DownloadIcon, UploadIcon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { Button } from '../ui/Button';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { SettingRow } from './SettingRow';

type Strategy = 'keep' | 'prefer' | 'replace';

interface Preview {
  file: string;
  date: string;
  lettering: string;
  buffers: string;
  pairs: number;
  newPairs: number;
  differing: number;
  alternates: number;
  solves: number;
  practice: number;
}

export function DataPanel() {
  const store = useStore();
  const fileRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState('');
  const [preview, setPreview] = useState<Preview | null>(null);
  const [invalid, setInvalid] = useState<{file: string;problems: string[];} | null>(null);
  const [strategy, setStrategy] = useState<Strategy>('keep');
  const [confirmClear, setConfirmClear] = useState(false);
  const pairCount = Object.keys(store.pairs).length;

  const exportBackup = () => {
    const data = {
      app: 'BlindSolve',
      version: 3,
      exportedAt: new Date().toISOString(),
      setup: store.setup,
      prefs: store.prefs,
      pairs: store.pairs,
      sessions: store.sessions,
      solves: store.solves,
      attempts: store.attempts,
      flashcards: store.flashHistory
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `3bld-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    setStatus('Backup saved to downloads');
  };

  const previewFrom = (name: string, obj: Record<string, unknown>): Preview => {
    const pairs = (obj.pairs ?? {}) as Record<string, unknown>;
    const keys = Object.keys(pairs);
    return {
      file: name,
      date: typeof obj.exportedAt === 'string' ? new Date(obj.exportedAt).toLocaleDateString() : 'Unknown date',
      lettering: 'Speffz',
      buffers: 'DF · UBL',
      pairs: keys.length,
      newPairs: keys.filter((k) => !store.pairs[k]).length,
      differing: keys.filter((k) => store.pairs[k] && JSON.stringify(store.pairs[k]) !== JSON.stringify(pairs[k])).length,
      alternates: 0,
      solves: Array.isArray(obj.solves) ? obj.solves.length : 0,
      practice: Array.isArray(obj.attempts) ? obj.attempts.length : 0
    };
  };

  const onFile = async (f: File) => {
    if (f.size > 25 * 1024 * 1024) return setInvalid({ file: f.name, problems: ['File is larger than 25 MB.'] });
    try {
      const obj = JSON.parse(await f.text());
      if (obj?.app !== 'BlindSolve' || obj?.version !== 3) {
        return setInvalid({ file: f.name, problems: ['Missing BlindSolve backup header or unsupported version.'] });
      }
      setStrategy('keep');
      setPreview(previewFrom(f.name, obj));
    } catch {
      setInvalid({ file: f.name, problems: ['Not valid JSON.'] });
    }
  };

  return (
    <div>
      <SettingRow label="Export backup" hint={status || 'Setup, letter pairs, solves, sessions, preferences and practice history as JSON.'}>
        <Button size="sm" variant="secondary" onClick={exportBackup}>
          <DownloadIcon className="h-3.5 w-3.5" /> Export
        </Button>
      </SettingRow>
      <SettingRow label="Import backup" hint="You’ll see what’s inside before anything changes.">
        <div className="flex items-center gap-2">
          <button
            type="button"
            className="sr-only focus:not-sr-only focus:h-8 focus:rounded-md focus:px-2 focus:text-[12.5px] focus:text-muted"
            onClick={() =>
            setPreview(
              previewFrom('Sample (current data)', { pairs: store.pairs, solves: store.solves, attempts: store.attempts, exportedAt: new Date().toISOString() })
            )
            }>
            
            Preview a sample backup
          </button>
          <Button size="sm" variant="secondary" onClick={() => fileRef.current?.click()}>
            <UploadIcon className="h-3.5 w-3.5" /> Import…
          </Button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onFile(f);
            e.target.value = '';
          }} />
        
      </SettingRow>
      <SettingRow
        label="Clear all letter pairs"
        hint={pairCount ? `${pairCount} entries. Solves and practice history are not affected.` : 'No letter pairs saved.'}>
        
        <Button size="sm" variant="danger" disabled={!pairCount} onClick={() => setConfirmClear(true)}>
          Clear all
        </Button>
      </SettingRow>

      <ConfirmDialog
        open={!!preview}
        title="Import backup"
        tone={strategy === 'replace' ? 'danger' : 'primary'}
        confirmLabel={strategy === 'replace' ? 'Replace my data' : 'Import'}
        onCancel={() => setPreview(null)}
        onConfirm={() => {
          setPreview(null);
          setStatus('Backup imported');
        }}>
        
        {preview &&
        <>
            <p className="font-mono text-[12.5px] text-fg">{preview.file}</p>
            <dl className="tnum mt-3 grid grid-cols-2 gap-x-4 gap-y-1.5 text-[13px]">
              {[
            ['Exported', preview.date],
            ['Lettering', preview.lettering],
            ['Buffers', preview.buffers],
            ['Letter pairs', `${preview.pairs} · ${preview.newPairs} new · ${preview.differing} differ`],
            ['Alternates', String(preview.alternates)],
            ['Solves', String(preview.solves)],
            ['Practice', String(preview.practice)]].
            map(([k, v]) =>
            <React.Fragment key={k}>
                  <dt className="text-faint">{k}</dt>
                  <dd className="text-fg">{v}</dd>
                </React.Fragment>
            )}
            </dl>
            <div role="radiogroup" aria-label="Import strategy" className="mt-4 space-y-1.5">
              {(
            [
            ['keep', 'Merge, keep mine where they differ'],
            ['prefer', 'Merge, use the backup where they differ'],
            ['replace', 'Replace everything with the backup']] as
            [Strategy, string][]).
            map(([id, label]) =>
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={strategy === id}
              onClick={() => setStrategy(id)}
              className={`flex w-full items-center gap-3 rounded-md border px-3 py-2.5 text-left text-[13px] ${
              strategy === id ? 'border-fg/70 bg-raised text-fg' : 'border-line text-muted hover:border-line-strong'}`
              }>
              
                  <span className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${strategy === id ? 'border-fg' : 'border-line-strong'}`}>
                    {strategy === id && <span className="h-2 w-2 rounded-full bg-fg" />}
                  </span>
                  {label}
                </button>
            )}
            </div>
          </>
        }
      </ConfirmDialog>

      <ConfirmDialog
        open={!!invalid}
        title="Can’t import this file"
        confirmLabel="Choose another file"
        cancelLabel="Close"
        tone="primary"
        onCancel={() => setInvalid(null)}
        onConfirm={() => {
          setInvalid(null);
          fileRef.current?.click();
        }}>
        
        {invalid &&
        <>
            <p className="font-mono text-[12.5px] text-fg">{invalid.file}</p>
            <p className="mt-2">This isn’t a backup from this app.</p>
            <ul className="mt-2 list-disc pl-4 text-[12.5px]">
              {invalid.problems.map((p) =>
            <li key={p}>{p}</li>
            )}
            </ul>
          </>
        }
      </ConfirmDialog>

      <ConfirmDialog
        open={confirmClear}
        title="Clear all letter pairs?"
        confirmLabel="Clear all"
        onCancel={() => setConfirmClear(false)}
        onConfirm={() => {
          store.clearAllPairs();
          setConfirmClear(false);
          setStatus('All letter pairs cleared');
        }}>
        
        Removes all {pairCount} entries — every word, alternate and edge/corner override. Timer solves and practice history stay.
      </ConfirmDialog>
    </div>);

}