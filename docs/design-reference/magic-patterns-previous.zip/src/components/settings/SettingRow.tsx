import React from 'react';

interface SettingRowProps {
  label: React.ReactNode;
  hint?: React.ReactNode;
  children?: React.ReactNode;
  changed?: boolean;
  htmlFor?: string;
  stack?: boolean;
}

export function SettingRow({ label, hint, children, changed, htmlFor, stack }: SettingRowProps) {
  const Label = htmlFor ? 'label' : 'div';
  return (
    <div className={`flex gap-x-6 gap-y-3 border-b border-line py-4 last:border-b-0 ${stack ? 'flex-col' : 'flex-wrap items-center'}`}>
      <Label {...htmlFor ? { htmlFor } : {}} className="min-w-0 flex-1">
        <span className="flex items-center gap-2 text-[14px] text-fg">
          {label}
          {changed && <span className="h-1.5 w-1.5 rounded-full bg-warn" aria-label="unsaved" />}
        </span>
        {hint && <span className="mt-0.5 block text-[12.5px] leading-snug text-muted">{hint}</span>}
      </Label>
      {children && <div className="shrink-0">{children}</div>}
    </div>);

}