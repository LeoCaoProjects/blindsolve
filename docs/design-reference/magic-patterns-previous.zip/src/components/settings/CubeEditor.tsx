import React, { useMemo, useState } from 'react';
import { ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
import { Face, FaceColor, PieceKind } from '../../types/cube';
import { SetupDraft } from '../../types/domain';
import { COLOR_NAMES, OPPOSITE, solvedState } from '../../utils/cube';
import { isSpeffz, letterIndexOf, slotKind, SPEFFZ, stickerKey, stickerName } from '../../utils/lettering';
import { viewAfterDrag } from '../../utils/view';
import { clamp, useViewport } from '../../hooks/useViewport';
import { useIsDesktop } from '../../hooks/useMediaQuery';
import { Sheet } from '../ui/Sheet';
import { Button } from '../ui/Button';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { CubeFigure } from '../cube/CubeFigure';
import { STICKER_HEX } from '../cube/Cube3D';

export type EditorMode = 'lettering' | 'edgeBuffer' | 'cornerBuffer' | 'view';

const MODES: {id: EditorMode;label: string;}[] = [
{ id: 'lettering', label: 'Lettering' },
{ id: 'edgeBuffer', label: 'Edge buffer' },
{ id: 'cornerBuffer', label: 'Corner buffer' },
{ id: 'view', label: 'Cube view' }];


const COMMON_EDGE = [
{ label: 'UF', idx: 2 },
{ label: 'DF', idx: 20 },
{ label: 'UR', idx: 1 },
{ label: 'UB', idx: 0 }];

const COMMON_CORNER = [
{ label: 'UFR', idx: 2 },
{ label: 'UBL', idx: 4 },
{ label: 'UFL', idx: 3 },
{ label: 'DFR', idx: 21 }];

const COLORS: FaceColor[] = ['W', 'Y', 'G', 'B', 'R', 'O'];

interface CubeEditorProps {
  open: boolean;
  mode: EditorMode;
  setMode: (m: EditorMode) => void;
  draft: SetupDraft;
  setDraft: (fn: (d: SetupDraft) => SetupDraft) => void;
  onClose: () => void;
}

export function CubeEditor({ open, mode, setMode, draft, setDraft, onClose }: CubeEditorProps) {
  const desktop = useIsDesktop();
  const { h } = useViewport();
  const [sel, setSel] = useState<{kind: PieceKind;idx: number;}>({ kind: 'edge', idx: 0 });
  const [rot, setRot] = useState({ x: 0, y: 0 });
  const [resetKey, setResetKey] = useState(0);
  const [confirmSpeffz, setConfirmSpeffz] = useState(false);

  const scheme = { name: draft.schemeName, edges: draft.edges, corners: draft.corners };
  const cubeSize = desktop ? clamp(h - 300, 220, 320) : clamp(Math.round(h * 0.28), 150, 220);
  const rotated = Math.abs(rot.x) > 10 || Math.abs(rot.y) > 10;
  const dragView = viewAfterDrag(draft.viewTop, draft.viewFront, rot);
  const viewChanged = rotated && (dragView.top !== draft.viewTop || dragView.front !== draft.viewFront);

  const selectedKey =
  mode === 'lettering' ?
  stickerKey(sel.kind, sel.idx) :
  mode === 'edgeBuffer' ?
  stickerKey('edge', draft.edgeBuffer) :
  mode === 'cornerBuffer' ?
  stickerKey('corner', draft.cornerBuffer) :
  null;

  const onSticker = (face: Face, index: number) => {
    const k = slotKind(index);
    if (k === 'center') return;
    const li = letterIndexOf(face, index);
    if (mode === 'lettering') setSel({ kind: k, idx: li });
    if (mode === 'edgeBuffer' && k === 'edge') setDraft((d) => ({ ...d, edgeBuffer: li }));
    if (mode === 'cornerBuffer' && k === 'corner') setDraft((d) => ({ ...d, cornerBuffer: li }));
  };

  const tokens = sel.kind === 'edge' ? draft.edges : draft.corners;
  const token = tokens[sel.idx] ?? '';
  const dupes = token ? tokens.map((t, i) => t === token && i !== sel.idx ? stickerName(sel.kind, i) : null).filter(Boolean) : [];
  const setToken = (v: string) => {
    const clean = v.toUpperCase().replace(/\s+/g, '').slice(0, 3);
    setDraft((d) => {
      const list = [...(sel.kind === 'edge' ? d.edges : d.corners)];
      list[sel.idx] = clean;
      return sel.kind === 'edge' ? { ...d, edges: list } : { ...d, corners: list };
    });
  };
  const step = (dir: number) => setSel((s) => ({ ...s, idx: (s.idx + dir + 24) % 24 }));

  const setTop = (top: FaceColor) =>
  setDraft((d) => {
    const ok = d.viewFront !== top && d.viewFront !== OPPOSITE[top];
    const front = ok ? d.viewFront : COLORS.find((c) => c !== top && c !== OPPOSITE[top])!;
    return { ...d, viewTop: top, viewFront: front };
  });

  const isClickable = (face: Face, index: number) => {
    const k = slotKind(index);
    if (mode === 'lettering') return k !== 'center';
    if (mode === 'edgeBuffer') return k === 'edge';
    if (mode === 'cornerBuffer') return k === 'corner';
    return false;
  };

  return (
    <>
      <Sheet
        open={open}
        onClose={onClose}
        title="Cube & lettering"
        variant="full"
        widthClass="md:w-[min(820px,calc(100vw_-_72px))]"
        footer={
        <div className="flex items-center gap-3">
            <span className="text-[12.5px] text-muted">Changes stay in your draft until you save.</span>
            <Button variant="primary" className="ml-auto" onClick={onClose}>
              Done
            </Button>
          </div>
        }>
        
        <div role="radiogroup" aria-label="Edit" className="grid grid-cols-2 gap-1 rounded-md border border-line bg-bg p-0.5 sm:grid-cols-4">
          {MODES.map((m) =>
          <button
            key={m.id}
            type="button"
            role="radio"
            aria-checked={mode === m.id}
            onClick={() => setMode(m.id)}
            className={`h-9 whitespace-nowrap rounded-[5px] text-[13px] font-medium transition-colors duration-150 ${
            mode === m.id ? 'bg-fg text-bg' : 'text-muted hover:text-fg'}`
            }>
            
              {m.label}
            </button>
          )}
        </div>

        <div className="mt-4 grid gap-6 md:mt-6 md:grid-cols-[auto_1fr] md:gap-10">
          <div className="flex flex-col items-center">
            <CubeFigure
              state={solvedState()}
              scheme={scheme}
              labelFor={(f, i) => {
                const k = slotKind(i);
                if (k === 'center') return undefined;
                return (k === 'edge' ? draft.edges : draft.corners)[letterIndexOf(f, i)] || '·';
              }}
              viewTop={draft.viewTop}
              viewFront={draft.viewFront}
              size={cubeSize}
              showLabels={mode !== 'view'}
              selected={selectedKey}
              onSticker={mode === 'view' ? undefined : onSticker}
              isClickable={isClickable}
              resetKey={resetKey}
              onRotate={setRot}
              label="Configurator cube. Drag to rotate, select a sticker." />
            
            {rotated &&
            <button
              type="button"
              onClick={() => {
                setRot({ x: 0, y: 0 });
                setResetKey((k) => k + 1);
              }}
              className="h-8 text-[12.5px] text-muted hover:text-fg">
              
                Reset rotation
              </button>
            }
          </div>

          <div className="min-w-0">
            {mode === 'lettering' &&
            <div className="space-y-6">
                <div>
                  <p className="text-[12px] font-medium text-faint">
                    {sel.kind === 'edge' ? 'Edge' : 'Corner'} sticker · Speffz {SPEFFZ[sel.idx]}
                  </p>
                  <div className="mt-1 flex items-end gap-4">
                    <span className="font-mono text-[28px] font-medium leading-none text-fg">{stickerName(sel.kind, sel.idx)}</span>
                  </div>
                </div>
                <div className="flex items-end gap-3">
                  <label className="block">
                    <span className="text-[12px] font-medium text-faint">Token</span>
                    <input
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === 'Tab') {
                        e.preventDefault();
                        step(e.shiftKey ? -1 : 1);
                      }
                    }}
                    maxLength={3}
                    autoCapitalize="characters"
                    spellCheck={false}
                    aria-describedby="token-info"
                    className="mt-1 h-14 w-28 rounded-md border border-line-strong bg-bg text-center font-mono text-[28px] font-medium uppercase text-fg focus:border-signal focus:outline-none" />
                  
                  </label>
                  <div className="flex gap-1 pb-2">
                    <Button size="icon" variant="secondary" aria-label="Previous sticker" onClick={() => step(-1)}>
                      <ChevronLeftIcon className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="secondary" aria-label="Next sticker" onClick={() => step(1)}>
                      <ChevronRightIcon className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <p id="token-info" className="-mt-3 text-[12.5px] text-muted" aria-live="polite">
                  {!token ? 'Unlabelled' : dupes.length ? `Also on ${dupes.join(', ')}` : 'Up to 3 characters. Enter or Tab moves on.'}
                </p>
                {!isSpeffz(draft) &&
              <label className="block">
                    <span className="text-[12px] font-medium text-faint">Scheme name</span>
                    <input
                  value={draft.schemeName === 'Speffz' ? '' : draft.schemeName}
                  onChange={(e) => setDraft((d) => ({ ...d, schemeName: e.target.value }))}
                  placeholder="Custom"
                  className="mt-1 h-10 w-full max-w-xs rounded-md border border-line bg-bg px-3 text-[14px] text-fg placeholder:text-faint focus:border-line-strong focus:outline-none" />
                
                  </label>
              }
                <Button variant="secondary" size="sm" disabled={isSpeffz(draft)} onClick={() => setConfirmSpeffz(true)}>
                  Use Speffz
                </Button>
              </div>
            }

            {(mode === 'edgeBuffer' || mode === 'cornerBuffer') &&
            <BufferControls
              kind={mode === 'edgeBuffer' ? 'edge' : 'corner'}
              value={mode === 'edgeBuffer' ? draft.edgeBuffer : draft.cornerBuffer}
              token={(mode === 'edgeBuffer' ? draft.edges : draft.corners)[mode === 'edgeBuffer' ? draft.edgeBuffer : draft.cornerBuffer]}
              method={mode === 'edgeBuffer' ? draft.edgeMethod : 'OP'}
              onChange={(idx) => setDraft((d) => mode === 'edgeBuffer' ? { ...d, edgeBuffer: idx } : { ...d, cornerBuffer: idx })} />

            }

            {mode === 'view' &&
            <div className="space-y-6">
                <ColorPick label="Top" value={draft.viewTop} onChange={setTop} />
                <ColorPick
                label="Front"
                value={draft.viewFront}
                onChange={(c) => setDraft((d) => ({ ...d, viewFront: c }))}
                disabled={(c) => c === draft.viewTop || c === OPPOSITE[draft.viewTop]} />
              
                <div className="flex flex-wrap gap-2">
                  <Button
                  variant="secondary"
                  size="sm"
                  disabled={!viewChanged}
                  onClick={() => {
                    setDraft((d) => ({ ...d, viewTop: dragView.top, viewFront: dragView.front }));
                    setRot({ x: 0, y: 0 });
                    setResetKey((k) => k + 1);
                  }}>
                  
                    Use this view
                  </Button>
                  {(draft.viewTop !== 'W' || draft.viewFront !== 'G') &&
                <Button variant="ghost" size="sm" onClick={() => setDraft((d) => ({ ...d, viewTop: 'W', viewFront: 'G' }))}>
                      Back to white top, green front
                    </Button>
                }
                </div>
                <p className="text-[12.5px] leading-relaxed text-muted">
                  Changes how cubes are drawn. Scrambles are always read white top, green front.
                </p>
              </div>
            }
          </div>
        </div>
      </Sheet>
      <ConfirmDialog
        open={confirmSpeffz}
        title="Replace lettering with Speffz?"
        confirmLabel="Use Speffz"
        onCancel={() => setConfirmSpeffz(false)}
        onConfirm={() => {
          setDraft((d) => ({ ...d, edges: [...SPEFFZ], corners: [...SPEFFZ], schemeName: 'Speffz' }));
          setConfirmSpeffz(false);
        }}>
        
        Overwrites every custom sticker label in your draft. Saved letter pairs are kept.
      </ConfirmDialog>
    </>);

}

function BufferControls({
  kind,
  value,
  token,
  method,
  onChange






}: {kind: PieceKind;value: number;token: string | undefined;method: 'M2' | 'OP';onChange: (i: number) => void;}) {
  const common = kind === 'edge' ? COMMON_EDGE : COMMON_CORNER;
  const recommend = kind === 'edge' ? method === 'OP' && value !== 3 ? { label: 'UL', idx: 3 } : null : value !== 4 ? { label: 'UBL', idx: 4 } : null;
  return (
    <div className="space-y-6">
      <div>
        <p className="text-[12px] font-medium text-faint">{kind === 'edge' ? 'Edge' : 'Corner'} buffer</p>
        <p className="mt-1 flex items-baseline gap-3">
          <span className="font-mono text-[28px] font-medium leading-none text-fg">{stickerName(kind, value)}</span>
          <span className="text-[13px] text-muted">
            sticker on {stickerName(kind, value)[0]} · token <span className="font-mono text-fg">{token || '—'}</span>
          </span>
        </p>
        <p className="mt-2 text-[12.5px] text-muted">Select a {kind} sticker on the cube. The sticker’s face matters.</p>
      </div>
      <div>
        <p className="mb-2 text-[12px] font-medium text-faint">Common</p>
        <div className="flex flex-wrap gap-1.5">
          {common.map((c) =>
          <button
            key={c.label}
            type="button"
            aria-pressed={value === c.idx}
            onClick={() => onChange(c.idx)}
            className={`h-9 rounded-md border px-3 font-mono text-[13.5px] transition-colors duration-150 ${
            value === c.idx ? 'border-fg bg-fg text-bg' : 'border-line text-fg hover:border-line-strong'}`
            }>
            
              {c.label}
            </button>
          )}
        </div>
      </div>
      {recommend &&
      <p className="text-[13px] text-muted">
          OP usually uses {recommend.label}.{' '}
          <button type="button" onClick={() => onChange(recommend.idx)} className="text-fg underline underline-offset-4">
            Use {recommend.label}
          </button>
        </p>
      }
    </div>);

}

function ColorPick({
  label,
  value,
  onChange,
  disabled





}: {label: string;value: FaceColor;onChange: (c: FaceColor) => void;disabled?: (c: FaceColor) => boolean;}) {
  return (
    <div>
      <p className="mb-2 text-[12px] font-medium text-faint">{label}</p>
      <div role="radiogroup" aria-label={`${label} face colour`} className="flex flex-wrap gap-2">
        {COLORS.map((c) => {
          const off = disabled?.(c);
          const on = value === c;
          return (
            <button
              key={c}
              type="button"
              role="radio"
              aria-checked={on}
              aria-label={COLOR_NAMES[c]}
              title={COLOR_NAMES[c]}
              disabled={off}
              onClick={() => onChange(c)}
              className={`h-9 w-9 rounded-md transition-[box-shadow,opacity] duration-150 disabled:cursor-not-allowed disabled:opacity-20 ${
              on ? 'shadow-[0_0_0_2px_#0C0D0E,0_0_0_4px_#ECEAE4]' : ''}`
              }
              style={{ background: STICKER_HEX[c] }} />);


        })}
      </div>
    </div>);

}