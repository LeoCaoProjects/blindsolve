import React, { useState } from 'react';
import { Loader2Icon, RefreshCwIcon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { useSignInFlow } from '../../hooks/useSignInFlow';
import { Button } from '../ui/Button';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { ProviderButtons } from '../auth/ProviderButtons';
import { MigrationDialog } from '../auth/MigrationDialog';

export function AccountPanel() {
  const store = useStore();
  const flow = useSignInFlow();
  const [confirmOut, setConfirmOut] = useState(false);
  const { account } = store;

  if (account.mode === 'unconfigured') {
    return (
      <div className="py-4">
        <p className="flex items-center gap-2 text-[14px] text-fg">
          <span className="rounded border border-line-strong px-1.5 py-0.5 font-mono text-[11px] text-muted">Local</span>
          This deployment has no sign-in.
        </p>
        <p className="mt-1 text-[12.5px] text-muted">Everything you save stays on this device.</p>
      </div>);

  }

  if (account.mode === 'guest') {
    return (
      <div className="grid gap-5 py-4 md:grid-cols-[1fr_280px] md:gap-10">
        <div>
          <p className="text-[14px] text-fg">Sign in to sync</p>
          <p className="mt-1 text-[12.5px] leading-relaxed text-muted">
            Letter pairs, solves, practice and setup follow you across devices. Until then everything stays on this device.
          </p>
        </div>
        <ProviderButtons pending={flow.pending} onStart={flow.start} onCancel={flow.cancel} />
        <MigrationDialog open={flow.migrating} onDone={flow.finishMigration} />
      </div>);

  }

  const initials = account.name.
  split(' ').
  map((p) => p[0]).
  join('').
  slice(0, 2);
  const detail = account.provider === 'WCA' ? account.detail : 'leo.cao@gmail.com';

  return (
    <div className="py-2">
      <div className="flex items-center gap-3 border-b border-line py-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-raised text-[13px] font-semibold text-fg">{initials}</span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[14px] font-medium text-fg">{account.name}</p>
          <p className="truncate font-mono text-[12.5px] text-muted">
            {detail} <span className="font-sans text-faint">· {account.provider === 'WCA' ? 'WCA account' : 'Google'}</span>
          </p>
        </div>
        <Button size="sm" variant="ghost" onClick={() => setConfirmOut(true)}>
          Sign out
        </Button>
      </div>

      <div className="py-3" aria-live="polite">
        {account.sync === 'synced' &&
        <p className="flex items-center gap-2 text-[13px] text-muted">
            <span className="h-2 w-2 rounded-full bg-signal" /> Synced <span className="text-faint">· last tried {account.lastTried}</span>
          </p>
        }
        {account.sync === 'saving' &&
        <p className="flex items-center gap-2 text-[13px] text-muted">
            <Loader2Icon className="h-3.5 w-3.5 animate-spin" /> Saving…
          </p>
        }
        {account.sync === 'offline' &&
        <p className="flex items-start gap-2 text-[13px] text-muted">
            <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-warn" /> Offline — changes are kept here and sync when you reconnect.
          </p>
        }
        {account.sync === 'failed' &&
        <div role="alert" className="flex flex-wrap items-start gap-x-4 gap-y-2">
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-2 text-[13px] text-fg">
                <span className="h-2 w-2 rounded-full bg-danger" /> Sync failed <span className="text-faint">· last tried {account.lastTried}</span>
              </p>
              <p className="mt-1 font-mono text-[12px] text-muted">Request timed out (504). Your changes are still on this device.</p>
            </div>
            <Button size="sm" variant="secondary" onClick={store.retrySync}>
              <RefreshCwIcon className="h-3.5 w-3.5" /> Retry
            </Button>
          </div>
        }
      </div>

      <ConfirmDialog
        open={confirmOut}
        title="Sign out?"
        confirmLabel="Sign out"
        tone="primary"
        onCancel={() => setConfirmOut(false)}
        onConfirm={() => {
          store.signOut();
          setConfirmOut(false);
        }}>
        
        Your account’s data stays saved to your account. This device switches to its own guest workspace.
      </ConfirmDialog>
    </div>);

}