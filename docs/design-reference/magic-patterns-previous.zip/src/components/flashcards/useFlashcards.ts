import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useStore } from '../../contexts/AppStore';
import { effectiveWords, hasOverride, normalizeWords, splitKey } from '../../utils/pairs';
import { uid } from '../../utils/dom';

/** PRESENTATION MIRROR of production useFlashcards: eligibility, uniform draw, self-report. */

export interface Variant {
  key: string;
  kind: 'edge' | 'corner';
}
export type CardPhase = 'question' | 'revealed' | 'editing' | 'adding';

export function useFlashcards() {
  const store = useStore();
  const variants = useMemo(() => {
    const out: Variant[] = [];
    Object.keys(store.pairs).forEach((key) => {
      const [a, b] = splitKey(key);
      if (a === b) return;
      (['edge', 'corner'] as const).forEach((kind) => {
        const tokens = kind === 'edge' ? store.scheme.edges : store.scheme.corners;
        if (!tokens.includes(a) || !tokens.includes(b)) return;
        if (effectiveWords(store.pairs[key], kind === 'edge' ? 'edges' : 'corners').length) out.push({ key, kind });
      });
    });
    return out;
  }, [store.pairs, store.scheme]);

  const cardCount = useMemo(() => {
    const seen = new Set<string>();
    variants.forEach((v) => {
      const words = effectiveWords(store.pairs[v.key], v.kind === 'edge' ? 'edges' : 'corners');
      seen.add(`${v.key}::${words.map((w) => w.toLowerCase()).join(',')}`);
    });
    return seen.size;
  }, [variants, store.pairs]);

  const draw = useCallback(
    (prev?: Variant | null): Variant | null => {
      if (!variants.length) return null;
      const pool = variants.length > 1 && prev ? variants.filter((v) => !(v.key === prev.key && v.kind === prev.kind)) : variants;
      return pool[Math.floor(Math.random() * pool.length)];
    },
    [variants]
  );

  const [card, setCard] = useState<Variant | null>(() => draw(null));
  const [phase, setPhase] = useState<CardPhase>('question');
  const shownAt = useRef(performance.now());

  const show = (v: Variant | null, p: CardPhase = 'question') => {
    setCard(v);
    setPhase(p);
    shownAt.current = performance.now();
  };

  // initial draw + invalidation when the current card stops being eligible
  useEffect(() => {
    const valid = card && variants.some((v) => v.key === card.key && v.kind === card.kind);
    if (!valid && phase !== 'editing' && phase !== 'adding') show(draw(card));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [variants]);

  const ctx = card?.kind === 'edge' ? 'edges' : 'corners';
  const words = card ? effectiveWords(store.pairs[card.key], ctx) : [];
  const settled = () => performance.now() - shownAt.current > 220;

  const reveal = () => phase === 'question' && settled() && setPhase('revealed');
  const answer = (outcome: 'remembered' | 'forgot') => {
    if (!card || phase !== 'revealed' || !settled()) return;
    store.addFlash({ id: uid('f'), key: card.key, kind: card.kind, word: words[0] ?? '', outcome });
    show(draw(card));
  };

  const writeSource = (next: (list: string[]) => string[]) => {
    if (!card) return;
    const entry = store.pairs[card.key];
    if (!entry) return;
    const source = hasOverride(entry, ctx) ? ctx : 'shared';
    store.savePair(card.key, { ...entry, [source]: normalizeWords(next(entry[source] as string[] ?? [])) });
  };

  return {
    variants,
    cardCount,
    card,
    phase,
    setPhase,
    words,
    reveal,
    answer,
    savePrimary: (w: string) => {
      if (w.trim()) writeSource((l) => [w.trim(), ...l.slice(1)]);
      setPhase('revealed');
    },
    addAlternate: (w: string) => {
      if (w.trim()) writeSource((l) => [...l, w.trim()]);
      setPhase('revealed');
    },
    openRevealed: (v: Variant) => show(v, 'revealed')
  };
}