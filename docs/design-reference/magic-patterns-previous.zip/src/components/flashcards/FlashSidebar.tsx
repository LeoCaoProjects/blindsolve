import React, { useMemo } from 'react';
import { Trash2Icon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { solvedState } from '../../utils/cube';
import { splitKey } from '../../utils/pairs';
import { stickerKey, tokenIndex } from '../../utils/lettering';
import { CubeFigure } from '../cube/CubeFigure';
import { Variant } from './useFlashcards';

interface FlashSidebarProps {
  card: Variant | null;
  onOpen: (v: Variant) => void;
  onAskClear: () => void;
  cubeSize?: number;
}

/** Where the tokens sit, counters and recent cards. Same content on every screen size. */
export function FlashSidebar({ card, onOpen, onAskClear, cubeSize = 168 }: FlashSidebarProps) {
  const store = useStore();
  const recent = [...store.flashHistory].reverse();
  const highlights = useMemo(() => {
    if (!card) return undefined;
    const [a, b] = splitKey(card.key);
    const out = new Set<string>();
    [a, b].forEach((t) => {
      const i = tokenIndex(store.scheme, card.kind, t);
      if (i >= 0) out.add(stickerKey(card.kind, i));
    });
    return out;
  }, [card, store.scheme]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex justify-center">
        <CubeFigure
          state={solvedState()}
          scheme={store.scheme}
          viewTop={store.setup.viewTop}
          viewFront={store.setup.viewFront}
          size={cubeSize}
          showLabels
          highlights={highlights}
          label="Where this pair’s stickers sit" />
        
      </div>
      <dl className="mt-4 grid grid-cols-3 gap-3 border-y border-line py-3">
        <Stat label="Seen" value={store.flashCounts.seen} />
        <Stat label="Remembered" value={store.flashCounts.remembered} />
        <Stat label="Forgot" value={store.flashCounts.forgot} />
      </dl>
      <h3 className="mb-1 mt-4 text-[12px] font-medium text-faint">Recent</h3>
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
        {recent.length === 0 ?
        <p className="py-4 text-[13px] text-faint">No cards answered yet</p> :

        <ol className="-mx-2">
            {recent.map((r) => {
            const [a, b] = splitKey(r.key);
            return (
              <li key={r.id} className="group flex items-center rounded-md hover:bg-raised">
                  <button
                  type="button"
                  onClick={() => onOpen({ key: r.key, kind: r.kind })}
                  className="flex h-10 min-w-0 flex-1 items-center gap-3 px-2 text-left">
                  
                    <span className="w-9 font-mono text-[14px] tracking-[0.06em] text-fg">
                      {a}
                      {b}
                    </span>
                    <span className="min-w-0 truncate font-serif text-[15px] italic text-muted">{r.word}</span>
                    <span className={`ml-auto shrink-0 text-[11.5px] ${r.outcome === 'forgot' ? 'text-danger' : 'text-faint'}`}>
                      {r.outcome === 'forgot' ? 'Forgot' : 'Remembered'}
                    </span>
                  </button>
                  <button
                  type="button"
                  aria-label={`Remove ${a}${b} from history`}
                  onClick={() => store.deleteFlash(r.id)}
                  className="mr-1 flex h-8 w-8 items-center justify-center rounded-md text-faint opacity-0 hover:text-danger focus-visible:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100">
                  
                    <Trash2Icon className="h-3.5 w-3.5" />
                  </button>
                </li>);

          })}
          </ol>
        }
      </div>
      <div className="mt-2 border-t border-line pt-2">
        <button
          type="button"
          disabled={recent.length === 0}
          onClick={onAskClear}
          className="h-8 rounded-md px-2 text-[12.5px] text-faint hover:text-danger disabled:pointer-events-none disabled:opacity-40">
          
          Clear history
        </button>
      </div>
    </div>);

}

function Stat({ label, value }: {label: string;value: number;}) {
  return (
    <div>
      <dt className="text-[11.5px] text-faint">{label}</dt>
      <dd className="tnum mt-0.5 font-mono text-[15px] text-fg">{value}</dd>
    </div>);

}