import React from 'react';
import { SampleTarget } from '../../data/trainingSamples';
import { PairDB } from '../../types/domain';
import { PieceKey, toPairs } from '../../utils/training';

/** Review list: each pair with its effective word, cycle breaks underlined. */
export function ReviewMemo({ rows, pairs }: {rows: {piece: PieceKey;targets: SampleTarget[];}[];pairs?: PairDB;}) {
  return (
    <div className="grid gap-6 sm:grid-cols-2">
      {rows.map(({ piece, targets }) =>
      <div key={piece}>
          <h4 className="mb-1.5 text-[12px] font-medium text-faint">{piece === 'corners' ? 'Corners' : 'Edges'}</h4>
          <ul className="grid grid-cols-[3rem_1fr] gap-x-3 gap-y-1">
            {toPairs(targets, piece, pairs).map((p, i) =>
          <li key={i} className="contents">
                <span className="font-mono text-[15px] tracking-[0.06em] text-fg">
                  {p.tokens.map((t, k) =>
              <span key={k} className={t.isBreak ? 'underline decoration-signal decoration-2 underline-offset-[5px]' : ''}>
                      {t.token}
                    </span>
              )}
                </span>
                <span className="truncate text-[15px]">
                  {p.tokens.length === 2 && (
              p.word ? <span className="font-serif italic text-fg">{p.word}</span> : <span className="text-faint">—</span>)}
                </span>
              </li>
          )}
          </ul>
        </div>
      )}
    </div>);

}