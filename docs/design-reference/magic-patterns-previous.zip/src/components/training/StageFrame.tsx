import React from 'react';

interface StageFrameProps {
  children: React.ReactNode;
  footer?: React.ReactNode;
  surface?: Partial<React.HTMLAttributes<HTMLDivElement>>;
  label: string;
}

/** Scrollable stage with a footer that never scrolls away (TRN-22). */
export function StageFrame({ children, footer, surface, label }: StageFrameProps) {
  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div
        aria-label={label}
        {...surface}
        className={`min-h-0 flex-1 overflow-y-auto overscroll-contain ${surface ? 'touch-manipulation select-none' : ''}`}>
        
        <div className="flex min-h-full flex-col px-4 pb-6 pt-4 md:px-10 md:pt-6">{children}</div>
      </div>
      {footer &&
      <div className="flex shrink-0 items-center gap-2 border-t border-line px-4 py-3 md:px-10">{footer}</div>
      }
    </div>);

}