import React, { useEffect, useState } from 'react';
import { Trash2Icon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { useTraining } from '../../contexts/TrainingContext';
import { trainingModes } from '../../data/trainingModes';
import { formatMs } from '../../utils/time';
import { drillStats } from '../../utils/training';
import { isTypingTarget, overlayOpen } from '../../utils/dom';
import { ConfirmDialog } from '../ui/ConfirmDialog';

/** Per-drill stats + newest-first attempts. Also owns the drill cleanup shortcuts. */
export function TrainingHistory({ listenKeys = false }: {listenKeys?: boolean;}) {
  const store = useStore();
  const { mode, drills } = useTraining();
  const info = trainingModes.find((m) => m.id === mode)!;
  const list = store.attempts.filter((a) => a.mode === mode).sort((a, b) => b.date.localeCompare(a.date));
  const stats = drillStats(list);
  const [confirm, setConfirm] = useState<'latest' | 'clear' | null>(null);
  const idle = drills[mode].phase === 'idle';

  useEffect(() => {
    if (!listenKeys) return;
    const onKey = (e: KeyboardEvent) => {
      if (!idle || isTypingTarget(e.target) || overlayOpen() || list.length === 0) return;
      if (e.key === 'Backspace' || e.key === 'Delete') {
        e.preventDefault();
        setConfirm(e.shiftKey ? 'clear' : 'latest');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [listenKeys, idle, list.length]);

  const successLabel = mode === 'recall' || mode === 'trace' ? 'Correct' : 'Solved';

  return (
    <div className="flex h-full min-h-0 flex-col">
      <dl className="grid grid-cols-3 gap-3 border-b border-line pb-3">
        <div>
          <dt className="text-[11.5px] text-faint">Attempts</dt>
          <dd className="tnum mt-0.5 font-mono text-[15px] text-fg">{stats.count}</dd>
        </div>
        <div>
          <dt className="text-[11.5px] text-faint">{successLabel}</dt>
          <dd className="tnum mt-0.5 font-mono text-[15px] text-fg">{stats.count ? `${stats.ok}/${stats.count}` : '—'}</dd>
        </div>
        <div>
          <dt className="whitespace-nowrap text-[11.5px] text-faint">{info.meanLabel}</dt>
          <dd className="tnum mt-0.5 font-mono text-[15px] text-fg">{stats.mean !== null ? formatMs(stats.mean) : '—'}</dd>
        </div>
      </dl>

      <div className="mt-2 min-h-0 flex-1 overflow-y-auto overscroll-contain">
        {list.length === 0 ?
        <p className="py-6 text-[13px] text-faint">No attempts yet</p> :

        <ol className="-mx-2">
            {list.map((a, i) =>
          <li key={a.id} className="group flex h-10 items-center gap-3 rounded-md px-2 hover:bg-raised">
                <span className="tnum w-6 font-mono text-[12px] text-faint">{list.length - i}</span>
                <span className="tnum font-mono text-[14px] text-fg">{formatMs(a.durationMs)}</span>
                <span className="text-[11.5px] text-faint">{a.scope === 'both' ? '' : a.scope === 'edges' ? 'Edges' : 'Corners'}</span>
                <span className={`tnum ml-auto font-mono text-[12.5px] ${a.success ? 'text-muted' : 'text-danger'}`}>
                  {a.correct !== undefined ? `${a.correct}/${a.total}` : a.success ? '✓' : 'DNF'}
                </span>
                <button
              type="button"
              aria-label={`Delete attempt ${list.length - i}`}
              onClick={() => store.deleteAttempt(a.id)}
              className="flex h-8 w-8 items-center justify-center rounded-md text-faint opacity-0 hover:text-danger focus-visible:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100">
              
                  <Trash2Icon className="h-3.5 w-3.5" />
                </button>
              </li>
          )}
          </ol>
        }
      </div>
      <div className="mt-2 border-t border-line pt-2">
        <button
          type="button"
          disabled={list.length === 0 || !idle}
          onClick={() => setConfirm('clear')}
          className="h-8 rounded-md px-2 text-[12.5px] text-faint hover:text-danger disabled:pointer-events-none disabled:opacity-40">
          
          Clear {info.short} history
        </button>
      </div>

      <ConfirmDialog
        open={confirm === 'latest'}
        title="Delete latest attempt?"
        confirmLabel="Delete"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          if (list[0]) store.deleteAttempt(list[0].id);
          setConfirm(null);
        }}>
        
        {list[0] && `${info.name} · ${formatMs(list[0].durationMs)}`}
      </ConfirmDialog>
      <ConfirmDialog
        open={confirm === 'clear'}
        title={`Clear ${info.name} history?`}
        confirmLabel="Clear all"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          store.clearAttempts(mode);
          setConfirm(null);
        }}>
        
        Removes all {list.length} {info.name} attempts. Other drills keep their history.
      </ConfirmDialog>
    </div>);

}