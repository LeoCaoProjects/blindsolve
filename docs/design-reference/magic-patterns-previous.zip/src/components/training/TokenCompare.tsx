import React from 'react';
import { compareTokens } from '../../utils/training';

const COLOR = {
  correct: 'text-fg',
  wrong: 'text-danger',
  missing: 'text-faint',
  extra: 'text-warn'
};

/** Position-based expected vs. typed comparison (not edit-distance). */
export function TokenCompare({ label, expected, yours }: {label: string;expected: string[];yours: string[];}) {
  const cmp = compareTokens(expected, yours);
  const allOk = cmp.every((c) => c.status === 'correct');
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <h4 className="text-[12px] font-medium text-faint">{label}</h4>
        <span className={`text-[12px] ${allOk ? 'text-signal' : 'text-muted'}`}>
          {allOk ? 'All correct' : `${cmp.filter((c) => c.status === 'correct').length}/${expected.length}`}
        </span>
      </div>
      {!allOk &&
      <div className="overflow-x-auto">
          <table className="font-mono text-[16px]">
            <tbody>
              <tr>
                <th scope="row" className="pr-4 text-left font-sans text-[11.5px] font-normal text-faint">
                  Expected
                </th>
                {cmp.map((c, i) =>
              <td key={i} className={`w-7 text-center text-muted ${i % 2 === 1 ? 'pr-2' : ''}`}>
                    {c.e ?? ''}
                  </td>
              )}
              </tr>
              <tr>
                <th scope="row" className="pr-4 text-left font-sans text-[11.5px] font-normal text-faint">
                  Yours
                </th>
                {cmp.map((c, i) =>
              <td key={i} className={`w-7 text-center ${COLOR[c.status]} ${i % 2 === 1 ? 'pr-2' : ''}`} title={c.status}>
                    {c.y ?? '·'}
                  </td>
              )}
              </tr>
            </tbody>
          </table>
        </div>
      }
      {allOk &&
      <p className="font-mono text-[16px] tracking-[0.06em] text-fg">
          {expected.map((t, i) =>
        <span key={i}>
              {t}
              {i % 2 === 1 ? ' ' : ''}
            </span>
        )}
        </p>
      }
    </div>);

}