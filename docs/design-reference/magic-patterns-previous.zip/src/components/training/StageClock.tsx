import React, { useEffect, useState } from 'react';
import { formatMs } from '../../utils/time';

/** Live training clock. Training clocks always show numbers (Show Live Timer applies to Timer only). */
export function StageClock({ from, to, className = '' }: {from: number;to?: number | null;className?: string;}) {
  const running = to === null || to === undefined;
  const [now, setNow] = useState(performance.now());
  useEffect(() => {
    if (!running) return;
    let raf = 0;
    const tick = () => {
      setNow(performance.now());
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [running]);
  const ms = (running ? now : to as number) - from;
  return <span className={`tnum font-mono ${className}`}>{formatMs(Math.max(0, ms))}</span>;
}