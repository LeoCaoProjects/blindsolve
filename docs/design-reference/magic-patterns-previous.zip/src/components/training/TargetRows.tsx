import React from 'react';
import { SampleTarget } from '../../data/trainingSamples';
import { PairDB } from '../../types/domain';
import { PieceKey, toPairs } from '../../utils/training';

interface TargetRowsProps {
  rows: {piece: PieceKey;targets: SampleTarget[];}[];
  display?: 'letters' | 'words';
  pairs?: PairDB;
  size?: 'xl' | 'md';
}

/** Memo presented to read: letter pairs or effective words (letters as fallback). */
export function TargetRows({ rows, display = 'letters', pairs, size = 'xl' }: TargetRowsProps) {
  const letterCls = size === 'xl' ? 'text-[26px] md:text-[34px] short:md:text-[28px]' : 'text-[17px]';
  const wordCls = size === 'xl' ? 'text-[24px] md:text-[32px] short:md:text-[26px]' : 'text-[16px]';
  return (
    <div className={size === 'xl' ? 'space-y-5 md:space-y-7' : 'space-y-3'}>
      {rows.map(({ piece, targets }) =>
      <div key={piece}>
          <h3 className="mb-1.5 text-[12px] font-medium text-faint">{piece === 'corners' ? 'Corners' : 'Edges'}</h3>
          {targets.length === 0 ?
        <p className="text-[13px] text-faint">Solved</p> :

        <p className="flex flex-wrap items-baseline gap-x-5 gap-y-2 md:gap-x-7">
              {toPairs(targets, piece, pairs).map((p, i) => {
            const useWord = display === 'words' && p.word && p.tokens.length === 2;
            return useWord ?
            <span key={i} className={`font-serif italic leading-tight text-fg ${wordCls}`}>
                    {p.word}
                  </span> :

            <span key={i} className={`whitespace-nowrap font-mono font-medium leading-tight tracking-[0.06em] text-fg ${letterCls}`}>
                    {p.tokens.map((t, k) =>
              <span key={k} className={t.isBreak ? 'underline decoration-signal decoration-2 underline-offset-[6px]' : ''}>
                        {t.token}
                      </span>
              )}
                  </span>;

          })}
            </p>
        }
        </div>
      )}
    </div>);

}