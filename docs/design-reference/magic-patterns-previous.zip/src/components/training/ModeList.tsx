import React from 'react';
import { trainingModes } from '../../data/trainingModes';
import { useTraining } from '../../contexts/TrainingContext';

export function ModeList({ onPicked }: {onPicked?: () => void;}) {
  const { mode, setMode, busy } = useTraining();
  return (
    <div role="radiogroup" aria-label="Drill" aria-disabled={busy || undefined} className="flex flex-col gap-0.5">
      {trainingModes.map((m) => {
        const on = m.id === mode;
        return (
          <button
            key={m.id}
            type="button"
            role="radio"
            aria-checked={on}
            disabled={busy && !on}
            onClick={() => {
              setMode(m.id);
              onPicked?.();
            }}
            className={`rounded-md px-3 py-2.5 text-left transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-35 ${
            on ? 'bg-raised' : 'hover:bg-raised/60'}`
            }>
            
            <span className={`block text-[14px] font-medium ${on ? 'text-fg' : 'text-muted'}`}>{m.name}</span>
            <span className="mt-0.5 block text-[12.5px] leading-snug text-faint">{m.line}</span>
          </button>);

      })}
    </div>);

}