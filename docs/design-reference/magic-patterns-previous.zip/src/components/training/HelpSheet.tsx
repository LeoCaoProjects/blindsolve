import React from 'react';
import { trainingModes } from '../../data/trainingModes';
import { useTraining } from '../../contexts/TrainingContext';
import { Sheet } from '../ui/Sheet';

export function HelpSheet({ open, onClose }: {open: boolean;onClose: () => void;}) {
  const { mode } = useTraining();
  const info = trainingModes.find((m) => m.id === mode)!;
  return (
    <Sheet open={open} onClose={onClose} title={info.name} meta={info.line} widthClass="md:w-[400px]">
      <ol className="space-y-4">
        {info.help.map((step, i) =>
        <li key={i} className="grid grid-cols-[1.5rem_1fr] gap-2">
            <span className="tnum font-mono text-[13px] text-faint">{i + 1}</span>
            <span className="text-[14px] leading-relaxed text-fg">{step}</span>
          </li>
        )}
      </ol>
    </Sheet>);

}