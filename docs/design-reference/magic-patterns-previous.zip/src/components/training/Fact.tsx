import React from 'react';

export function Fact({ label, value, tone }: {label: string;value: string;tone?: 'danger' | 'signal';}) {
  return (
    <div>
      <dt className="font-sans text-[11.5px] text-faint">{label}</dt>
      <dd className={tone === 'danger' ? 'text-danger' : tone === 'signal' ? 'text-signal' : 'text-fg'}>{value}</dd>
    </div>);

}