import React from 'react';
import { DrillState } from '../../contexts/TrainingContext';
import { TrainingMode } from '../../types/domain';
import { formatMs } from '../../utils/time';
import { StageClock } from './StageClock';

/** Header clocks that replace setup controls while a drill is busy. */
export function DrillClocks({ mode, s }: {mode: TrainingMode;s: DrillState;}) {
  const cls = 'text-[15px] md:text-[17px] text-fg';
  const label = (t: string) => <span className="mr-1.5 font-sans text-[11.5px] text-faint">{t}</span>;

  if (mode === 'guided' && s.phase === 'memo') return <span>{label('Memo')}<StageClock from={s.t0} className={cls} /></span>;
  if (mode === 'guided' && (s.phase === 'exec' || s.phase === 'report'))
  return (
    <span className="flex gap-4">
        <span>
          {label('Memo')}
          <span className={`tnum font-mono ${cls} text-muted`}>{formatMs((s.t1 ?? s.t0) - s.t0)}</span>
        </span>
        <span>
          {label('Exec')}
          <StageClock from={s.t1 ?? s.t0} to={s.phase === 'report' ? s.t2 : null} className={cls} />
        </span>
      </span>);

  if (mode === 'recall' && s.phase === 'study') return <span>{label('Memo')}<StageClock from={s.t0} className={cls} /></span>;
  if (mode === 'recall' && s.phase === 'recall')
  return (
    <span className="flex gap-4">
        <span>
          {label('Memo')}
          <span className={`tnum font-mono ${cls} text-muted`}>{formatMs((s.t1 ?? s.t0) - s.t0)}</span>
        </span>
        <span>
          {label('Recall')}
          <StageClock from={s.t1 ?? s.t0} className={cls} />
        </span>
      </span>);

  if (mode === 'trace' && s.phase === 'active') return <span>{label('Trace')}<StageClock from={s.t0} className={cls} /></span>;
  return null;
}