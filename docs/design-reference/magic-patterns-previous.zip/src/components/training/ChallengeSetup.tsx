import React, { useMemo } from 'react';
import { RefreshCwIcon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { useIsDesktop } from '../../hooks/useMediaQuery';
import { scrambleState } from '../../utils/cube';
import { Button } from '../ui/Button';
import { Kbd } from '../ui/Kbd';
import { CubeFigure } from '../cube/CubeFigure';
import { ScrambleText } from '../timer/ScrambleText';

interface ChallengeSetupProps {
  scramble: string;
  preparing: boolean;
  onNew: () => void;
  children?: React.ReactNode;
}

/** Idle setup for execution drills: the exact scramble and its cube, side by side. */
export function ChallengeSetup({ scramble, preparing, onNew, children }: ChallengeSetupProps) {
  const store = useStore();
  const desktop = useIsDesktop();
  const cube = useMemo(() => scrambleState(scramble), [scramble]);
  return (
    <div className="flex items-start gap-4 md:gap-10">
      <div className="min-w-0 flex-1">
        {children}
        <ScrambleText scramble={preparing ? null : scramble} preparing={preparing} size="md" className="max-w-[44ch]" />
        <Button size="sm" variant="ghost" className="-ml-3 mt-2" onClick={onNew} disabled={preparing}>
          <RefreshCwIcon className={`h-3.5 w-3.5 ${preparing ? 'animate-spin' : ''}`} /> New scramble <Kbd>N</Kbd>
        </Button>
      </div>
      {!preparing &&
      <CubeFigure
        state={cube}
        scheme={store.scheme}
        viewTop={store.setup.viewTop}
        viewFront={store.setup.viewFront}
        size={desktop ? 170 : 72}
        flat={!desktop}
        label="Cube after this scramble"
        resetKey={scramble} />

      }
    </div>);

}