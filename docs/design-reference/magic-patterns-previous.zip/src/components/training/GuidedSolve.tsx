import React, { useEffect, useRef } from 'react';
import { useStore } from '../../contexts/AppStore';
import { useTraining } from '../../contexts/TrainingContext';
import { sampleChallenges } from '../../data/trainingSamples';
import { useHoldToStart } from '../../hooks/useHoldToStart';
import { executionTargets, piecesFor } from '../../utils/training';
import { isTypingTarget, overlayOpen, uid } from '../../utils/dom';
import { formatMs } from '../../utils/time';
import { Button } from '../ui/Button';
import { StageFrame } from './StageFrame';
import { ChallengeSetup } from './ChallengeSetup';
import { HoldReadout } from './HoldReadout';
import { TargetRows } from './TargetRows';
import { StageClock } from './StageClock';
import { ReviewMemo } from './ReviewMemo';
import { Fact } from './Fact';
import { ScrambleText } from '../timer/ScrambleText';

export function GuidedSolve({ setupExtra }: {setupExtra?: React.ReactNode;}) {
  const store = useStore();
  const t = useTraining();
  const s = t.drills.guided;
  const c = sampleChallenges[s.challenge];
  const pieces = piecesFor(t.scope, store.prefs.memoOrder);
  const m2 = store.prefs.m2Swap && store.setup.edgeMethod === 'M2';
  const rows = pieces.map((p) => ({ piece: p, targets: executionTargets(c, p, m2) }));
  const reported = useRef(false);

  const hold = useHoldToStart({
    enabled: s.phase === 'idle' && !s.preparing,
    onStart: () => {
      reported.current = false;
      t.update('guided', { phase: 'memo', t0: performance.now(), t1: null, t2: null, attemptId: null });
    }
  });

  const startExec = () => s.phase === 'memo' && t.update('guided', { phase: 'exec', t1: performance.now() });
  const stop = () => s.phase === 'exec' && t.update('guided', { phase: 'report', t2: performance.now() });
  const report = (ok: boolean) => {
    if (s.phase !== 'report' || reported.current || s.t1 === null || s.t2 === null) return;
    reported.current = true;
    const total = Math.round(s.t2 - s.t0);
    const memoMs = Math.round(s.t1 - s.t0);
    const id = uid('a');
    store.addAttempt({
      id,
      mode: 'guided',
      date: new Date().toISOString(),
      scope: t.scope,
      success: ok,
      durationMs: total,
      memoMs,
      execMs: total - memoMs
    });
    t.update('guided', { phase: 'review', attemptId: id, success: ok });
  };
  const next = () => t.nextChallenge('guided', true);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target) || overlayOpen() || e.metaKey || e.ctrlKey) return;
      if (e.code === 'Space' && (s.phase === 'memo' || s.phase === 'exec')) {
        e.preventDefault();
        if (e.repeat) return;
        if (s.phase === 'memo') startExec();else
        stop();
      }
      if (s.phase === 'idle' && (e.key === 'n' || e.key === 'N') && !s.preparing) next();
      if (s.phase === 'report') {
        if (e.key === 's' || e.key === 'S') report(true);
        if (e.key === 'd' || e.key === 'D') report(false);
      }
      if (s.phase === 'review' && e.key === 'Enter' && !(e.target as HTMLElement).closest('button')) {
        e.preventDefault();
        next();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (s.phase === 'idle') {
    return (
      <StageFrame label="Guided Solve setup. Hold to start." surface={hold.handlers}>
        <ChallengeSetup scramble={c.scramble} preparing={s.preparing} onNew={next}>
          {setupExtra && <div className="mb-4">{setupExtra}</div>}
        </ChallengeSetup>
        <div className="flex flex-1 items-center justify-center py-10">
          <HoldReadout hold={hold.state} disabled={s.preparing} />
        </div>
      </StageFrame>);

  }

  if (s.phase === 'memo') {
    return (
      <StageFrame
        label="Memorise"
        footer={
        <Button variant="primary" size="lg" className="w-full md:w-auto" onClick={startExec}>
            Start execution <span className="hidden font-mono text-[11px] opacity-50 md:inline">Space</span>
          </Button>
        }>
        
        <TargetRows rows={rows} />
      </StageFrame>);

  }

  if (s.phase === 'exec' || s.phase === 'report') {
    return (
      <StageFrame
        label={s.phase === 'exec' ? 'Solving' : 'Report result'}
        footer={
        s.phase === 'exec' ?
        <Button variant="primary" size="lg" className="w-full md:w-auto" onClick={stop}>
              Stop <span className="hidden font-mono text-[11px] opacity-50 md:inline">Space</span>
            </Button> :

        <div className="grid w-full grid-cols-2 gap-2 md:flex md:w-auto">
              <Button variant="signal" size="lg" onClick={() => report(true)} data-autofocus>
                Solved <span className="hidden font-mono text-[11px] opacity-60 md:inline">S</span>
              </Button>
              <Button variant="danger" size="lg" onClick={() => report(false)}>
                DNF <span className="hidden font-mono text-[11px] opacity-60 md:inline">D</span>
              </Button>
            </div>

        }>
        
        <div className="flex flex-1 flex-col items-center justify-center py-8 text-center">
          {s.phase === 'exec' ?
          <>
              <p className="text-[40px] font-medium tracking-[-0.03em] text-fg md:text-[56px]">Solving</p>
              <StageClock from={s.t0} className="mt-3 text-[22px] text-muted" />
            </> :

          <>
              <p className="tnum font-mono text-[48px] font-medium tracking-[-0.04em] text-fg md:text-[64px]">
                {formatMs((s.t2 ?? s.t0) - s.t0)}
              </p>
              <p className="mt-4 text-[17px] text-fg">Did you solve the cube?</p>
            </>
          }
        </div>
      </StageFrame>);

  }

  const total = (s.t2 ?? s.t0) - s.t0;
  const memo = (s.t1 ?? s.t0) - s.t0;
  return (
    <StageFrame
      label="Guided Solve review"
      footer={
      <Button variant="primary" className="ml-auto" onClick={next}>
          Next <span className="hidden font-mono text-[11px] opacity-50 md:inline">↵</span>
        </Button>
      }>
      
      <div className={`tnum font-mono text-[44px] font-medium leading-none tracking-[-0.04em] md:text-[56px] ${s.success ? 'text-fg' : 'text-danger'}`}>
        {s.success ? formatMs(total) : 'DNF'}
      </div>
      <dl className="tnum mt-6 flex flex-wrap gap-x-8 gap-y-2 font-mono text-[14px]">
        <Fact label="Result" value={s.success ? 'Solved' : 'DNF'} tone={s.success ? 'signal' : 'danger'} />
        <Fact label="Total" value={formatMs(total)} />
        <Fact label="Memo" value={formatMs(memo)} />
        <Fact label="Execution" value={formatMs(total - memo)} />
        <Fact label="Pieces" value={t.scope === 'both' ? 'All' : t.scope === 'edges' ? 'Edges' : 'Corners'} />
      </dl>
      <div className="mt-8 border-t border-line pt-6">
        <ReviewMemo rows={rows} />
      </div>
      <div className="mt-8 border-t border-line pt-6">
        <h4 className="mb-1.5 text-[12px] font-medium text-faint">Scramble</h4>
        <ScrambleText scramble={c.scramble} size="sm" />
      </div>
    </StageFrame>);

}