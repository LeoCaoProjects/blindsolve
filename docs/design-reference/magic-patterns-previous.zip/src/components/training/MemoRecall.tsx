import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useStore } from '../../contexts/AppStore';
import { useTraining } from '../../contexts/TrainingContext';
import { sampleChallenges } from '../../data/trainingSamples';
import { useHoldToStart } from '../../hooks/useHoldToStart';
import { useIsDesktop } from '../../hooks/useMediaQuery';
import { scrambleState, solvedState } from '../../utils/cube';
import { compareTokens, piecesFor, PieceKey } from '../../utils/training';
import { scopeTokens, tokenize } from '../../utils/lettering';
import { isTypingTarget, overlayOpen, uid } from '../../utils/dom';
import { formatMs } from '../../utils/time';
import { effectiveWords, normalizeWords, pairKey, suggestWords } from '../../utils/pairs';
import { Button } from '../ui/Button';
import { CubeFigure } from '../cube/CubeFigure';
import { StageFrame } from './StageFrame';
import { HoldReadout } from './HoldReadout';
import { TargetRows } from './TargetRows';
import { TokenCompare } from './TokenCompare';
import { Fact } from './Fact';

export function MemoRecall({ setupExtra }: {setupExtra?: React.ReactNode;}) {
  const store = useStore();
  const t = useTraining();
  const desktop = useIsDesktop();
  const s = t.drills.recall;
  const c = sampleChallenges[s.challenge];
  const pieces = piecesFor(t.scope, store.prefs.memoOrder);
  const rows = pieces.map((p) => ({ piece: p, targets: c[p] }));
  const inputRefs = useRef<Partial<Record<PieceKey, HTMLInputElement | null>>>({});
  const guard = useRef(false);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [openRow, setOpenRow] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);
  const scrambled = useMemo(() => scrambleState(c.scramble), [c.scramble]);

  const hold = useHoldToStart({
    enabled: s.phase === 'idle',
    onStart: () => {
      guard.current = false;
      setDrafts({});
      setOpenRow(null);
      setShowAll(false);
      t.update('recall', { phase: 'study', t0: performance.now(), t1: null, t2: null, inputs: { corners: '', edges: '' } });
    }
  });

  const ready = () => {
    if (s.phase !== 'study') return;
    t.update('recall', { phase: 'recall', t1: performance.now() });
    window.setTimeout(() => inputRefs.current[pieces[0]]?.focus(), 30);
  };

  const evaluate = () =>
  pieces.map((p) => {
    const expected = c[p].map((x) => x.token);
    const yours = tokenize(s.inputs[p], scopeTokens(store.scheme, p));
    return { piece: p, expected, yours, cmp: compareTokens(expected, yours) };
  });

  const submit = () => {
    if (s.phase !== 'recall' || guard.current) return;
    guard.current = true;
    const end = performance.now();
    const res = evaluate();
    const total = res.reduce((n, r) => n + r.expected.length, 0);
    const correct = res.reduce((n, r) => n + r.cmp.filter((x) => x.status === 'correct').length, 0);
    store.addAttempt({
      id: uid('a'),
      mode: 'recall',
      date: new Date().toISOString(),
      scope: t.scope,
      success: correct === total && res.every((r) => r.yours.length === r.expected.length),
      durationMs: Math.round((s.t1 ?? s.t0) - s.t0),
      recallMs: Math.round(end - (s.t1 ?? end)),
      correct,
      total
    });
    t.update('recall', { phase: 'review', t2: end });
  };

  const pending = Object.values(drafts).filter((v) => v.trim()).length;
  const saveDrafts = () => {
    Object.entries(drafts).forEach(([id, word]) => {
      if (!word.trim()) return;
      const [piece, key] = id.split(':') as [PieceKey, string];
      const entry = store.pairs[key] ?? { shared: [], usage: 0 };
      store.savePair(key, { ...entry, [piece]: normalizeWords([word, ...(entry[piece] as string[] ?? [])]) });
    });
    setDrafts({});
    setOpenRow(null);
  };
  const cancelDrafts = () => {
    setDrafts({});
    setOpenRow(null);
  };
  const next = () => {
    if (pending) return;
    t.nextChallenge('recall', false);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (overlayOpen() || e.metaKey || e.ctrlKey) return;
      if (s.phase === 'study' && (e.code === 'Space' || e.key === 'Enter') && !isTypingTarget(e.target)) {
        e.preventDefault();
        if (!e.repeat) ready();
      }
      if (s.phase === 'recall' && e.key === 'Escape') {
        e.preventDefault();
        submit();
      }
      if (s.phase === 'review') {
        if (e.key === 'Escape' && pending) {
          e.preventDefault();
          cancelDrafts();
        }
        if (e.key === 'Enter' && !e.repeat && !(e.target as HTMLElement).closest('button')) {
          if (isTypingTarget(e.target) && !pending) return;
          e.preventDefault();
          if (pending) saveDrafts();else
          next();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const cubeEl = (state = scrambled, dim = false) =>
  <CubeFigure
    state={state}
    scheme={store.scheme}
    viewTop={store.setup.viewTop}
    viewFront={store.setup.viewFront}
    size={desktop ? 190 : 72}
    flat={!desktop}
    dim={dim}
    label={state === scrambled ? 'Challenge cube' : 'Solved reference cube'}
    draggable={desktop} />;



  if (s.phase === 'idle') {
    return (
      <StageFrame label="Memo Recall. Hold to start." surface={hold.handlers}>
        <div className="flex items-start justify-between gap-4">
          <div>{setupExtra}</div>
          {cubeEl(solvedState())}
        </div>
        <div className="flex flex-1 items-center justify-center py-10">
          <HoldReadout hold={hold.state} />
        </div>
      </StageFrame>);

  }

  if (s.phase === 'study' || s.phase === 'recall') {
    const study = s.phase === 'study';
    return (
      <StageFrame
        label={study ? 'Study' : 'Recall'}
        footer={
        study ?
        <Button variant="primary" size="lg" className="w-full md:w-auto" onClick={ready}>
              Ready <span className="hidden font-mono text-[11px] opacity-50 md:inline">Space</span>
            </Button> :

        <div className="flex w-full items-center gap-2 md:w-auto">
              <Button variant="ghost" onClick={submit}>
                Show answer <span className="hidden font-mono text-[11px] opacity-50 md:inline">Esc</span>
              </Button>
              <Button variant="primary" className="ml-auto md:ml-0" onClick={submit}>
                Submit
              </Button>
            </div>

        }>
        
        <div className="flex items-start gap-6 md:gap-10">
          <div className="min-w-0 flex-1">
            {study ?
            <TargetRows rows={rows} /> :

            <form
              className="space-y-5"
              onSubmit={(e) => {
                e.preventDefault();
                submit();
              }}>
              
                {pieces.map((p, i) =>
              <label key={p} className="block">
                    <span className="text-[12px] font-medium text-faint">{p === 'corners' ? 'Corners' : 'Edges'}</span>
                    <input
                  ref={(el) => inputRefs.current[p] = el}
                  value={s.inputs[p]}
                  autoComplete="off"
                  autoCapitalize="characters"
                  spellCheck={false}
                  onChange={(e) => t.update('recall', (st) => ({ inputs: { ...st.inputs, [p]: e.target.value.toUpperCase() } }))}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const nextPiece = pieces[i + 1];
                      if (nextPiece) inputRefs.current[nextPiece]?.focus();else
                      submit();
                    }
                  }}
                  className="mt-1 h-14 w-full border-b border-line-strong bg-transparent font-mono text-[24px] tracking-[0.12em] text-fg focus:border-signal focus:outline-none md:text-[28px]" />
                
                  </label>
              )}
              </form>
            }
          </div>
          {cubeEl(scrambled, !study)}
        </div>
      </StageFrame>);

  }

  // Review
  const res = evaluate();
  const total = res.reduce((n, r) => n + r.expected.length, 0);
  const correct = res.reduce((n, r) => n + r.cmp.filter((x) => x.status === 'correct').length, 0);
  const allOk = correct === total && res.every((r) => r.yours.length === r.expected.length);

  const vocab = res.flatMap((r) => {
    const out: {id: string;piece: PieceKey;key: string;tokens: string[];word?: string;missed: boolean;}[] = [];
    for (let i = 0; i + 1 < r.expected.length; i += 2) {
      const key = pairKey(r.expected[i], r.expected[i + 1]);
      out.push({
        id: `${r.piece}:${key}`,
        piece: r.piece,
        key,
        tokens: [r.expected[i], r.expected[i + 1]],
        word: effectiveWords(store.pairs[key], r.piece)[0],
        missed: r.cmp[i].status !== 'correct' || r.cmp[i + 1].status !== 'correct'
      });
    }
    return out;
  });
  const worth = vocab.filter((v) => !v.word || v.missed);
  const list = showAll ? vocab : worth;

  return (
    <StageFrame
      label="Memo Recall review"
      footer={
      pending > 0 ?
      <>
            <span className="text-[13px] text-muted">
              {pending} unsaved {pending === 1 ? 'word' : 'words'}
            </span>
            <div className="ml-auto flex gap-2">
              <Button variant="ghost" onClick={cancelDrafts}>
                Cancel
              </Button>
              <Button variant="primary" onClick={saveDrafts}>
                Save
              </Button>
            </div>
          </> :

      <Button variant="primary" className="ml-auto" onClick={next}>
            Next <span className="hidden font-mono text-[11px] opacity-50 md:inline">↵</span>
          </Button>

      }>
      
      <p className={`text-[28px] font-semibold tracking-[-0.02em] md:text-[34px] ${allOk ? 'text-signal' : 'text-fg'}`}>
        {allOk ? 'Correct' : 'Incorrect'}
      </p>
      <dl className="tnum mt-4 flex flex-wrap gap-x-8 gap-y-2 font-mono text-[14px]">
        <Fact label="Targets" value={`${correct}/${total}`} />
        <Fact label="Memo" value={formatMs((s.t1 ?? s.t0) - s.t0)} />
        <Fact label="Recall" value={formatMs((s.t2 ?? 0) - (s.t1 ?? 0))} />
      </dl>
      <div className="mt-8 space-y-6 border-t border-line pt-6">
        {res.map((r) =>
        <TokenCompare key={r.piece} label={r.piece === 'corners' ? 'Corners' : 'Edges'} expected={r.expected} yours={r.yours} />
        )}
      </div>

      <section className="mt-8 border-t border-line pt-6" aria-labelledby="vocab-title">
        <div className="mb-2 flex items-baseline justify-between">
          <h4 id="vocab-title" className="text-[13px] font-medium text-fg">
            {showAll ? 'All words' : 'Worth a look'}
          </h4>
          <button type="button" onClick={() => setShowAll((v) => !v)} className="h-8 text-[12.5px] text-muted hover:text-fg">
            {showAll ? 'Show fewer' : 'Show all words'}
          </button>
        </div>
        {list.length === 0 ?
        <p className="text-[13px] text-faint">Every pair has a word and was recalled correctly.</p> :

        <ul className="divide-y divide-line">
            {list.map((v) =>
          <li key={v.id} className="py-2">
                <div className="flex items-center gap-4">
                  <span className={`w-10 font-mono text-[15px] tracking-[0.06em] ${v.missed ? 'text-danger' : 'text-fg'}`}>
                    {v.tokens.join('')}
                  </span>
                  <span className="w-14 text-[11.5px] text-faint">{v.piece === 'corners' ? 'Corner' : 'Edge'}</span>
                  {v.word ?
              <span className="font-serif text-[16px] italic text-fg">{v.word}</span> :
              openRow === v.id ?
              <input
                autoFocus
                value={drafts[v.id] ?? ''}
                onChange={(e) => setDrafts((d) => ({ ...d, [v.id]: e.target.value }))}
                placeholder="Add a word"
                aria-label={`Word for ${v.tokens.join('')}`}
                className="h-9 min-w-0 flex-1 rounded-md border border-line-strong bg-bg px-2 font-serif text-[16px] italic text-fg placeholder:font-sans placeholder:not-italic placeholder:text-[13px] placeholder:text-faint focus:outline-none" /> :


              <button
                type="button"
                onClick={() => setOpenRow(v.id)}
                className="h-8 text-[13px] text-muted underline decoration-line-strong underline-offset-4 hover:text-fg">
                
                      {drafts[v.id] ? <span className="font-serif italic text-fg no-underline">{drafts[v.id]}</span> : 'No word · add'}
                    </button>
              }
                </div>
                {openRow === v.id && !v.word &&
            <div className="mt-2 flex flex-wrap gap-1.5 pl-[7.5rem]">
                    {suggestWords(v.tokens[0], v.tokens[1]).map((w) =>
              <button
                key={w}
                type="button"
                onClick={() => setDrafts((d) => ({ ...d, [v.id]: w }))}
                className="h-7 rounded-md border border-line px-2.5 font-serif text-[14px] italic text-muted hover:border-line-strong hover:text-fg">
                
                        {w}
                      </button>
              )}
                  </div>
            }
              </li>
          )}
          </ul>
        }
      </section>
    </StageFrame>);

}