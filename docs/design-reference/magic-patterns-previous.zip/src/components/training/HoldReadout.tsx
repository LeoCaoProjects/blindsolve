import React from 'react';
import { HoldState } from '../../hooks/useHoldToStart';

/** Idle state of every drill: a resting clock that arms and readies under the hold. */
export function HoldReadout({ hold, disabled }: {hold: HoldState;disabled?: boolean;}) {
  return (
    <div className="flex flex-col items-center">
      <span
        className={`tnum font-mono text-[56px] font-medium leading-none tracking-[-0.04em] transition-colors duration-100 md:text-[72px] short:md:text-[56px] ${
        disabled ? 'text-faint/50' : hold === 'ready' ? 'text-signal' : hold === 'armed' ? 'text-faint' : 'text-fg'}`
        }>
        
        0.00
      </span>
      <span className="mt-3 text-[12.5px] text-faint">
        {disabled ?
        'Preparing scramble…' :

        <>
            <span className="hidden md:inline">Hold Space to start</span>
            <span className="md:hidden">Touch and hold to start</span>
          </>
        }
      </span>
    </div>);

}