import React, { useEffect, useRef } from 'react';
import { useStore } from '../../contexts/AppStore';
import { useTraining } from '../../contexts/TrainingContext';
import { sampleChallenges } from '../../data/trainingSamples';
import { useHoldToStart } from '../../hooks/useHoldToStart';
import { executionTargets, piecesFor } from '../../utils/training';
import { isControlTarget, isTypingTarget, overlayOpen, uid } from '../../utils/dom';
import { formatMs } from '../../utils/time';
import { Button } from '../ui/Button';
import { Segmented } from '../ui/Segmented';
import { StageFrame } from './StageFrame';
import { ChallengeSetup } from './ChallengeSetup';
import { HoldReadout } from './HoldReadout';
import { TargetRows } from './TargetRows';
import { StageClock } from './StageClock';
import { ReviewMemo } from './ReviewMemo';
import { ScrambleText } from '../timer/ScrambleText';
import { Fact } from './Fact';

export function ExecutionSprint({ setupExtra }: {setupExtra?: React.ReactNode;}) {
  const store = useStore();
  const t = useTraining();
  const s = t.drills.exec;
  const c = sampleChallenges[s.challenge];
  const pieces = piecesFor(t.scope, store.prefs.memoOrder);
  const m2 = store.prefs.m2Swap && store.setup.edgeMethod === 'M2';
  const rows = pieces.map((p) => ({ piece: p, targets: executionTargets(c, p, m2) }));
  const guard = useRef(false);

  const hold = useHoldToStart({
    enabled: s.phase === 'idle' && !s.preparing,
    onStart: () => {
      guard.current = false;
      t.update('exec', { phase: 'active', t0: performance.now(), t2: null, attemptId: null, success: true });
    }
  });

  const stop = () => {
    if (guard.current || s.phase !== 'active') return;
    guard.current = true;
    const end = performance.now();
    const id = uid('a');
    store.addAttempt({ id, mode: 'exec', date: new Date().toISOString(), scope: t.scope, success: true, durationMs: Math.round(end - s.t0) });
    t.update('exec', { phase: 'review', t2: end, attemptId: id, success: true });
  };

  const setResult = (ok: boolean) => {
    if (!s.attemptId) return;
    t.update('exec', { success: ok });
    store.updateAttempt(s.attemptId, { success: ok });
  };

  const next = () => t.nextChallenge('exec', true);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target) || overlayOpen() || e.metaKey || e.ctrlKey) return;
      if (s.phase === 'active' && e.code === 'Space') {
        e.preventDefault();
        if (!e.repeat) stop();
      }
      if (s.phase === 'idle' && (e.key === 'n' || e.key === 'N') && !s.preparing) next();
      if (s.phase === 'review') {
        if (e.key === 's' || e.key === 'S') setResult(true);
        if (e.key === 'd' || e.key === 'D') setResult(false);
        if (e.key === 'Enter' && !(e.target as HTMLElement).closest('button')) {
          e.preventDefault();
          next();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (s.phase === 'idle') {
    return (
      <StageFrame label="Execution Sprint setup. Hold to start." surface={hold.handlers}>
        <ChallengeSetup scramble={c.scramble} preparing={s.preparing} onNew={next}>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            {setupExtra}
            <Segmented
              size="sm"
              label="Show memo as"
              value={s.display}
              onChange={(v) => t.update('exec', { display: v })}
              options={[
              { value: 'letters', label: 'Letters' },
              { value: 'words', label: 'Words' }]
              } />
            
          </div>
        </ChallengeSetup>
        <div className="flex flex-1 items-center justify-center py-10">
          <HoldReadout hold={hold.state} disabled={s.preparing} />
        </div>
      </StageFrame>);

  }

  if (s.phase === 'active') {
    return (
      <StageFrame
        label="Execution in progress. Tap to stop."
        surface={{
          onPointerDown: (e) => {
            if (!isControlTarget(e.target)) stop();
          }
        }}
        footer={
        <Button variant="primary" size="lg" className="w-full md:w-auto" onClick={stop}>
            Stop <span className="hidden font-mono text-[11px] opacity-50 md:inline">Space</span>
          </Button>
        }>
        
        <StageClock from={s.t0} className="mb-8 text-[40px] font-medium leading-none tracking-[-0.04em] text-muted md:text-[48px]" />
        <TargetRows rows={rows} display={s.display} pairs={store.pairs} />
      </StageFrame>);

  }

  const duration = (s.t2 ?? s.t0) - s.t0;
  const targets = rows.reduce((n, r) => n + r.targets.length, 0);
  const fullPairs = rows.reduce((n, r) => n + Math.floor(r.targets.length / 2), 0);

  return (
    <StageFrame
      label="Execution Sprint review"
      footer={
      <Button variant="primary" className="ml-auto" onClick={next} data-autofocus>
          Next <span className="hidden font-mono text-[11px] opacity-50 md:inline">↵</span>
        </Button>
      }>
      
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className={`tnum font-mono text-[44px] font-medium leading-none tracking-[-0.04em] md:text-[56px] ${s.success ? 'text-fg' : 'text-danger'}`}>
            {s.success ? formatMs(duration) : 'DNF'}
          </div>
          {!s.success && <p className="tnum mt-1 font-mono text-[12.5px] text-faint">{formatMs(duration)}</p>}
        </div>
        <Segmented
          label="Self-reported result"
          value={s.success ? 'solved' : 'dnf'}
          onChange={(v) => setResult(v === 'solved')}
          options={[
          { value: 'solved', label: <span>Solved <span className="ml-1 hidden font-mono text-[10.5px] opacity-50 md:inline">S</span></span>, tone: 'signal' },
          { value: 'dnf', label: <span>DNF <span className="ml-1 hidden font-mono text-[10.5px] opacity-50 md:inline">D</span></span>, tone: 'danger' }]
          } />
        
      </div>
      <dl className="tnum mt-6 flex flex-wrap gap-x-8 gap-y-2 font-mono text-[14px]">
        <Fact label="Targets" value={String(targets)} />
        <Fact label="Pairs" value={String(fullPairs)} />
        <Fact label="Per target" value={targets ? formatMs(duration / targets) : '—'} />
      </dl>
      <div className="mt-8 border-t border-line pt-6">
        <ReviewMemo rows={rows} pairs={store.pairs} />
      </div>
      <div className="mt-8 border-t border-line pt-6">
        <h4 className="mb-1.5 text-[12px] font-medium text-faint">Scramble</h4>
        <ScrambleText scramble={c.scramble} size="sm" />
      </div>
    </StageFrame>);

}