import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useStore } from '../../contexts/AppStore';
import { useTraining } from '../../contexts/TrainingContext';
import { sampleChallenges } from '../../data/trainingSamples';
import { useHoldToStart } from '../../hooks/useHoldToStart';
import { useMediaQuery } from '../../hooks/useMediaQuery';
import { scrambleState } from '../../utils/cube';
import { compareTokens, piecesFor, PieceKey } from '../../utils/training';
import { scopeTokens, tokenize } from '../../utils/lettering';
import { overlayOpen, uid } from '../../utils/dom';
import { formatMs } from '../../utils/time';
import { Button } from '../ui/Button';
import { CubeFigure } from '../cube/CubeFigure';
import { StageFrame } from './StageFrame';
import { HoldReadout } from './HoldReadout';
import { TokenCompare } from './TokenCompare';
import { Fact } from './Fact';

export function TraceSprint({ setupExtra }: {setupExtra?: React.ReactNode;}) {
  const store = useStore();
  const t = useTraining();
  const s = t.drills.trace;
  const c = sampleChallenges[s.challenge];
  const pieces = piecesFor(t.scope, store.prefs.memoOrder);
  const wide = useMediaQuery('(min-width: 1100px) and (min-height: 600px)');
  const small = useMediaQuery('(max-width: 380px)');
  const [rot, setRot] = useState({ x: 0, y: 0 });
  const refs = useRef<Partial<Record<PieceKey, HTMLInputElement | null>>>({});
  const guard = useRef(false);
  const cube = useMemo(() => scrambleState(c.scramble), [c.scramble]);

  const hold = useHoldToStart({
    enabled: s.phase === 'idle',
    onStart: () => {
      guard.current = false;
      setRot({ x: 0, y: 0 });
      t.update('trace', { phase: 'active', t0: performance.now(), t2: null, inputs: { corners: '', edges: '' } });
      window.setTimeout(() => refs.current[pieces[0]]?.focus(), 40);
    }
  });

  const evaluate = () =>
  pieces.map((p) => {
    const expected = c[p].map((x) => x.token);
    const yours = tokenize(s.inputs[p], scopeTokens(store.scheme, p));
    return { piece: p, expected, yours, cmp: compareTokens(expected, yours) };
  });

  const submit = () => {
    if (s.phase !== 'active' || guard.current) return;
    guard.current = true;
    const end = performance.now();
    const res = evaluate();
    const total = res.reduce((n, r) => n + r.expected.length, 0);
    const correct = res.reduce((n, r) => n + r.cmp.filter((x) => x.status === 'correct').length, 0);
    store.addAttempt({
      id: uid('a'),
      mode: 'trace',
      date: new Date().toISOString(),
      scope: t.scope,
      success: correct === total && res.every((r) => r.yours.length === r.expected.length),
      durationMs: Math.round(end - s.t0),
      correct,
      total
    });
    t.update('trace', { phase: 'review', t2: end });
  };
  const next = () => t.nextChallenge('trace', false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (overlayOpen()) return;
      if (s.phase === 'review' && e.key === 'Enter' && !(e.target as HTMLElement).closest('button')) {
        e.preventDefault();
        next();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (s.phase === 'idle') {
    return (
      <StageFrame label="Trace Sprint. Hold to start." surface={hold.handlers}>
        {setupExtra}
        <div className="flex flex-1 items-center justify-center py-10">
          <HoldReadout hold={hold.state} />
        </div>
      </StageFrame>);

  }

  if (s.phase === 'active') {
    const cubeSize = wide ? 240 : small ? 132 : 156;
    const cubes =
    <div className="flex justify-center gap-2 md:gap-6">
        {(['front', 'back'] as const).map((v) =>
      <figure key={v} className="flex flex-col items-center">
            <CubeFigure
          state={cube}
          scheme={store.scheme}
          viewTop={store.setup.viewTop}
          viewFront={store.setup.viewFront}
          size={cubeSize}
          view={v}
          linkedOffset={rot}
          onRotate={setRot}
          label={v === 'front' ? 'Front view: U, F, R visible' : 'Back view of the same cube: D, B, L visible'} />
        
            <figcaption className="font-mono text-[11.5px] text-faint">{v === 'front' ? 'U · F · R' : 'D · B · L'}</figcaption>
          </figure>
      )}
      </div>;

    return (
      <StageFrame
        label="Trace the cube"
        footer={
        <Button variant="primary" className="ml-auto" onClick={submit}>
            Submit <span className="hidden font-mono text-[11px] opacity-50 md:inline">↵</span>
          </Button>
        }>
        
        <div className={wide ? 'grid grid-cols-[auto_1fr] items-center gap-12' : 'space-y-5'}>
          {cubes}
          <form
            className="space-y-5"
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}>
            
            {pieces.map((p, i) =>
            <label key={p} className="block">
                <span className="text-[12px] font-medium text-faint">{p === 'corners' ? 'Corners' : 'Edges'}</span>
                <input
                ref={(el) => refs.current[p] = el}
                value={s.inputs[p]}
                autoComplete="off"
                autoCapitalize="characters"
                spellCheck={false}
                onChange={(e) => t.update('trace', (st) => ({ inputs: { ...st.inputs, [p]: e.target.value.toUpperCase() } }))}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    const n = pieces[i + 1];
                    if (n) refs.current[n]?.focus();else
                    submit();
                  }
                }}
                className="mt-1 h-12 w-full border-b border-line-strong bg-transparent font-mono text-[22px] tracking-[0.12em] text-fg focus:border-signal focus:outline-none md:h-14 md:text-[26px]" />
              
              </label>
            )}
          </form>
        </div>
      </StageFrame>);

  }

  const res = evaluate();
  const total = res.reduce((n, r) => n + r.expected.length, 0);
  const correct = res.reduce((n, r) => n + r.cmp.filter((x) => x.status === 'correct').length, 0);
  const allOk = correct === total && res.every((r) => r.yours.length === r.expected.length);
  const duration = (s.t2 ?? s.t0) - s.t0;

  return (
    <StageFrame
      label="Trace Sprint review"
      footer={
      <Button variant="primary" className="ml-auto" onClick={next}>
          Next <span className="hidden font-mono text-[11px] opacity-50 md:inline">↵</span>
        </Button>
      }>
      
      <div className="flex flex-wrap items-baseline gap-x-5 gap-y-1">
        <span className="tnum font-mono text-[44px] font-medium leading-none tracking-[-0.04em] text-fg md:text-[56px]">
          {formatMs(duration)}
        </span>
        <span className={`text-[20px] font-semibold ${allOk ? 'text-signal' : 'text-danger'}`}>{allOk ? 'Correct' : 'Incorrect'}</span>
      </div>
      <dl className="tnum mt-6 flex flex-wrap gap-x-8 gap-y-2 font-mono text-[14px]">
        <Fact label="Targets" value={`${correct}/${total}`} />
        <Fact label="Accuracy" value={`${total ? Math.round(correct / total * 100) : 0}%`} />
        <Fact label="Per target" value={total ? formatMs(duration / total) : '—'} />
      </dl>
      <div className="mt-8 space-y-6 border-t border-line pt-6">
        {res.map((r) =>
        <TokenCompare key={r.piece} label={r.piece === 'corners' ? 'Corners' : 'Edges'} expected={r.expected} yours={r.yours} />
        )}
      </div>
    </StageFrame>);

}