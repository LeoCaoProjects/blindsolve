import React, { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { CheckIcon, ChevronDownIcon, ImageIcon, XIcon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { FeedbackType } from '../../types/domain';
import { Sheet } from '../ui/Sheet';
import { Segmented } from '../ui/Segmented';
import { Button } from '../ui/Button';

type SendState = 'idle' | 'sending' | 'failed' | 'sent';

export function FeedbackSheet({ open, onClose }: {open: boolean;onClose: () => void;}) {
  const store = useStore();
  const { pathname } = useLocation();
  const [type, setType] = useState<FeedbackType>('bug');
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const [shot, setShot] = useState<{name: string;url: string;} | null>(null);
  const [details, setDetails] = useState(false);
  const [state, setState] = useState<SendState>('idle');
  const attempts = useRef(0);
  const fileRef = useRef<HTMLInputElement>(null);
  const signedIn = store.account.mode === 'signedIn' || store.account.mode === 'admin';

  const reset = () => {
    setMessage('');
    setEmail('');
    setShot(null);
    setDetails(false);
    setState('idle');
    setType('bug');
  };

  useEffect(() => {
    if (state !== 'sent') return;
    const t = window.setTimeout(() => {
      onClose();
      reset();
    }, 1800);
    return () => window.clearTimeout(t);
  }, [state, onClose]);

  const send = () => {
    if (!message.trim() || state === 'sending') return;
    setState('sending');
    const fail = store.simulateFailures && attempts.current === 0;
    attempts.current += 1;
    window.setTimeout(() => setState(fail ? 'failed' : 'sent'), 1100);
  };

  const context: [string, string][] = [
  ['Page', pathname],
  ['Build', '2026.11.02-prototype'],
  ['Browser', navigator.userAgent.includes('Chrome') ? 'Chrome' : navigator.userAgent.includes('Safari') ? 'Safari' : 'Other'],
  ['Device', navigator.platform || 'Unknown'],
  ['Viewport', `${window.innerWidth}×${window.innerHeight}`]];


  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Give feedback"
      dismissible={state !== 'sending'}
      widthClass="md:w-[460px]"
      footer={
      state === 'sent' ?
      <p className="flex h-10 items-center gap-2 text-[14px] text-fg" role="status">
            <CheckIcon className="h-4 w-4 text-signal" /> Sent. Thank you.
          </p> :

      <div className="flex items-center gap-3">
            {state === 'failed' &&
        <span role="alert" className="text-[12.5px] text-danger">
                Couldn’t send. Your message is kept.
              </span>
        }
            <Button variant="primary" className="ml-auto" disabled={!message.trim() || state === 'sending'} onClick={send}>
              {state === 'sending' ? 'Sending…' : state === 'failed' ? 'Try again' : 'Send'}
            </Button>
          </div>

      }>
      
      <fieldset disabled={state === 'sending' || state === 'sent'} className="space-y-5">
        <Segmented
          stretch
          label="Feedback type"
          value={type}
          onChange={setType}
          options={[
          { value: 'bug', label: 'Bug' },
          { value: 'feature', label: 'Feature request' },
          { value: 'general', label: 'General' }]
          } />
        
        <label className="block">
          <span className="text-[12px] font-medium text-faint">Message</span>
          <textarea
            data-autofocus
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
            required
            className="mt-1 w-full resize-y rounded-md border border-line bg-bg px-3 py-2.5 text-[14px] leading-relaxed text-fg placeholder:text-faint focus:border-line-strong focus:outline-none"
            placeholder={type === 'bug' ? 'What happened, and what did you expect?' : ''} />
          
        </label>
        {signedIn ?
        <p className="text-[12.5px] text-muted">
            Sent as {store.account.name} · <span className="font-mono">{store.account.provider === 'WCA' ? store.account.detail : 'leo.cao@gmail.com'}</span>
          </p> :

        <label className="block">
            <span className="text-[12px] font-medium text-faint">Email for a reply (optional)</span>
            <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 h-10 w-full rounded-md border border-line bg-bg px-3 text-[14px] text-fg focus:border-line-strong focus:outline-none" />
          
          </label>
        }
        {type === 'bug' &&
        <>
            <div>
              {shot ?
            <div className="flex items-center gap-3 rounded-md border border-line p-2">
                  <img src={shot.url} alt="Screenshot preview" className="h-12 w-16 rounded object-cover" />
                  <span className="min-w-0 flex-1 truncate text-[13px] text-muted">{shot.name}</span>
                  <Button size="icon-sm" variant="ghost" aria-label="Remove screenshot" onClick={() => setShot(null)}>
                    <XIcon className="h-4 w-4" />
                  </Button>
                </div> :

            <Button size="sm" variant="secondary" onClick={() => fileRef.current?.click()}>
                  <ImageIcon className="h-3.5 w-3.5" /> Add screenshot
                </Button>
            }
              <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) setShot({ name: f.name, url: URL.createObjectURL(f) });
                e.target.value = '';
              }} />
            
            </div>
            <div>
              <button
              type="button"
              aria-expanded={details}
              onClick={() => setDetails((d) => !d)}
              className="flex h-8 items-center gap-1.5 text-[13px] text-muted hover:text-fg">
              
                <ChevronDownIcon className={`h-3.5 w-3.5 transition-transform duration-150 ${details ? 'rotate-180' : ''}`} />
                What’s included
              </button>
              {details &&
            <dl className="mt-2 grid grid-cols-[6rem_1fr] gap-y-1 text-[12.5px]">
                  {context.map(([k, v]) =>
              <React.Fragment key={k}>
                      <dt className="text-faint">{k}</dt>
                      <dd className="truncate font-mono text-muted">{v}</dd>
                    </React.Fragment>
              )}
                  <dd className="col-span-2 mt-1 text-faint">Training answers and mnemonic words are never included.</dd>
                </dl>
            }
            </div>
          </>
        }
      </fieldset>
    </Sheet>);

}