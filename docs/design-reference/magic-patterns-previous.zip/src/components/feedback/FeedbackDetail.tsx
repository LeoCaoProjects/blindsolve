import React, { useEffect, useState } from 'react';
import { ImageIcon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { FeedbackRecord, FeedbackStatus } from '../../types/domain';
import { formatDate } from '../../utils/time';
import { Button } from '../ui/Button';
import { ConfirmDialog } from '../ui/ConfirmDialog';

export const STATUS_LABEL: Record<FeedbackStatus, string> = {
  new: 'New',
  reviewing: 'Reviewing',
  planned: 'Planned',
  resolved: 'Resolved',
  archived: 'Archived'
};
export const TYPE_LABEL = { bug: 'Bug', feature: 'Feature request', general: 'General' };

export function FeedbackDetail({ record, onClose }: {record: FeedbackRecord;onClose: () => void;}) {
  const store = useStore();
  const [note, setNote] = useState(record.note ?? '');
  const [confirmDelete, setConfirmDelete] = useState(false);
  useEffect(() => setNote(record.note ?? ''), [record.id, record.note]);
  const noteDirty = note !== (record.note ?? '');

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[12.5px] text-muted">
        <span className={record.type === 'bug' ? 'text-danger' : 'text-fg'}>{TYPE_LABEL[record.type]}</span>
        <span className="font-mono text-faint">{record.source}</span>
        <span className="text-faint">{formatDate(record.date)}</span>
      </div>
      <p className="whitespace-pre-wrap text-[15px] leading-relaxed text-fg">{record.message}</p>

      {record.screenshot &&
      <a href="#screenshot" onClick={(e) => e.preventDefault()} className="inline-flex items-center gap-2 text-[13px] text-muted underline underline-offset-4 hover:text-fg">
          <ImageIcon className="h-3.5 w-3.5" /> {record.screenshot}
        </a>
      }

      <dl className="grid grid-cols-[6.5rem_1fr] gap-y-1.5 border-t border-line pt-4 text-[13px]">
        <dt className="text-faint">From</dt>
        <dd className="text-fg">
          {record.user ?
          <>
              {record.user.name} <span className="font-mono text-muted">{record.user.detail}</span>
            </> :

          <span className="text-muted">Guest{record.contact ? ` · ${record.contact}` : ', no contact'}</span>
          }
        </dd>
        {record.context &&
        Object.entries(record.context).map(([k, v]) =>
        <React.Fragment key={k}>
              <dt className="text-faint">{k}</dt>
              <dd className="font-mono text-[12.5px] text-muted">{v}</dd>
            </React.Fragment>
        )}
      </dl>

      <label className="block border-t border-line pt-4">
        <span className="text-[12px] font-medium text-faint">Status</span>
        <select
          value={record.status}
          onChange={(e) => store.updateFeedback(record.id, { status: e.target.value as FeedbackStatus })}
          className="mt-1 h-10 w-full rounded-md border border-line bg-bg px-3 text-[14px] text-fg focus:border-line-strong focus:outline-none">
          
          {(Object.keys(STATUS_LABEL) as FeedbackStatus[]).map((s) =>
          <option key={s} value={s}>
              {STATUS_LABEL[s]}
            </option>
          )}
        </select>
      </label>

      <div>
        <label className="block">
          <span className="text-[12px] font-medium text-faint">Private note</span>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={3}
            className="mt-1 w-full rounded-md border border-line bg-bg px-3 py-2 text-[14px] text-fg focus:border-line-strong focus:outline-none" />
          
        </label>
        {noteDirty &&
        <div className="mt-2 flex gap-2">
            <Button size="sm" variant="primary" onClick={() => store.updateFeedback(record.id, { note })}>
              Save note
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setNote(record.note ?? '')}>
              Cancel
            </Button>
          </div>
        }
      </div>

      <div className="flex flex-wrap gap-2 border-t border-line pt-4">
        {record.status === 'archived' ?
        <Button size="sm" variant="secondary" onClick={() => store.updateFeedback(record.id, { status: 'new' })}>
            Restore
          </Button> :

        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            store.updateFeedback(record.id, { status: 'archived' });
            onClose();
          }}>
          
            Archive
          </Button>
        }
        <Button size="sm" variant="ghost" className="ml-auto text-faint hover:text-danger" onClick={() => setConfirmDelete(true)}>
          Delete permanently
        </Button>
      </div>

      <ConfirmDialog
        open={confirmDelete}
        title="Delete this feedback permanently?"
        confirmLabel="Delete permanently"
        onCancel={() => setConfirmDelete(false)}
        onConfirm={() => {
          store.deleteFeedback(record.id);
          setConfirmDelete(false);
          onClose();
        }}>
        
        The message, screenshot and note are removed for good. This can’t be undone.
      </ConfirmDialog>
    </div>);

}