import React from 'react';
import { PairDB } from '../../types/domain';
import { countForFirst, PairContext } from '../../utils/pairs';

interface TokenGridProps {
  tokens: string[];
  selected: string;
  onSelect: (t: string) => void;
  db: PairDB;
  ctx: PairContext;
}

/** First-token chooser as a compact matrix: token + fill count, scannable at a glance. */
export function TokenGrid({ tokens, selected, onSelect, db, ctx }: TokenGridProps) {
  const possible = Math.max(0, tokens.length - 1);
  return (
    <div role="listbox" aria-label="First letter" className="grid grid-cols-4 gap-1">
      {tokens.map((t) => {
        const n = countForFirst(db, t, tokens, ctx);
        const on = t === selected;
        const full = n === possible && possible > 0;
        return (
          <button
            key={t}
            type="button"
            role="option"
            aria-selected={on}
            aria-label={`${t}, ${n} of ${possible}`}
            onClick={() => onSelect(t)}
            className={`flex h-12 flex-col items-center justify-center rounded-md transition-colors duration-150 ${
            on ? 'bg-fg text-bg' : 'text-fg hover:bg-raised'}`
            }>
            
            <span className="font-mono text-[15px] font-medium leading-none">{t}</span>
            <span className={`tnum mt-1 font-mono text-[10.5px] leading-none ${on ? 'text-bg/60' : full ? 'text-signal' : n === 0 ? 'text-faint/60' : 'text-faint'}`}>
              {n}
            </span>
          </button>);

      })}
    </div>);

}