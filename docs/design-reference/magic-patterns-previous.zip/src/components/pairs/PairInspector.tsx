import React, { useEffect, useState } from 'react';
import { XIcon } from 'lucide-react';
import { useStore } from '../../contexts/AppStore';
import { PairEntry } from '../../types/domain';
import { normalizeWords, PairContext, splitKey, suggestWords } from '../../utils/pairs';
import { Sheet } from '../ui/Sheet';
import { Segmented } from '../ui/Segmented';
import { Button } from '../ui/Button';
import { ConfirmDialog } from '../ui/ConfirmDialog';

interface Draft {
  shared: string[];
  edges: string[] | null;
  corners: string[] | null;
}

const toDraft = (e?: PairEntry): Draft => ({
  shared: e ? [...e.shared] : [],
  edges: e?.edges && e.edges.length ? [...e.edges] : null,
  corners: e?.corners && e.corners.length ? [...e.corners] : null
});

export function PairInspector({ pairKeyValue, initialCtx, onClose }: {pairKeyValue: string | null;initialCtx: PairContext;onClose: () => void;}) {
  const store = useStore();
  const entry = pairKeyValue ? store.pairs[pairKeyValue] : undefined;
  const [draft, setDraft] = useState<Draft>(toDraft(entry));
  const [tab, setTab] = useState<PairContext>(initialCtx);
  const [alt, setAlt] = useState('');
  const [sugPage, setSugPage] = useState<number | null>(null);
  const [notice, setNotice] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);

  useEffect(() => {
    setDraft(toDraft(entry));
    setTab(initialCtx);
    setAlt('');
    setSugPage(null);
    setNotice('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pairKeyValue]);

  if (!pairKeyValue) return <Sheet open={false} onClose={onClose} title="">{null}</Sheet>;
  const [a, b] = splitKey(pairKeyValue);

  const list: string[] | null = tab === 'shared' ? draft.shared : draft[tab];
  const setList = (l: string[]) => setDraft((d) => tab === 'shared' ? { ...d, shared: l } : { ...d, [tab]: l });
  const primary = list?.[0] ?? '';

  const setPrimary = (v: string) => {
    if (!list) return;
    setList(list.length ? [v, ...list.slice(1)] : [v]);
  };
  const removePrimary = () => {
    if (!list) return;
    const rest = list.slice(1);
    setList(rest);
    setNotice(rest[0] ? `“${rest[0]}” is now the primary word.` : 'Primary word removed.');
  };
  const addAlt = () => {
    if (!list || !alt.trim()) return;
    setList(list.length ? [...list, alt.trim()] : ['', alt.trim()]);
    setAlt('');
  };
  const promote = (i: number) => {
    if (!list) return;
    const next = [...list];
    [next[0], next[i]] = [next[i], next[0]];
    setList(next);
  };
  const removeAlt = (i: number) => list && setList(list.filter((_, k) => k !== i));

  const save = () => {
    const shared = normalizeWords(draft.shared);
    const edges = draft.edges ? normalizeWords(draft.edges) : [];
    const corners = draft.corners ? normalizeWords(draft.corners) : [];
    if (!shared.length && !edges.length && !corners.length) store.savePair(pairKeyValue, null);else

    store.savePair(pairKeyValue, {
      shared,
      edges: edges.length ? edges : undefined,
      corners: corners.length ? corners : undefined,
      usage: entry?.usage ?? 0
    });
    onClose();
  };

  const tabLabel = (c: PairContext, l: string) =>
  <span className="flex items-center gap-1.5">
      {l}
      {c !== 'shared' && draft[c] && <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" aria-label="override" />}
    </span>;


  return (
    <>
      <Sheet
        open
        onClose={onClose}
        title={
        <span className="font-mono text-[26px] font-medium tracking-[0.06em]">
            {a}
            {b}
          </span>
        }
        meta={entry?.usage ? `Used in ${entry.usage} ${entry.usage === 1 ? 'solve' : 'solves'}` : 'Not used in a solve yet'}
        widthClass="md:w-[460px]"
        footer={
        <div className="flex items-center gap-2">
            {entry ?
          <Button variant="ghost" className="text-faint hover:text-danger" onClick={() => setConfirmClear(true)}>
                Clear pair
              </Button> :

          <Button variant="ghost" onClick={() => setDraft({ shared: [], edges: null, corners: null })}>
                Clear
              </Button>
          }
            <div className="ml-auto flex gap-2">
              <Button variant="ghost" onClick={onClose}>
                Cancel
              </Button>
              <Button variant="primary" onClick={save}>
                Save
              </Button>
            </div>
          </div>
        }>
        
        <Segmented<PairContext>
          stretch
          label="Vocabulary scope"
          value={tab}
          onChange={(v) => {
            setTab(v);
            setSugPage(null);
          }}
          options={[
          { value: 'shared', label: 'Shared' },
          { value: 'edges', label: tabLabel('edges', 'Edges') },
          { value: 'corners', label: tabLabel('corners', 'Corners') }]
          } />
        

        <div className="mt-6">
          {list === null ?
          <div>
              <p className="text-[12px] font-medium text-faint">Uses shared</p>
              <p className="mt-1 font-serif text-[24px] italic text-muted">{draft.shared[0] || <span className="font-sans text-[15px] not-italic text-faint">Nothing yet</span>}</p>
              <Button className="mt-5" variant="secondary" onClick={() => setDraft((d) => ({ ...d, [tab]: [] }))}>
                Different word for {tab}
              </Button>
            </div> :

          <div className="space-y-6">
              <label className="block">
                <span className="text-[12px] font-medium text-faint">{tab === 'shared' ? 'Mnemonic' : `${tab === 'edges' ? 'Edge' : 'Corner'} mnemonic`}</span>
                <div className="mt-1 flex items-center gap-2">
                  <input
                  data-autofocus
                  value={primary}
                  onChange={(e) => setPrimary(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      save();
                    }
                  }}
                  placeholder="Primary word"
                  className="h-12 min-w-0 flex-1 border-b border-line-strong bg-transparent font-serif text-[24px] italic text-fg placeholder:font-sans placeholder:text-[15px] placeholder:not-italic placeholder:text-faint focus:border-signal focus:outline-none" />
                
                  {primary &&
                <Button size="sm" variant="ghost" onClick={removePrimary}>
                      Remove
                    </Button>
                }
                </div>
              </label>
              <p className="sr-only" aria-live="polite">
                {notice}
              </p>
              {notice && <p className="-mt-3 text-[12.5px] text-muted">{notice}</p>}

              <div>
                <span className="text-[12px] font-medium text-faint">Alternates</span>
                {list.length > 1 ?
              <ul className="mt-2 flex flex-wrap gap-1.5">
                    {list.slice(1).map((w, i) =>
                <li key={`${w}-${i}`} className="flex items-center rounded-md border border-line">
                        <button
                    type="button"
                    onClick={() => promote(i + 1)}
                    title="Make primary"
                    className="h-8 pl-2.5 pr-1.5 font-serif text-[15px] italic text-fg hover:text-signal">
                    
                          {w}
                        </button>
                        <button
                    type="button"
                    aria-label={`Remove ${w}`}
                    onClick={() => removeAlt(i + 1)}
                    className="flex h-8 w-7 items-center justify-center text-faint hover:text-danger">
                    
                          <XIcon className="h-3 w-3" />
                        </button>
                      </li>
                )}
                  </ul> :

              <p className="mt-1 text-[13px] text-faint">None</p>
              }
                <input
                value={alt}
                onChange={(e) => setAlt(e.target.value)}
                onBlur={addAlt}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addAlt();
                  }
                }}
                placeholder="Add alternate"
                aria-label="Add alternate"
                className="mt-3 h-10 w-full rounded-md border border-line bg-bg px-3 text-[14px] text-fg placeholder:text-faint focus:border-line-strong focus:outline-none" />
              
              </div>

              <div>
                {sugPage === null ?
              <button
                type="button"
                onClick={() => setSugPage(0)}
                className="h-8 text-[13px] text-muted underline decoration-line-strong underline-offset-4 hover:text-fg">
                
                    Suggest words
                  </button> :

              <div className="flex flex-wrap items-center gap-1.5">
                    {suggestWords(a, b, sugPage).map((w) =>
                <button
                  key={w}
                  type="button"
                  onClick={() => primary ? setList([...list, w]) : setPrimary(w)}
                  className="h-8 rounded-md border border-line px-2.5 font-serif text-[15px] italic text-muted hover:border-line-strong hover:text-fg">
                  
                        {w}
                      </button>
                )}
                    <button type="button" onClick={() => setSugPage((p) => (p ?? 0) + 1)} className="h-8 px-2 text-[13px] text-muted hover:text-fg">
                      More
                    </button>
                  </div>
              }
              </div>

              {tab !== 'shared' &&
            <button
              type="button"
              onClick={() => setDraft((d) => ({ ...d, [tab]: null }))}
              className="h-8 text-[13px] text-muted hover:text-fg">
              
                  Use shared instead
                </button>
            }
            </div>
          }
        </div>
      </Sheet>
      <ConfirmDialog
        open={confirmClear}
        title={`Clear ${a}${b}?`}
        confirmLabel="Clear pair"
        onCancel={() => setConfirmClear(false)}
        onConfirm={() => {
          store.savePair(pairKeyValue, null);
          setConfirmClear(false);
          onClose();
        }}>
        
        Removes {(entry?.shared.length ?? 0) + (entry?.edges?.length ?? 0) + (entry?.corners?.length ?? 0)} words — the primary,
        alternates and any edge or corner override.
      </ConfirmDialog>
    </>);

}