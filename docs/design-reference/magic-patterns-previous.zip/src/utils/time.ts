import { Solve } from '../types/domain';

export function formatMs(ms: number): string {
  const cs = Math.floor(ms / 10);
  const totalSeconds = Math.floor(cs / 100);
  const hundredths = String(cs % 100).padStart(2, '0');
  if (totalSeconds >= 60) {
    const m = Math.floor(totalSeconds / 60);
    const s = String(totalSeconds % 60).padStart(2, '0');
    return `${m}:${s}.${hundredths}`;
  }
  return `${totalSeconds}.${hundredths}`;
}

export function effectiveMs(s: Pick<Solve, 'rawMs' | 'penalty'>): number | null {
  if (s.penalty === 'dnf') return null;
  return s.rawMs + (s.penalty === '+2' ? 2000 : 0);
}

export function formatResult(s: Pick<Solve, 'rawMs' | 'penalty'>): string {
  if (s.penalty === 'dnf') return 'DNF';
  const t = formatMs(effectiveMs(s) as number);
  return s.penalty === '+2' ? `${t}+` : t;
}

export interface SessionStats {
  best: number | null;
  mo3: number | 'dnf' | null;
  success: number;
  total: number;
}

/** Display mirror of production statistics: best, mo3 (DNF if any DNF), non-DNF fraction. */
export function sessionStats(newestFirst: Solve[]): SessionStats {
  const eff = newestFirst.map(effectiveMs);
  const valid = eff.filter((v): v is number => v !== null);
  const best = valid.length ? Math.min(...valid) : null;
  let mo3: number | 'dnf' | null = null;
  if (eff.length >= 3) {
    const last = eff.slice(0, 3);
    mo3 = last.some((v) => v === null) ? 'dnf' : (last as number[]).reduce((a, b) => a + b, 0) / 3;
  }
  return { best, mo3, success: valid.length, total: eff.length };
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}