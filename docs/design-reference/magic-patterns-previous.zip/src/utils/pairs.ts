import { PairDB, PairEntry } from '../types/domain';
import { suggestionBank } from '../data/vocabulary';

export type PairContext = 'shared' | 'edges' | 'corners';

export const pairKey = (a: string, b: string) => `${a}|${b}`;
export const splitKey = (key: string) => key.split('|') as [string, string];

/** Effective list: piece override if nonempty, else shared. */
export function effectiveWords(entry: PairEntry | undefined, ctx: PairContext): string[] {
  if (!entry) return [];
  if (ctx === 'edges' && entry.edges && entry.edges.length) return entry.edges;
  if (ctx === 'corners' && entry.corners && entry.corners.length) return entry.corners;
  return entry.shared;
}

export function hasOverride(entry: PairEntry | undefined, ctx: 'edges' | 'corners'): boolean {
  return !!entry && !!entry[ctx] && (entry[ctx] as string[]).length > 0;
}

export function normalizeWords(words: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  words.forEach((w) => {
    const t = w.trim();
    if (!t) return;
    const k = t.toLowerCase();
    if (seen.has(k)) return;
    seen.add(k);
    out.push(t);
  });
  return out;
}

export function countForFirst(db: PairDB, first: string, tokens: string[], ctx: PairContext): number {
  return tokens.filter((t) => t !== first && effectiveWords(db[pairKey(first, t)], ctx).length > 0).length;
}

/** Prototype suggestion source — production uses its own vocabulary suggester. */
export function suggestWords(a: string, b: string, page = 0): string[] {
  const la = a.toLowerCase();
  const lb = b.toLowerCase();
  const strong = suggestionBank.filter((w) => w.startsWith(la) && w.slice(1).includes(lb));
  const loose = suggestionBank.filter((w) => w.startsWith(la) && !strong.includes(w));
  const all = [...strong, ...loose];
  return all.slice(page * 4, page * 4 + 4);
}