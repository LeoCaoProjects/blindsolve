/**
 * PROTOTYPE STAND-IN ONLY.
 * Minimal facelet simulator so sample scrambles render a matching diagram.
 * Production BlindSolve's cubing engine remains the authority for cube state,
 * orientation and every BLD computation.
 */
import { CubeState, Face, FaceColor } from '../types/cube';

type V = [number, number, number];
type Grid<T> = Record<Face, T[]>;
interface Sticker<T> {
  p: V;
  n: V;
  c: T;
}

export const FACES: Face[] = ['U', 'L', 'F', 'R', 'B', 'D'];

const AXIS: Record<Face, V> = {
  U: [0, 1, 0],
  D: [0, -1, 0],
  R: [1, 0, 0],
  L: [-1, 0, 0],
  F: [0, 0, 1],
  B: [0, 0, -1]
};

const FRAME: Record<Face, {r: V;d: V;}> = {
  U: { r: [1, 0, 0], d: [0, 0, 1] },
  F: { r: [1, 0, 0], d: [0, -1, 0] },
  R: { r: [0, 0, -1], d: [0, -1, 0] },
  B: { r: [-1, 0, 0], d: [0, -1, 0] },
  L: { r: [0, 0, 1], d: [0, -1, 0] },
  D: { r: [1, 0, 0], d: [0, 0, -1] }
};

const dot = (a: V, b: V) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: V, b: V): V => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const rot = (v: V, a: V): V => {
  const c = cross(a, v);
  const d = dot(a, v);
  return [a[0] * d - c[0], a[1] * d - c[1], a[2] * d - c[2]];
};

function fromGrid<T>(grid: Grid<T>): Sticker<T>[] {
  return FACES.flatMap((f) =>
  grid[f].map((c, i) => {
    const row = Math.floor(i / 3);
    const col = i % 3;
    const { r, d } = FRAME[f];
    const n = AXIS[f];
    const p: V = [
    n[0] + r[0] * (col - 1) + d[0] * (row - 1),
    n[1] + r[1] * (col - 1) + d[1] * (row - 1),
    n[2] + r[2] * (col - 1) + d[2] * (row - 1)];

    return { p, n, c };
  })
  );
}

function toGrid<T>(stickers: Sticker<T>[]): Grid<T> {
  const out = { U: [], L: [], F: [], R: [], B: [], D: [] } as unknown as Grid<T>;
  stickers.forEach((s) => {
    const face = FACES.find((f) => dot(AXIS[f], s.n) === 1) as Face;
    const { r, d } = FRAME[face];
    out[face][(dot(s.p, d) + 1) * 3 + dot(s.p, r) + 1] = s.c;
  });
  return out;
}

function turn<T>(st: Sticker<T>[], axis: V, all: boolean): Sticker<T>[] {
  return st.map((s) => all || dot(s.p, axis) === 1 ? { p: rot(s.p, axis), n: rot(s.n, axis), c: s.c } : s);
}

export function solvedState(): CubeState {
  return {
    U: Array(9).fill('W'),
    L: Array(9).fill('O'),
    F: Array(9).fill('G'),
    R: Array(9).fill('R'),
    B: Array(9).fill('B'),
    D: Array(9).fill('Y')
  };
}

export function applyMoves(state: CubeState, moves: string): CubeState {
  let st = fromGrid(state);
  moves.
  trim().
  split(/\s+/).
  filter(Boolean).
  forEach((t) => {
    const f = t[0] as Face;
    if (!AXIS[f]) return;
    const times = t.includes('2') ? 2 : t.includes("'") ? 3 : 1;
    for (let k = 0; k < times; k++) st = turn(st, AXIS[f], false);
  });
  return toGrid(st);
}

export function scrambleState(scramble: string | null): CubeState {
  return scramble ? applyMoves(solvedState(), scramble) : solvedState();
}

export type ViewSeq = V[];

/** Whole-cube rotation that puts `top` on U and `front` on F (presentation only). */
export function viewRotation(top: FaceColor, front: FaceColor): ViewSeq {
  if (top === 'W' && front === 'G') return [];
  const pres: V[][] = [[], [[1, 0, 0]], [[1, 0, 0], [1, 0, 0]], [[-1, 0, 0]], [[0, 0, 1]], [[0, 0, -1]]];
  const base = fromGrid(solvedState());
  for (const pre of pres) {
    for (let k = 0; k < 4; k++) {
      const seq: V[] = [...pre, ...Array(k).fill([0, 1, 0] as V)];
      let st = base;
      seq.forEach((a) => st = turn(st, a, true));
      const s = toGrid(st);
      if (s.U[4] === top && s.F[4] === front) return seq;
    }
  }
  return [];
}

export function applyView<T>(grid: Grid<T>, seq: ViewSeq): Grid<T> {
  if (!seq.length) return grid;
  let st = fromGrid(grid);
  seq.forEach((a) => st = turn(st, a, true));
  return toGrid(st);
}

export const KEY_GRID: Grid<string> = Object.fromEntries(
  FACES.map((f) => [f, Array.from({ length: 9 }, (_, i) => `${f}${i}`)])
) as Grid<string>;

export const OPPOSITE: Record<FaceColor, FaceColor> = { W: 'Y', Y: 'W', G: 'B', B: 'G', R: 'O', O: 'R' };

export const COLOR_NAMES: Record<FaceColor, string> = {
  W: 'White',
  Y: 'Yellow',
  G: 'Green',
  B: 'Blue',
  R: 'Red',
  O: 'Orange'
};