import { SampleChallenge, SampleTarget } from '../data/trainingSamples';
import { MemoOrder, PairDB, PieceScope, TrainingAttempt } from '../types/domain';
import { effectiveWords, pairKey } from './pairs';

export type PieceKey = 'corners' | 'edges';

export function piecesFor(scope: PieceScope, order: MemoOrder): PieceKey[] {
  if (scope === 'edges') return ['edges'];
  if (scope === 'corners') return ['corners'];
  return order === 'corners' ? ['corners', 'edges'] : ['edges', 'corners'];
}

const M2_SWAP: Record<string, string> = { C: 'W', W: 'C', I: 'S', S: 'I' };

/** Display stand-in for the prepared execution representation (production owns the transform). */
export function executionTargets(c: SampleChallenge, piece: PieceKey, m2: boolean): SampleTarget[] {
  const raw = c[piece];
  if (piece !== 'edges' || !m2) return raw;
  return raw.map((t, i) => i % 2 === 1 && M2_SWAP[t.token] ? { ...t, token: M2_SWAP[t.token] } : t);
}

export interface TargetPair {
  tokens: SampleTarget[];
  word?: string;
}

export function toPairs(targets: SampleTarget[], piece: PieceKey, db?: PairDB): TargetPair[] {
  const out: TargetPair[] = [];
  for (let i = 0; i < targets.length; i += 2) {
    const t = targets.slice(i, i + 2);
    const word = t.length === 2 && db ? effectiveWords(db[pairKey(t[0].token, t[1].token)], piece)[0] : undefined;
    out.push({ tokens: t, word });
  }
  return out;
}

export type CompareStatus = 'correct' | 'wrong' | 'missing' | 'extra';

export function compareTokens(expected: string[], yours: string[]) {
  const n = Math.max(expected.length, yours.length);
  return Array.from({ length: n }, (_, i) => {
    const e = expected[i];
    const y = yours[i];
    const status: CompareStatus = e === undefined ? 'extra' : y === undefined ? 'missing' : e === y ? 'correct' : 'wrong';
    return { e, y, status };
  });
}

export function drillStats(list: TrainingAttempt[]) {
  const ok = list.filter((a) => a.success);
  const mean = list.length ? list.reduce((s, a) => s + a.durationMs, 0) / list.length : null;
  return { count: list.length, ok: ok.length, mean };
}