import { FaceColor } from '../types/cube';
import { applyView, solvedState, viewRotation } from './cube';

/**
 * Presentation helper: which top/front a drag-rotated cube now shows.
 * Production utils/view.ts remains authoritative for legal orientations.
 */
export function viewAfterDrag(top: FaceColor, front: FaceColor, offset: {x: number;y: number;}): {top: FaceColor;front: FaceColor;} {
  const shown = applyView(solvedState(), viewRotation(top, front));
  const c = { U: shown.U[4], D: shown.D[4], F: shown.F[4], B: shown.B[4], L: shown.L[4], R: shown.R[4] };
  const vx = Math.round(offset.x / 90);
  if (vx <= -1) return { top: c.B, front: c.U };
  if (vx >= 1) return { top: c.F, front: c.D };
  const steps = (Math.round(offset.y / 90) % 4 + 4) % 4;
  const ring = [c.F, c.L, c.B, c.R];
  return { top: c.U, front: ring[steps] };
}