import { Face, PieceKind, Scheme } from '../types/cube';
import { PieceScope } from '../types/domain';

export const LETTER_FACES: Face[] = ['U', 'L', 'F', 'R', 'B', 'D'];
const CORNER_SLOTS = [0, 2, 8, 6];
const EDGE_SLOTS = [1, 5, 7, 3];

export const SPEFFZ = 'ABCDEFGHIJKLMNOPQRSTUVWX'.split('');

export const EDGE_NAMES = [
'UB', 'UR', 'UF', 'UL', 'LU', 'LF', 'LD', 'LB', 'FU', 'FR', 'FD', 'FL',
'RU', 'RB', 'RD', 'RF', 'BU', 'BL', 'BD', 'BR', 'DF', 'DR', 'DB', 'DL'];

export const CORNER_NAMES = [
'UBL', 'UBR', 'UFR', 'UFL', 'LUB', 'LUF', 'LDF', 'LDB', 'FUL', 'FUR', 'FDR', 'FDL',
'RUF', 'RUB', 'RDB', 'RDF', 'BUR', 'BUL', 'BDL', 'BDR', 'DFL', 'DFR', 'DBR', 'DBL'];


export function slotKind(index: number): PieceKind | 'center' {
  if (index === 4) return 'center';
  return CORNER_SLOTS.includes(index) ? 'corner' : 'edge';
}

export function letterIndexOf(face: Face, index: number): number {
  const fi = LETTER_FACES.indexOf(face);
  const k = slotKind(index) === 'corner' ? CORNER_SLOTS.indexOf(index) : EDGE_SLOTS.indexOf(index);
  return fi * 4 + k;
}

export function stickerOf(kind: PieceKind, letterIndex: number): {face: Face;index: number;} {
  const face = LETTER_FACES[Math.floor(letterIndex / 4)];
  const slots = kind === 'corner' ? CORNER_SLOTS : EDGE_SLOTS;
  return { face, index: slots[letterIndex % 4] };
}

export function stickerKey(kind: PieceKind, letterIndex: number): string {
  const s = stickerOf(kind, letterIndex);
  return `${s.face}${s.index}`;
}

export function labelAt(scheme: Scheme, face: Face, index: number): string | undefined {
  const kind = slotKind(index);
  if (kind === 'center') return undefined;
  const li = letterIndexOf(face, index);
  return kind === 'corner' ? scheme.corners[li] : scheme.edges[li];
}

export function tokenIndex(scheme: Scheme, kind: PieceKind, token: string): number {
  return (kind === 'corner' ? scheme.corners : scheme.edges).indexOf(token);
}

export function stickerName(kind: PieceKind, letterIndex: number): string {
  return kind === 'corner' ? CORNER_NAMES[letterIndex] : EDGE_NAMES[letterIndex];
}

/** Tokens available for a scope, preserving scheme order and uniqueness. */
export function scopeTokens(scheme: Scheme, scope: PieceScope | 'shared'): string[] {
  const list =
  scope === 'edges' ? scheme.edges : scope === 'corners' ? scheme.corners : [...scheme.edges, ...scheme.corners];
  return Array.from(new Set(list.filter(Boolean)));
}

/** Greedy longest-match tokenizer for typed answers (custom multi-character tokens). */
export function tokenize(input: string, tokens: string[]): string[] {
  const clean = input.toUpperCase().replace(/\s+/g, '');
  const sorted = [...tokens].sort((a, b) => b.length - a.length);
  const out: string[] = [];
  let i = 0;
  while (i < clean.length) {
    const hit = sorted.find((t) => t && clean.startsWith(t, i));
    if (hit) {
      out.push(hit);
      i += hit.length;
    } else {
      out.push(clean[i]);
      i += 1;
    }
  }
  return out;
}

export function isSpeffz(scheme: {edges: string[];corners: string[];}): boolean {
  return scheme.edges.every((t, i) => t === SPEFFZ[i]) && scheme.corners.every((t, i) => t === SPEFFZ[i]);
}