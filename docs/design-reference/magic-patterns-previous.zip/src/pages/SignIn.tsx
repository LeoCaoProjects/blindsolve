import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../contexts/AppStore';
import { useSignInFlow } from '../hooks/useSignInFlow';
import { BrandMark } from '../components/shell/BrandMark';
import { ProviderButtons } from '../components/auth/ProviderButtons';
import { MigrationDialog } from '../components/auth/MigrationDialog';

export function SignInPage() {
  const store = useStore();
  const navigate = useNavigate();
  const flow = useSignInFlow(() => navigate('/settings#account'));
  const unconfigured = store.account.mode === 'unconfigured';

  return (
    <div className="flex h-dvh w-full flex-col bg-bg text-fg">
      <header className="flex h-14 shrink-0 items-center px-4 md:h-16 md:px-8">
        <Link to="/" className="flex items-center gap-2.5" aria-label="BlindSolve">
          <BrandMark size={18} />
          <span className="text-[14px] font-semibold tracking-[-0.01em]">BlindSolve</span>
        </Link>
        <Link to="/" className="ml-auto inline-flex h-9 items-center rounded-md px-3 text-[13px] text-muted hover:bg-raised hover:text-fg">
          Continue without signing in
        </Link>
      </header>
      <main className="flex flex-1 items-center justify-center overflow-y-auto px-5 py-8">
        <div className="w-full max-w-[360px]">
          <h1 className="text-[26px] font-semibold tracking-[-0.025em]">Sign in</h1>
          <p className="mt-2 text-[14px] leading-relaxed text-muted">
            Keep letter pairs, solves and practice in sync across devices. Your first sign-in creates the account.
          </p>
          <div className="mt-8">
            <ProviderButtons size="lg" pending={flow.pending} onStart={flow.start} onCancel={flow.cancel} />
          </div>
          {unconfigured &&
          <p className="mt-5 text-[12.5px] leading-relaxed text-faint">
              Sign-in isn’t configured on this deployment, so these buttons can’t complete. Everything stays on this device.
            </p>
          }
        </div>
      </main>
      <MigrationDialog open={flow.migrating} onDone={flow.finishMigration} />
    </div>);

}