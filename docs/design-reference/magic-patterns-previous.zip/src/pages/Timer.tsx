import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { ChevronUpIcon, RefreshCwIcon } from 'lucide-react';
import { useStore } from '../contexts/AppStore';
import { useTimer } from '../contexts/TimerContext';
import { useChrome } from '../contexts/ChromeContext';
import { useHoldToStart } from '../hooks/useHoldToStart';
import { clamp, useViewport } from '../hooks/useViewport';
import { scrambleState } from '../utils/cube';
import { isTypingTarget, overlayOpen } from '../utils/dom';
import { formatMs, formatResult, sessionStats } from '../utils/time';
import { Button } from '../components/ui/Button';
import { Kbd } from '../components/ui/Kbd';
import { Sheet } from '../components/ui/Sheet';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { CubeFigure } from '../components/cube/CubeFigure';
import { ScrambleText } from '../components/timer/ScrambleText';
import { TimerReadout } from '../components/timer/TimerReadout';
import { HistoryPanel } from '../components/timer/HistoryPanel';
import { SessionsSheet } from '../components/timer/SessionsSheet';
import { SolveDetailsSheet } from '../components/timer/SolveDetailsSheet';
import { ReconstructionWorkbench } from '../components/reconstruction/ReconstructionWorkbench';

export function TimerPage() {
  const store = useStore();
  const timer = useTimer();
  const { setQuiet } = useChrome();
  const { h } = useViewport();
  const [letters, setLetters] = useState(false);
  const [sessionsOpen, setSessionsOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [cubeOpen, setCubeOpen] = useState(false);
  const [detailsId, setDetailsId] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<'latest' | 'clear' | null>(null);

  const live = timer.phase === 'memo' || timer.phase === 'exec' || timer.phase === 'running';
  const ready = timer.scrambleStatus === 'ready' && !!timer.scramble;
  const canStart = ready && !live && !timer.reconstructionOpen;
  const hold = useHoldToStart({ enabled: canStart, onStart: () => timer.start(store.prefs.multiphase) });
  const cube = useMemo(() => scrambleState(timer.scramble), [timer.scramble]);
  const stats = sessionStats(store.sessionSolves);
  const session = store.sessions.find((s) => s.id === store.activeSessionId);
  const latest = store.sessionSolves[0];
  const recede = live || hold.state !== 'idle';

  useEffect(() => {
    setQuiet(recede);
    return () => setQuiet(false);
  }, [recede, setQuiet]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target) || overlayOpen()) return;
      if (e.code === 'Space' && live) {
        e.preventDefault();
        if (!e.repeat) timer.press();
        return;
      }
      if (live || e.metaKey || e.ctrlKey || e.altKey) return;
      if ((e.key === 'n' || e.key === 'N') && timer.scrambleStatus !== 'preparing') {
        e.preventDefault();
        timer.newScramble();
      }
      if ((e.key === 'Backspace' || e.key === 'Delete') && store.sessionSolves.length > 0) {
        e.preventDefault();
        setConfirm(e.shiftKey ? 'clear' : 'latest');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [live, timer, store.sessionSolves.length]);

  const surface = live ?
  {
    onPointerDown: (e: React.PointerEvent) => {
      if (!overlayOpen()) {
        e.preventDefault();
        timer.press();
      }
    }
  } :
  hold.handlers;

  const cubeSize = clamp(Math.round((h - 340) * 0.5), 132, 232);
  const resultText = timer.phase === 'stopped' && latest ? formatResult(latest) : undefined;

  return (
    <div className="flex h-full w-full">
      <div className="flex min-w-0 flex-1 flex-col">
        <section
          aria-label="Scramble"
          className={`px-4 pt-4 transition-opacity duration-200 ease-out md:px-10 md:pt-8 short:md:pt-5 ${recede ? 'opacity-[0.12]' : ''}`}>
          
          <div className="flex items-start gap-4 md:gap-10">
            <div className="min-w-0 flex-1">
              {timer.scrambleStatus === 'failed' ?
              <div role="alert" className="py-1">
                  <p className="text-[17px] text-fg md:text-[20px]">Scramble unavailable.</p>
                  <Button className="mt-3" size="sm" variant="primary" onClick={timer.newScramble}>
                    <RefreshCwIcon className="h-3.5 w-3.5" /> Try again
                  </Button>
                </div> :

              <ScrambleText
                scramble={timer.scramble}
                preparing={timer.scrambleStatus === 'preparing'}
                className="max-w-[40ch]" />

              }
              {timer.scrambleStatus !== 'failed' &&
              <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 short:mt-2">
                  <Button
                  size="sm"
                  variant="ghost"
                  className="-ml-3"
                  onClick={timer.newScramble}
                  disabled={live || timer.scrambleStatus === 'preparing'}>
                  
                    <RefreshCwIcon className={`h-3.5 w-3.5 ${timer.scrambleStatus === 'preparing' ? 'animate-spin' : ''}`} />
                    New scramble <Kbd>N</Kbd>
                  </Button>
                  {timer.replaceFailed &&
                <span role="status" className="text-[12.5px] text-danger">
                      New scramble failed
                    </span>
                }
                </div>
              }
            </div>

            <div className="hidden shrink-0 flex-col items-center md:flex">
              <CubeFigure
                state={cube}
                scheme={store.scheme}
                viewTop={store.setup.viewTop}
                viewFront={store.setup.viewFront}
                size={cubeSize}
                label="Cube after scramble, white top green front"
                showLabels={letters}
                resetKey={timer.scramble} />
              
              <button
                type="button"
                aria-pressed={letters}
                onClick={() => setLetters((l) => !l)}
                className={`-mt-1 h-7 rounded-md px-2 text-[12px] transition-colors duration-150 ${
                letters ? 'text-fg' : 'text-faint hover:text-muted'}`
                }>
                
                Sticker letters
              </button>
            </div>

            <button
              type="button"
              onClick={() => setCubeOpen(true)}
              aria-label="Inspect cube"
              className="shrink-0 rounded-md p-1 transition-colors duration-150 hover:bg-raised md:hidden">
              
              <CubeFigure
                state={cube}
                scheme={store.scheme}
                viewTop={store.setup.viewTop}
                viewFront={store.setup.viewFront}
                size={68}
                flat
                label="Cube after scramble" />
              
            </button>
          </div>
        </section>

        <section
          aria-label="Timing surface. Hold to start."
          {...surface}
          className="relative flex min-h-0 flex-1 touch-none select-none flex-col items-center justify-center px-4">
          
          <TimerReadout
            phase={timer.phase}
            hold={hold.state}
            startAt={timer.startAt}
            splitAt={timer.splitAt}
            result={timer.result}
            resultText={resultText}
            showLive={store.prefs.showLiveTimer}
            multiphase={store.prefs.multiphase} />
          
          {!live && hold.state === 'idle' && store.sessionSolves.length === 0 && ready &&
          <p className="absolute bottom-6 text-[12.5px] text-faint">
              <span className="hidden md:inline">Hold Space to start</span>
              <span className="md:hidden">Touch and hold to start</span>
            </p>
          }
        </section>

        <button
          type="button"
          onClick={() => setHistoryOpen(true)}
          className={`mx-4 mb-2 flex h-12 items-center gap-3 rounded-lg border border-line px-3 text-left transition-opacity duration-200 hover:bg-raised md:mx-10 md:mb-6 lg:hidden ${
          recede ? 'pointer-events-none opacity-0' : ''}`
          }>
          
          <span className="min-w-0 truncate text-[13.5px] font-medium text-fg">{session?.name}</span>
          <span className="tnum flex shrink-0 gap-3 font-mono text-[12.5px] text-muted">
            <span>
              <span className="font-sans text-faint">best </span>
              {stats.best !== null ? formatMs(stats.best) : '—'}
            </span>
            <span className="hidden min-[360px]:inline">
              <span className="font-sans text-faint">mo3 </span>
              {stats.mo3 === null ? '—' : stats.mo3 === 'dnf' ? 'DNF' : formatMs(stats.mo3)}
            </span>
          </span>
          <ChevronUpIcon className="ml-auto h-4 w-4 shrink-0 text-faint" aria-hidden />
          <span className="sr-only">Open history</span>
        </button>
      </div>

      <aside
        aria-label="Session history"
        className={`hidden w-[320px] shrink-0 border-l border-line px-6 pb-4 pt-8 transition-opacity duration-200 ease-out lg:block xl:w-[340px] short:pt-5 ${
        recede ? 'opacity-[0.12]' : ''}`
        }>
        
        <HistoryPanel onOpenSessions={() => setSessionsOpen(true)} onOpenSolve={setDetailsId} onAskClear={() => setConfirm('clear')} />
      </aside>

      <Sheet open={historyOpen} onClose={() => setHistoryOpen(false)} title="History" widthClass="md:w-[380px]">
        <div className="h-[64dvh] md:h-full">
          <HistoryPanel
            onOpenSessions={() => setSessionsOpen(true)}
            onOpenSolve={(id) => setDetailsId(id)}
            onAskClear={() => setConfirm('clear')} />
          
        </div>
      </Sheet>

      <Sheet open={cubeOpen} onClose={() => setCubeOpen(false)} title="Scrambled cube" meta="White top, green front">
        <div className="flex flex-col items-center gap-3 py-2">
          <CubeFigure
            state={cube}
            scheme={store.scheme}
            viewTop={store.setup.viewTop}
            viewFront={store.setup.viewFront}
            size={250}
            label="Cube after scramble"
            showLabels={letters}
            resetKey={timer.scramble} />
          
          <Button size="sm" variant={letters ? 'quiet' : 'ghost'} aria-pressed={letters} onClick={() => setLetters((l) => !l)}>
            Sticker letters {letters ? 'on' : 'off'}
          </Button>
          <ScrambleText scramble={timer.scramble} size="sm" className="mt-2 text-center" />
        </div>
      </Sheet>

      <SessionsSheet open={sessionsOpen} onClose={() => setSessionsOpen(false)} />
      <SolveDetailsSheet solveId={detailsId} onClose={() => setDetailsId(null)} />

      <ConfirmDialog
        open={confirm === 'latest'}
        title="Delete latest solve?"
        confirmLabel="Delete"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          if (latest) store.deleteSolve(latest.id);
          setConfirm(null);
        }}>
        
        {latest && `Solve ${store.sessionSolves.length} · ${formatResult(latest)}`}
      </ConfirmDialog>
      <ConfirmDialog
        open={confirm === 'clear'}
        title={`Clear “${session?.name ?? ''}”?`}
        confirmLabel="Clear all"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          store.clearSessionSolves();
          setConfirm(null);
        }}>
        
        Removes all {store.sessionSolves.length} solves in this session. The session stays.
      </ConfirmDialog>

      <AnimatePresence>
        {timer.reconstructionOpen && timer.pendingSolveId &&
        <ReconstructionWorkbench key={timer.pendingSolveId} solveId={timer.pendingSolveId} />
        }
      </AnimatePresence>
    </div>);

}