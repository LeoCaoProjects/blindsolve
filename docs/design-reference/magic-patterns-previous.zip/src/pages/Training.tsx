import React, { useEffect, useState } from 'react';
import { ChevronDownIcon, HistoryIcon } from 'lucide-react';
import { useTraining } from '../contexts/TrainingContext';
import { useChrome } from '../contexts/ChromeContext';
import { trainingModes } from '../data/trainingModes';
import { PieceScope } from '../types/domain';
import { Segmented } from '../components/ui/Segmented';
import { Sheet } from '../components/ui/Sheet';
import { Button } from '../components/ui/Button';
import { ModeList } from '../components/training/ModeList';
import { TrainingHistory } from '../components/training/TrainingHistory';
import { HelpSheet } from '../components/training/HelpSheet';
import { DrillClocks } from '../components/training/DrillClocks';
import { ExecutionSprint } from '../components/training/ExecutionSprint';
import { GuidedSolve } from '../components/training/GuidedSolve';
import { MemoRecall } from '../components/training/MemoRecall';
import { TraceSprint } from '../components/training/TraceSprint';
const LIVE = ['active', 'memo', 'exec', 'study', 'recall'];
export function TrainingPage() {
  const t = useTraining();
  const {
    setQuiet
  } = useChrome();
  const [modesOpen, setModesOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const info = trainingModes.find((m) => m.id === t.mode)!;
  const s = t.drills[t.mode];
  const live = LIVE.includes(s.phase);
  useEffect(() => {
    setQuiet(live);
    return () => setQuiet(false);
  }, [live, setQuiet]);
  const scope = <Segmented<PieceScope> size="sm" label="Pieces" value={t.scope} onChange={t.setScope} disabled={t.busy} options={[{
    value: 'both',
    label: 'Both'
  }, {
    value: 'edges',
    label: 'Edges'
  }, {
    value: 'corners',
    label: 'Corners'
  }]} />;
  const mobileScope = <div className="lg:hidden">{scope}</div>;
  return <div className="flex h-full w-full">
      <aside className="hidden w-[264px] shrink-0 flex-col border-r border-line px-4 pb-4 pt-7 lg:flex short:pt-4">
        <h1 className="mb-2 px-3 text-[12px] font-medium text-faint">Training</h1>
        <ModeList />
        <div className={`mt-6 px-3 transition-opacity duration-150 ${t.busy ? 'opacity-40' : ''}`}>
          <span className="mb-2 block text-[12px] font-medium text-faint">Pieces</span>
          {scope}
        </div>
        <button type="button" onClick={() => setHelpOpen(true)} className="mt-auto flex h-9 items-center gap-2 rounded-md px-3 text-[13px] text-muted hover:bg-raised hover:text-fg">
          <div className="h-4 w-4" /> How {info.short} works
        </button>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-2 px-4 md:h-16 md:px-10">
          <button type="button" onClick={() => setModesOpen(true)} disabled={t.busy} className="-ml-2 flex h-10 min-w-0 items-center gap-1.5 rounded-md px-2 text-left hover:bg-raised disabled:pointer-events-none lg:hidden">
            <span className="truncate text-[16px] font-semibold tracking-[-0.01em]">{info.name}</span>
            {!t.busy && <ChevronDownIcon className="h-4 w-4 shrink-0 text-faint" />}
          </button>
          <h2 className="hidden text-[18px] font-semibold tracking-[-0.015em] lg:block">{info.name}</h2>

          <div className="ml-auto flex items-center gap-1">
            {t.busy ? <DrillClocks mode={t.mode} s={s} /> : <>
                <Button size="icon" variant="ghost" className="lg:hidden" aria-label={`How ${info.name} works`} onClick={() => setHelpOpen(true)}>
                  <div className="h-[18px] w-[18px]" />
                </Button>
                <Button size="sm" variant="ghost" className="xl:hidden" onClick={() => setHistoryOpen(true)}>
                  <HistoryIcon className="h-4 w-4" /> <span className="hidden sm:inline">History</span>
                  <span className="sr-only sm:hidden">History</span>
                </Button>
              </>}
          </div>
        </header>

        {t.mode === 'exec' && <ExecutionSprint setupExtra={mobileScope} />}
        {t.mode === 'guided' && <GuidedSolve setupExtra={mobileScope} />}
        {t.mode === 'recall' && <MemoRecall setupExtra={mobileScope} />}
        {t.mode === 'trace' && <TraceSprint setupExtra={mobileScope} />}
      </div>

      <aside aria-label={`${info.name} history`} className={`hidden w-[300px] shrink-0 flex-col border-l border-line px-6 pb-4 pt-7 transition-opacity duration-200 xl:flex short:pt-4 ${live ? 'opacity-[0.12]' : ''}`}>
        <h2 className="mb-3 text-[12px] font-medium text-faint">History</h2>
        <TrainingHistory listenKeys />
      </aside>

      <Sheet open={modesOpen} onClose={() => setModesOpen(false)} title="Drill" widthClass="md:w-[360px]">
        <ModeList onPicked={() => setModesOpen(false)} />
      </Sheet>
      <Sheet open={historyOpen} onClose={() => setHistoryOpen(false)} title={`${info.name} history`} widthClass="md:w-[360px]">
        <div className="h-[60dvh] md:h-full">
          <TrainingHistory />
        </div>
      </Sheet>
      <HelpSheet open={helpOpen} onClose={() => setHelpOpen(false)} />
    </div>;
}