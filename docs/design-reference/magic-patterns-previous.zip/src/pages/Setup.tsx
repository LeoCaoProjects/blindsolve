import React, { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CheckIcon, ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
import { DEFAULT_SETUP, useStore } from '../contexts/AppStore';
import { Face, PieceKind } from '../types/cube';
import { SetupDraft } from '../types/domain';
import { solvedState } from '../utils/cube';
import { letterIndexOf, slotKind, SPEFFZ, stickerKey, stickerName } from '../utils/lettering';
import { clamp, useViewport } from '../hooks/useViewport';
import { useIsDesktop } from '../hooks/useMediaQuery';
import { Button } from '../components/ui/Button';
import { CubeFigure } from '../components/cube/CubeFigure';
import { BrandMark } from '../components/shell/BrandMark';

const STEPS = ['Lettering', 'Edge buffer', 'Corner buffer', 'Ready'] as const;
const COMMON: Record<PieceKind, {label: string;idx: number;}[]> = {
  edge: [
  { label: 'UF', idx: 2 },
  { label: 'DF', idx: 20 },
  { label: 'UR', idx: 1 },
  { label: 'UB', idx: 0 }],

  corner: [
  { label: 'UFR', idx: 2 },
  { label: 'UBL', idx: 4 },
  { label: 'UFL', idx: 3 },
  { label: 'DFR', idx: 21 }]

};

export function SetupPage() {
  const store = useStore();
  const navigate = useNavigate();
  const desktop = useIsDesktop();
  const { h } = useViewport();
  const [step, setStep] = useState(0);
  const [custom, setCustom] = useState(false);
  const [draft, setDraft] = useState<SetupDraft>({ ...DEFAULT_SETUP });
  const [sel, setSel] = useState<{kind: PieceKind;idx: number;}>({ kind: 'edge', idx: 0 });
  const cube = useMemo(() => solvedState(), []);
  const cubeSize = desktop ? clamp(h - 260, 240, 360) : clamp(Math.round(h * 0.27), 140, 220);

  const kindForStep: PieceKind | null = step === 1 ? 'edge' : step === 2 ? 'corner' : null;
  const selectedKey =
  step === 0 && custom ? stickerKey(sel.kind, sel.idx) : step === 1 ? stickerKey('edge', draft.edgeBuffer) : step === 2 ? stickerKey('corner', draft.cornerBuffer) : null;

  const onSticker = (face: Face, index: number) => {
    const k = slotKind(index);
    if (k === 'center') return;
    const li = letterIndexOf(face, index);
    if (step === 0 && custom) setSel({ kind: k, idx: li });
    if (step === 1 && k === 'edge') setDraft((d) => ({ ...d, edgeBuffer: li }));
    if (step === 2 && k === 'corner') setDraft((d) => ({ ...d, cornerBuffer: li }));
  };

  const tokens = sel.kind === 'edge' ? draft.edges : draft.corners;
  const setToken = (v: string) =>
  setDraft((d) => {
    const list = [...(sel.kind === 'edge' ? d.edges : d.corners)];
    list[sel.idx] = v.toUpperCase().replace(/\s+/g, '').slice(0, 3);
    return sel.kind === 'edge' ? { ...d, edges: list, schemeName: 'Custom' } : { ...d, corners: list, schemeName: 'Custom' };
  });
  const stepSticker = (dir: number) => setSel((s) => ({ ...s, idx: (s.idx + dir + 24) % 24 }));

  const finish = (setup: SetupDraft) => {
    store.saveSetup(setup);
    navigate('/');
  };

  return (
    <div className="flex h-dvh w-full flex-col bg-bg text-fg">
      <header className="flex h-14 shrink-0 items-center gap-4 px-4 md:h-16 md:px-8">
        <Link to="/" className="flex items-center gap-2.5" aria-label="BlindSolve">
          <BrandMark size={18} />
          <span className="hidden text-[14px] font-semibold tracking-[-0.01em] sm:inline">BlindSolve</span>
        </Link>
        <ol className="mx-auto hidden items-center gap-6 md:flex" aria-label="Setup steps">
          {STEPS.map((s, i) =>
          <li key={s} aria-current={i === step ? 'step' : undefined} className={`flex items-center gap-1.5 text-[13px] ${i === step ? 'font-medium text-fg' : i < step ? 'text-muted' : 'text-faint'}`}>
              {i < step ? <CheckIcon className="h-3.5 w-3.5 text-signal" /> : <span className="tnum font-mono text-[11.5px]">{i + 1}</span>}
              {s}
            </li>
          )}
        </ol>
        <div className="ml-auto flex items-center gap-1 md:ml-0">
          <Button size="sm" variant="ghost" onClick={() => finish({ ...DEFAULT_SETUP })}>
            Use defaults
          </Button>
          <Link to="/signin" className="inline-flex h-8 items-center rounded-md px-3 text-[13px] font-medium text-muted hover:bg-raised hover:text-fg">
            Sign in
          </Link>
        </div>
      </header>

      <main className="flex min-h-0 flex-1 flex-col md:flex-row md:items-center md:justify-center md:gap-16 md:px-10">
        <div className="flex shrink-0 justify-center pb-2 pt-1 md:pb-0">
          <CubeFigure
            state={cube}
            scheme={{ name: draft.schemeName, edges: draft.edges, corners: draft.corners }}
            viewTop="W"
            viewFront="G"
            size={cubeSize}
            showLabels={step !== 3}
            selected={selectedKey}
            onSticker={step < 3 && (step > 0 || custom) ? onSticker : undefined}
            isClickable={(_, i) => kindForStep ? slotKind(i) === kindForStep : slotKind(i) !== 'center'}
            label="Setup cube, white top green front" />
          
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-4 md:max-w-[420px] md:flex-none md:overflow-visible md:px-0">
          <p className="mb-1 text-[12.5px] text-faint md:hidden">
            {step + 1} · {STEPS[step]}
          </p>
          {step === 0 &&
          <>
              <h1 className="text-[22px] font-semibold tracking-[-0.02em] md:text-[26px]">How are your stickers lettered?</h1>
              <div role="radiogroup" aria-label="Lettering" className="mt-5 space-y-2">
                {[
              { id: false, title: 'Speffz', text: 'A–X on edges and on corners, reading each face clockwise from U.' },
              { id: true, title: 'Custom', text: 'Set your own label on each sticker.' }].
              map((o) =>
              <button
                key={o.title}
                type="button"
                role="radio"
                aria-checked={custom === o.id}
                onClick={() => {
                  setCustom(o.id);
                  if (!o.id) setDraft((d) => ({ ...d, edges: [...SPEFFZ], corners: [...SPEFFZ], schemeName: 'Speffz' }));
                }}
                className={`flex w-full items-start gap-3 rounded-md border p-3.5 text-left transition-colors duration-150 ${
                custom === o.id ? 'border-fg/70 bg-raised' : 'border-line hover:border-line-strong'}`
                }>
                
                    <span className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${custom === o.id ? 'border-fg' : 'border-line-strong'}`}>
                      {custom === o.id && <span className="h-2 w-2 rounded-full bg-fg" />}
                    </span>
                    <span>
                      <span className="block text-[14.5px] font-medium">{o.title}</span>
                      <span className="block text-[13px] text-muted">{o.text}</span>
                    </span>
                  </button>
              )}
              </div>
              {custom &&
            <div className="mt-6 flex items-end gap-3">
                  <label className="block">
                    <span className="text-[12px] font-medium text-faint">
                      {stickerName(sel.kind, sel.idx)} {sel.kind}
                    </span>
                    <input
                  value={tokens[sel.idx] ?? ''}
                  onChange={(e) => setToken(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === 'Tab') {
                      e.preventDefault();
                      stepSticker(e.shiftKey ? -1 : 1);
                    }
                  }}
                  maxLength={3}
                  className="mt-1 h-12 w-24 rounded-md border border-line-strong bg-bg text-center font-mono text-[24px] uppercase text-fg focus:border-signal focus:outline-none" />
                
                  </label>
                  <div className="flex gap-1 pb-1">
                    <Button size="icon" variant="secondary" aria-label="Previous sticker" onClick={() => stepSticker(-1)}>
                      <ChevronLeftIcon className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="secondary" aria-label="Next sticker" onClick={() => stepSticker(1)}>
                      <ChevronRightIcon className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
            }
            </>
          }

          {(step === 1 || step === 2) &&
          <>
              <h1 className="text-[22px] font-semibold tracking-[-0.02em] md:text-[26px]">{step === 1 ? 'Edge buffer' : 'Corner buffer'}</h1>
              <p className="mt-2 text-[14px] text-muted">Tap the buffer sticker on the cube, or pick a common one.</p>
              <p className="mt-5 flex items-baseline gap-3">
                <span className="font-mono text-[30px] font-medium leading-none">
                  {stickerName(step === 1 ? 'edge' : 'corner', step === 1 ? draft.edgeBuffer : draft.cornerBuffer)}
                </span>
                <span className="text-[13px] text-muted">
                  token{' '}
                  <span className="font-mono text-fg">
                    {step === 1 ? draft.edges[draft.edgeBuffer] : draft.corners[draft.cornerBuffer]}
                  </span>
                </span>
              </p>
              <div className="mt-5 flex flex-wrap gap-1.5">
                {COMMON[step === 1 ? 'edge' : 'corner'].map((c) => {
                const on = (step === 1 ? draft.edgeBuffer : draft.cornerBuffer) === c.idx;
                return (
                  <button
                    key={c.label}
                    type="button"
                    aria-pressed={on}
                    onClick={() => setDraft((d) => step === 1 ? { ...d, edgeBuffer: c.idx } : { ...d, cornerBuffer: c.idx })}
                    className={`h-9 rounded-md border px-3 font-mono text-[13.5px] ${on ? 'border-fg bg-fg text-bg' : 'border-line hover:border-line-strong'}`}>
                    
                      {c.label}
                    </button>);

              })}
              </div>
            </>
          }

          {step === 3 &&
          <>
              <h1 className="text-[22px] font-semibold tracking-[-0.02em] md:text-[26px]">Ready</h1>
              <dl className="mt-5 divide-y divide-line border-y border-line text-[14px]">
                {[
              ['Lettering', custom ? draft.schemeName || 'Custom' : 'Speffz'],
              ['Edge buffer', `${stickerName('edge', draft.edgeBuffer)} · ${draft.edges[draft.edgeBuffer]}`],
              ['Corner buffer', `${stickerName('corner', draft.cornerBuffer)} · ${draft.corners[draft.cornerBuffer]}`]].
              map(([k, v]) =>
              <div key={k} className="flex justify-between py-3">
                    <dt className="text-muted">{k}</dt>
                    <dd className="font-mono">{v}</dd>
                  </div>
              )}
              </dl>
              <p className="mt-4 text-[13px] text-muted">Scrambles are always applied with white on top and green in front.</p>
            </>
          }
        </div>
      </main>

      <footer className="flex shrink-0 items-center gap-2 border-t border-line px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:px-8">
        {step > 0 &&
        <Button variant="ghost" onClick={() => setStep((s) => s - 1)}>
            Back
          </Button>
        }
        {step < 3 ?
        <Button variant="primary" className="ml-auto" onClick={() => setStep((s) => s + 1)}>
            Continue
          </Button> :

        <Button variant="primary" className="ml-auto" onClick={() => finish(draft)}>
            Start timing
          </Button>
        }
      </footer>
    </div>);

}