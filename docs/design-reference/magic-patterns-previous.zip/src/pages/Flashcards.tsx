import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { HistoryIcon } from 'lucide-react';
import { useStore } from '../contexts/AppStore';
import { useFlashcards } from '../components/flashcards/useFlashcards';
import { FlashSidebar } from '../components/flashcards/FlashSidebar';
import { isTypingTarget, overlayOpen } from '../utils/dom';
import { splitKey } from '../utils/pairs';
import { Button } from '../components/ui/Button';
import { Sheet } from '../components/ui/Sheet';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';

export function FlashcardsPage() {
  const store = useStore();
  const fc = useFlashcards();
  const [draft, setDraft] = useState('');
  const [recentOpen, setRecentOpen] = useState(false);
  const [confirm, setConfirm] = useState<'latest' | 'clear' | null>(null);
  const latest = store.flashHistory[store.flashHistory.length - 1];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target) || overlayOpen() || e.repeat || e.metaKey || e.ctrlKey) return;
      const onButton = !!(e.target as HTMLElement).closest('button');
      if (e.key === 'Backspace' || e.key === 'Delete') {
        if (!store.flashHistory.length) return;
        e.preventDefault();
        setConfirm(e.shiftKey ? 'clear' : 'latest');
        return;
      }
      if (fc.phase === 'question' && (e.code === 'Space' || e.key === 'Enter') && !onButton) {
        e.preventDefault();
        fc.reveal();
      } else if (fc.phase === 'revealed') {
        if ((e.code === 'Space' || e.key === 'Enter') && !onButton) {
          e.preventDefault();
          fc.answer('remembered');
        }
        if (e.key === 'f' || e.key === 'F') fc.answer('forgot');
        if (e.key === 'e' || e.key === 'E') {
          e.preventDefault();
          setDraft(fc.words[0] ?? '');
          fc.setPhase('editing');
        }
        if (e.key === 'a' || e.key === 'A') {
          e.preventDefault();
          setDraft('');
          fc.setPhase('adding');
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const sidebar = (size: number) =>
  <FlashSidebar
    card={fc.card}
    cubeSize={size}
    onOpen={(v) => {
      fc.openRevealed(v);
      setRecentOpen(false);
    }}
    onAskClear={() => setConfirm('clear')} />;



  if (!fc.card) {
    return (
      <div className="flex h-full w-full items-center justify-center px-6">
        <div className="max-w-sm text-center">
          <h1 className="text-[22px] font-semibold tracking-[-0.02em]">No pairs yet</h1>
          <p className="mt-2 text-[14px] text-muted">Cards come from letter pairs that have a word.</p>
          <Link
            to="/pairs"
            className="mt-6 inline-flex h-10 items-center rounded-md bg-fg px-4 text-sm font-medium text-bg hover:bg-white">
            
            Add your first mnemonic
          </Link>
        </div>
      </div>);

  }

  const [a, b] = splitKey(fc.card.key);
  const editing = fc.phase === 'editing' || fc.phase === 'adding';
  const revealed = fc.phase !== 'question';

  return (
    <div className="flex h-full w-full">
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-3 px-4 md:h-16 md:px-10">
          <h1 className="text-[16px] font-semibold tracking-[-0.01em] lg:text-[18px]">Flashcards</h1>
          <span className="tnum font-mono text-[12.5px] text-faint">
            {fc.cardCount} {fc.cardCount === 1 ? 'card' : 'cards'}
          </span>
          <Button size="sm" variant="ghost" className="ml-auto lg:hidden" onClick={() => setRecentOpen(true)}>
            <HistoryIcon className="h-4 w-4" /> Recent
          </Button>
        </header>

        <div className="flex min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto px-4 pb-6">
          <div className="w-full max-w-[560px]">
            <div className="flex items-baseline justify-between text-[12.5px]">
              <span className="font-medium text-muted">{fc.card.kind === 'edge' ? 'Edge' : 'Corner'}</span>
              <span className="tnum font-mono text-faint">#{store.flashHistory.length + 1}</span>
            </div>
            <p className="mt-2 font-mono text-[clamp(72px,22vw,128px)] font-medium leading-none tracking-[0.04em] text-fg short:text-[72px]">
              {a}
              {b}
            </p>

            <div className="mt-8 min-h-[112px] border-t border-line pt-6 short:mt-5 short:pt-4" aria-live="polite">
              {fc.phase === 'question' &&
              <button
                type="button"
                onClick={fc.reveal}
                className="flex h-14 w-full items-center rounded-md border border-dashed border-line-strong px-4 text-left text-[14px] text-muted hover:border-faint hover:text-fg">
                
                  Reveal <span className="ml-auto hidden font-mono text-[11px] text-faint md:inline">Space</span>
                </button>
              }
              {fc.phase === 'revealed' &&
              <div>
                  <p className="break-words font-serif text-[40px] italic leading-tight text-fg md:text-[48px]">{fc.words[0]}</p>
                  {fc.words.length > 1 && <p className="mt-1 truncate text-[14px] text-muted">also {fc.words.slice(1).join(', ')}</p>}
                </div>
              }
              {editing &&
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (fc.phase === 'editing') fc.savePrimary(draft);else
                  fc.addAlternate(draft);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    e.stopPropagation();
                    fc.setPhase('revealed');
                  }
                }}>
                
                  {fc.phase === 'adding' && <p className="mb-2 font-serif text-[22px] italic text-muted">{fc.words[0]}</p>}
                  <label className="block">
                    <span className="text-[12px] font-medium text-faint">{fc.phase === 'editing' ? 'Primary word' : 'Alternate'}</span>
                    <input
                    autoFocus
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    className="mt-1 h-12 w-full border-b border-line-strong bg-transparent font-serif text-[28px] italic text-fg focus:border-signal focus:outline-none" />
                  
                  </label>
                  <div className="mt-4 flex gap-2">
                    <Button type="submit" variant="primary">
                      Save
                    </Button>
                    <Button variant="ghost" onClick={() => fc.setPhase('revealed')}>
                      Cancel
                    </Button>
                  </div>
                </form>
              }
            </div>

            {revealed &&
            <div className="mt-6 short:mt-4">
                <div className="grid grid-cols-2 gap-2">
                  <Button size="lg" variant="danger" disabled={editing} onClick={() => fc.answer('forgot')}>
                    Forgot <span className="hidden font-mono text-[11px] opacity-60 md:inline">F</span>
                  </Button>
                  <Button size="lg" variant="primary" disabled={editing} onClick={() => fc.answer('remembered')}>
                    Remembered <span className="hidden font-mono text-[11px] opacity-50 md:inline">↵</span>
                  </Button>
                </div>
                {!editing &&
              <div className="mt-2 flex justify-center gap-1">
                    <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setDraft(fc.words[0] ?? '');
                    fc.setPhase('editing');
                  }}>
                  
                      Edit <span className="hidden font-mono text-[10.5px] opacity-50 md:inline">E</span>
                    </Button>
                    <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setDraft('');
                    fc.setPhase('adding');
                  }}>
                  
                      Add alternate <span className="hidden font-mono text-[10.5px] opacity-50 md:inline">A</span>
                    </Button>
                  </div>
              }
              </div>
            }
          </div>
        </div>
      </div>

      <aside className="hidden w-[320px] shrink-0 border-l border-line px-6 pb-4 pt-7 lg:block short:pt-4">{sidebar(168)}</aside>

      <Sheet open={recentOpen} onClose={() => setRecentOpen(false)} title="Recent cards" widthClass="md:w-[380px]">
        <div className="h-[70dvh] md:h-full">{sidebar(140)}</div>
      </Sheet>

      <ConfirmDialog
        open={confirm === 'latest'}
        title="Remove latest card?"
        confirmLabel="Remove"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          if (latest) store.deleteFlash(latest.id);
          setConfirm(null);
        }}>
        
        {latest && `${splitKey(latest.key).join('')} · ${latest.outcome === 'forgot' ? 'Forgot' : 'Remembered'}. Words and counters stay.`}
      </ConfirmDialog>
      <ConfirmDialog
        open={confirm === 'clear'}
        title="Clear flashcard history?"
        confirmLabel="Clear all"
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          store.clearFlash();
          setConfirm(null);
        }}>
        
        Removes all {store.flashHistory.length} recent cards. Your words and the seen/remembered/forgot counters stay.
      </ConfirmDialog>
    </div>);

}