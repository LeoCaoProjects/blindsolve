import React, { useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Loader2Icon } from 'lucide-react';
import { useStore } from '../contexts/AppStore';
import { SetupDraft } from '../types/domain';
import { COLOR_NAMES } from '../utils/cube';
import { isSpeffz, stickerName } from '../utils/lettering';
import { Button } from '../components/ui/Button';
import { Segmented } from '../components/ui/Segmented';
import { Toggle } from '../components/ui/Toggle';
import { SettingRow } from '../components/settings/SettingRow';
import { CubeEditor, EditorMode } from '../components/settings/CubeEditor';
import { AccountPanel } from '../components/settings/AccountPanel';
import { DataPanel } from '../components/settings/DataPanel';
import { FeedbackSheet } from '../components/feedback/FeedbackSheet';
import { STICKER_HEX } from '../components/cube/Cube3D';

const SECTIONS = [
{ id: 'cube', label: 'Cube & lettering', short: 'Cube' },
{ id: 'methods', label: 'Methods', short: 'Methods' },
{ id: 'timer', label: 'Timer', short: 'Timer' },
{ id: 'account', label: 'Account & sync', short: 'Account' },
{ id: 'data', label: 'Data', short: 'Data' },
{ id: 'support', label: 'Support', short: 'Support' }];


export function SettingsPage() {
  const store = useStore();
  const { hash } = useLocation();
  const [draft, setDraftState] = useState<SetupDraft>(store.setup);
  const [editor, setEditor] = useState<EditorMode | null>(null);
  const [lastMode, setLastMode] = useState<EditorMode>('lettering');
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [current, setCurrent] = useState('cube');
  const [saving, setSaving] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const saved = store.setup;
  const dirty = JSON.stringify(draft) !== JSON.stringify(saved);
  const setDraft = (fn: (d: SetupDraft) => SetupDraft) => setDraftState(fn);

  useEffect(() => setDraftState(store.setup), [store.setup]);

  useEffect(() => {
    store.setSettingsDirty(dirty);
    store.leaveHandlers.current = { save: () => store.saveSetup(draft), discard: () => setDraftState(store.setup) };
  });
  useEffect(
    () => () => {
      store.setSettingsDirty(false);
      store.leaveHandlers.current = null;
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  useEffect(() => {
    const root = scrollRef.current;
    if (!root || !store.ready) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (vis) setCurrent(vis.target.id);
      },
      { root, rootMargin: '0px 0px -65% 0px' }
    );
    SECTIONS.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) obs.observe(el);
    });
    if (hash) document.getElementById(hash.slice(1))?.scrollIntoView();
    return () => obs.disconnect();
  }, [store.ready, hash]);

  const jump = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setCurrent(id);
  };
  const openEditor = (m: EditorMode) => {
    setLastMode(m);
    setEditor(m);
  };
  const save = () => {
    setSaving(true);
    window.setTimeout(() => {
      store.saveSetup(draft);
      setSaving(false);
    }, 450);
  };

  if (!store.ready) {
    return (
      <div className="flex h-full items-center justify-center gap-2 text-[14px] text-muted" role="status">
        <Loader2Icon className="h-4 w-4 animate-spin" /> Loading account settings…
      </div>);

  }

  const isAdmin = store.account.mode === 'admin';
  const newFeedback = store.feedback.filter((f) => f.status === 'new').length;

  return (
    <div className="flex h-full w-full">
      <nav aria-label="Settings sections" className="hidden w-[220px] shrink-0 flex-col border-r border-line px-4 pb-4 pt-7 md:flex short:pt-4">
        <h1 className="mb-3 px-2 text-[12px] font-medium text-faint">Settings</h1>
        <ul className="space-y-0.5">
          {SECTIONS.map((s) =>
          <li key={s.id}>
              <button
              type="button"
              aria-current={current === s.id ? 'true' : undefined}
              onClick={() => jump(s.id)}
              className={`flex h-9 w-full items-center rounded-md px-2 text-left text-[13.5px] transition-colors duration-150 ${
              current === s.id ? 'bg-raised text-fg' : 'text-muted hover:text-fg'}`
              }>
              
                {s.label}
                {s.id === 'cube' && dirty && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-warn" aria-label="unsaved changes" />}
              </button>
            </li>
          )}
        </ul>
        <div className="mt-auto space-y-0.5 border-t border-line pt-3">
          <Link to="/setup" className="flex h-9 items-center rounded-md px-2 text-[13px] text-muted hover:text-fg">
            Run first-use setup
          </Link>
          {isAdmin &&
          <Link to="/admin/feedback" className="flex h-9 items-center rounded-md px-2 text-[13px] text-muted hover:text-fg">
              Feedback inbox
              {newFeedback > 0 && <span className="tnum ml-auto font-mono text-[11.5px] text-signal">{newFeedback}</span>}
            </Link>
          }
        </div>
      </nav>

      <div ref={scrollRef} className="relative min-w-0 flex-1 overflow-y-auto overscroll-contain">
        <div className="mx-auto max-w-[700px] px-4 pb-24 pt-4 md:px-10 md:pt-7 short:md:pt-4">
          <div className="mb-2 md:hidden">
            <h1 className="text-[20px] font-semibold tracking-[-0.02em]">Settings</h1>
            <p className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[13px]">
              {SECTIONS.map((s) =>
              <button key={s.id} type="button" onClick={() => jump(s.id)} className="h-7 text-muted underline-offset-4 hover:text-fg hover:underline">
                  {s.short}
                </button>
              )}
            </p>
          </div>

          <Section id="cube" title="Cube & lettering">
            <SettingRow label="Lettering" changed={draft.schemeName !== saved.schemeName || draft.edges.join() !== saved.edges.join() || draft.corners.join() !== saved.corners.join()}>
              <ValueChange value={isSpeffz(draft) ? 'Speffz' : draft.schemeName && draft.schemeName !== 'Speffz' ? draft.schemeName : 'Custom'} onChange={() => openEditor('lettering')} />
            </SettingRow>
            <SettingRow label="Edge buffer" changed={draft.edgeBuffer !== saved.edgeBuffer}>
              <ValueChange
                value={<span className="font-mono">{stickerName('edge', draft.edgeBuffer)}</span>}
                sub={draft.edges[draft.edgeBuffer]}
                onChange={() => openEditor('edgeBuffer')} />
              
            </SettingRow>
            <SettingRow label="Corner buffer" changed={draft.cornerBuffer !== saved.cornerBuffer}>
              <ValueChange
                value={<span className="font-mono">{stickerName('corner', draft.cornerBuffer)}</span>}
                sub={draft.corners[draft.cornerBuffer]}
                onChange={() => openEditor('cornerBuffer')} />
              
            </SettingRow>
            <SettingRow label="Cube view" changed={draft.viewTop !== saved.viewTop || draft.viewFront !== saved.viewFront}>
              <ValueChange
                value={
                <span className="flex items-center gap-2">
                    <span className="flex gap-0.5">
                      <span className="h-3.5 w-3.5 rounded-[3px]" style={{ background: STICKER_HEX[draft.viewTop] }} />
                      <span className="h-3.5 w-3.5 rounded-[3px]" style={{ background: STICKER_HEX[draft.viewFront] }} />
                    </span>
                    <span className="hidden sm:inline">
                      {COLOR_NAMES[draft.viewTop]} top, {COLOR_NAMES[draft.viewFront].toLowerCase()} front
                    </span>
                  </span>
                }
                onChange={() => openEditor('view')} />
              
            </SettingRow>
          </Section>

          <Section id="methods" title="Methods">
            <SettingRow label="Edges" changed={draft.edgeMethod !== saved.edgeMethod}>
              <Segmented
                size="sm"
                label="Edge method"
                value={draft.edgeMethod}
                onChange={(m) => setDraft((d) => ({ ...d, edgeMethod: m, edgeBuffer: m === 'M2' ? 20 : 3 }))}
                options={[
                { value: 'M2', label: 'M2' },
                { value: 'OP', label: 'OP' }]
                } />
              
            </SettingRow>
            <SettingRow label="Corners">
              <Segmented size="sm" label="Corner method" value="OP" onChange={() => undefined} options={[{ value: 'OP', label: 'OP' }]} />
            </SettingRow>
            <SettingRow label="Automatically swap M2 targets" hint="Execution memo only, with M2 edges. Raw traces stay unchanged.">
              <Toggle label="Automatically swap M2 targets" checked={store.prefs.m2Swap} onChange={(v) => store.setPrefs({ m2Swap: v })} />
            </SettingRow>
            <SettingRow label="Memo order">
              <Segmented
                size="sm"
                label="Memo order"
                value={store.prefs.memoOrder}
                onChange={(v) => store.setPrefs({ memoOrder: v })}
                options={[
                { value: 'corners', label: 'Corners first' },
                { value: 'edges', label: 'Edges first' }]
                } />
              
            </SettingRow>
          </Section>

          <Section id="timer" title="Timer">
            <SettingRow label="Show live timer" hint="When off, a running solve shows Solve instead of the time.">
              <Toggle label="Show live timer" checked={store.prefs.showLiveTimer} onChange={(v) => store.setPrefs({ showLiveTimer: v })} />
            </SettingRow>
            <SettingRow label="Multiphase timing" hint="Press once to end memo, again to stop.">
              <Toggle label="Multiphase timing" checked={store.prefs.multiphase} onChange={(v) => store.setPrefs({ multiphase: v })} />
            </SettingRow>
          </Section>

          <Section id="account" title="Account & sync">
            <AccountPanel />
          </Section>

          <Section id="data" title="Data">
            <DataPanel />
          </Section>

          <Section id="support" title="Support">
            <SettingRow label="Give feedback" hint="Bugs, requests, anything else.">
              <Button size="sm" variant="secondary" onClick={() => setFeedbackOpen(true)}>
                Write
              </Button>
            </SettingRow>
            {isAdmin &&
            <SettingRow label="Feedback inbox" hint={`${newFeedback} new`}>
                <Link to="/admin/feedback" className="inline-flex h-8 items-center rounded-md border border-line bg-raised px-3 text-[13px] font-medium hover:border-line-strong">
                  Open inbox
                </Link>
              </SettingRow>
            }
            <SettingRow label="First-use setup" hint="Walk through lettering and buffers again.">
              <Link to="/setup" className="inline-flex h-8 items-center rounded-md px-3 text-[13px] font-medium text-muted hover:bg-raised hover:text-fg">
                Run setup
              </Link>
            </SettingRow>
          </Section>
        </div>

        {dirty &&
        <div className="sticky bottom-0 z-10 border-t border-line bg-surface">
            <div className="mx-auto flex max-w-[700px] items-center gap-3 px-4 py-3 md:px-10" role="region" aria-label="Unsaved setup changes">
              <span className="flex items-center gap-2 text-[13px] text-fg">
                <span className="h-1.5 w-1.5 rounded-full bg-warn" />
                Unsaved setup changes
              </span>
              <div className="ml-auto flex gap-2">
                <Button size="sm" variant="ghost" onClick={() => setDraftState(saved)} disabled={saving}>
                  Discard
                </Button>
                <Button size="sm" variant="primary" onClick={save} disabled={saving}>
                  {saving ? 'Saving…' : 'Save'}
                </Button>
              </div>
            </div>
          </div>
        }
      </div>

      <CubeEditor open={editor !== null} mode={editor ?? lastMode} setMode={(m) => setEditor(m)} draft={draft} setDraft={setDraft} onClose={() => setEditor(null)} />
      <FeedbackSheet open={feedbackOpen} onClose={() => setFeedbackOpen(false)} />
    </div>);

}

function Section({ id, title, children }: {id: string;title: string;children: React.ReactNode;}) {
  return (
    <section id={id} aria-labelledby={`${id}-h`} className="scroll-mt-4 pt-8 first-of-type:pt-4">
      <h2 id={`${id}-h`} className="mb-1 text-[15px] font-semibold tracking-[-0.01em] text-fg">
        {title}
      </h2>
      <div>{children}</div>
    </section>);

}

function ValueChange({ value, sub, onChange }: {value: React.ReactNode;sub?: string;onChange: () => void;}) {
  return (
    <button type="button" onClick={onChange} className="group flex h-9 items-center gap-3 rounded-md px-2 text-[14px] text-fg hover:bg-raised">
      {value}
      {sub && <span className="font-mono text-[12.5px] text-faint">{sub}</span>}
      <span className="text-[13px] text-muted group-hover:text-fg">Change</span>
    </button>);

}