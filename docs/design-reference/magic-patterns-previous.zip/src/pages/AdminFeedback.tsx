import React, { useMemo, useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { ChevronLeftIcon, SearchIcon } from 'lucide-react';
import { useStore } from '../contexts/AppStore';
import { FeedbackStatus, FeedbackType } from '../types/domain';
import { useMediaQuery } from '../hooks/useMediaQuery';
import { Sheet } from '../components/ui/Sheet';
import { FeedbackDetail, STATUS_LABEL, TYPE_LABEL } from '../components/feedback/FeedbackDetail';

type StatusFilter = 'open' | FeedbackStatus | 'all';

export function AdminFeedbackPage() {
  const store = useStore();
  const desktop = useMediaQuery('(min-width: 1100px)');
  const [type, setType] = useState<'all' | FeedbackType>('all');
  const [status, setStatus] = useState<StatusFilter>('open');
  const [q, setQ] = useState('');
  const [selected, setSelected] = useState<string | null>(null);

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return store.feedback.
    filter((f) => type === 'all' || f.type === type).
    filter((f) => status === 'all' ? true : status === 'open' ? f.status !== 'archived' : f.status === status).
    filter(
      (f) =>
      !needle ||
      [f.message, f.contact, f.user?.name, f.user?.detail, f.source].some((s) => s?.toLowerCase().includes(needle))
    ).
    sort((a, b) => b.date.localeCompare(a.date));
  }, [store.feedback, type, status, q]);

  if (store.account.mode !== 'admin') return <Navigate to="/settings" replace />;

  const record = store.feedback.find((f) => f.id === selected);
  const newCount = store.feedback.filter((f) => f.status === 'new').length;
  const selectCls =
  'h-9 rounded-md border border-line bg-bg px-2.5 text-[13px] text-fg focus:border-line-strong focus:outline-none';

  return (
    <div className="flex h-full w-full">
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="shrink-0 px-4 pt-4 md:px-8 md:pt-7">
          <Link to="/settings#support" className="-ml-1 inline-flex h-7 items-center gap-1 text-[12.5px] text-muted hover:text-fg">
            <ChevronLeftIcon className="h-3.5 w-3.5" /> Settings
          </Link>
          <div className="mt-1 flex items-baseline gap-3">
            <h1 className="text-[20px] font-semibold tracking-[-0.02em]">Feedback inbox</h1>
            <span className="tnum font-mono text-[12.5px] text-signal">{newCount} new</span>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2 pb-3">
            <label className="relative min-w-[180px] flex-1">
              <SearchIcon className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-faint" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search feedback"
                aria-label="Search feedback"
                className="h-9 w-full rounded-md border border-line bg-bg pl-8 pr-3 text-[13px] text-fg placeholder:text-faint focus:border-line-strong focus:outline-none" />
              
            </label>
            <select aria-label="Type" value={type} onChange={(e) => setType(e.target.value as typeof type)} className={selectCls}>
              <option value="all">All types</option>
              <option value="bug">Bugs</option>
              <option value="feature">Feature requests</option>
              <option value="general">General</option>
            </select>
            <select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)} className={selectCls}>
              <option value="open">Open</option>
              {(Object.keys(STATUS_LABEL) as FeedbackStatus[]).map((s) =>
              <option key={s} value={s}>
                  {STATUS_LABEL[s]}
                </option>
              )}
              <option value="all">Everything</option>
            </select>
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto border-t border-line">
          {list.length === 0 ?
          <p className="px-4 py-10 text-[13.5px] text-faint md:px-8">
              {store.feedback.length === 0 ? 'No feedback yet' : q ? `Nothing matches “${q}”` : 'Nothing with these filters'}
            </p> :

          <ul>
              {list.map((f) =>
            <li key={f.id} className="border-b border-line">
                  <button
                type="button"
                onClick={() => setSelected(f.id)}
                aria-current={selected === f.id || undefined}
                className={`grid w-full grid-cols-[1fr_auto] gap-x-4 gap-y-1 px-4 py-3 text-left transition-colors duration-100 hover:bg-raised md:grid-cols-[7rem_1fr_7rem_6rem] md:items-baseline md:px-8 ${
                selected === f.id ? 'bg-raised' : ''}`
                }>
                
                    <span className={`text-[12.5px] ${f.type === 'bug' ? 'text-danger' : 'text-muted'}`}>{TYPE_LABEL[f.type]}</span>
                    <span className="order-3 col-span-2 line-clamp-2 text-[13.5px] text-fg md:order-none md:col-span-1">{f.message}</span>
                    <span className="hidden truncate font-mono text-[12px] text-faint md:block">{f.user?.name ?? f.contact ?? 'Guest'}</span>
                    <span className={`text-right text-[12px] ${f.status === 'new' ? 'text-signal' : 'text-faint'}`}>{STATUS_LABEL[f.status]}</span>
                  </button>
                </li>
            )}
            </ul>
          }
        </div>
      </div>

      {desktop && record ?
      <aside className="w-[420px] shrink-0 overflow-y-auto border-l border-line px-6 pb-6 pt-7">
          <FeedbackDetail record={record} onClose={() => setSelected(null)} />
        </aside> :

      <Sheet open={!desktop && !!record} onClose={() => setSelected(null)} title="Feedback" widthClass="md:w-[460px]">
          {record && <FeedbackDetail record={record} onClose={() => setSelected(null)} />}
        </Sheet>
      }
    </div>);

}