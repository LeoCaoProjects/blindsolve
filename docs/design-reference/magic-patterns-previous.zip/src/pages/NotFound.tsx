import React from 'react';
import { Link } from 'react-router-dom';

export function NotFoundPage() {
  return (
    <div className="flex h-full w-full items-center justify-center px-6">
      <div className="max-w-sm">
        <p className="font-mono text-[13px] text-faint">404</p>
        <h1 className="mt-2 text-[24px] font-semibold tracking-[-0.02em]">Page not found</h1>
        <p className="mt-2 text-[14px] text-muted">This address does not exist.</p>
        <Link to="/" className="mt-6 inline-flex h-10 items-center rounded-md bg-fg px-4 text-sm font-medium text-bg hover:bg-white">
          Go to Timer
        </Link>
      </div>
    </div>);

}