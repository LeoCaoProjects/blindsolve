import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeftIcon, ChevronRightIcon, ChevronDownIcon } from 'lucide-react';
import { useStore } from '../contexts/AppStore';
import { effectiveWords, hasOverride, pairKey, PairContext, countForFirst } from '../utils/pairs';
import { scopeTokens } from '../utils/lettering';
import { overlayOpen } from '../utils/dom';
import { Segmented } from '../components/ui/Segmented';
import { Sheet } from '../components/ui/Sheet';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { Button } from '../components/ui/Button';
import { TokenGrid } from '../components/pairs/TokenGrid';
import { PairInspector } from '../components/pairs/PairInspector';

export function LetterPairsPage() {
  const store = useStore();
  const [ctx, setCtx] = useState<PairContext>('shared');
  const tokens = useMemo(() => scopeTokens(store.scheme, ctx === 'shared' ? 'shared' : ctx), [store.scheme, ctx]);
  const [first, setFirst] = useState(tokens[0] ?? 'A');
  const [focusIdx, setFocusIdx] = useState(0);
  const [editing, setEditing] = useState<string | null>(null);
  const [gridOpen, setGridOpen] = useState(false);
  const [confirmSection, setConfirmSection] = useState(false);
  const rowRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const typed = useRef({ buf: '', at: 0 });

  const seconds = tokens;
  const possible = Math.max(0, tokens.length - 1);
  const filled = countForFirst(store.pairs, first, tokens, ctx);
  const sectionEntries = Object.keys(store.pairs).filter((k) => k.split('|')[0] === first).length;
  const empty = Object.keys(store.pairs).length === 0;

  const selectFirst = (t: string) => {
    setFirst(t);
    setFocusIdx(0);
  };
  const cycleFirst = (dir: number) => {
    const i = tokens.indexOf(first);
    selectFirst(tokens[(i + dir + tokens.length) % tokens.length]);
  };

  const focusRow = (i: number) => {
    const n = Math.max(0, Math.min(seconds.length - 1, i));
    setFocusIdx(n);
    rowRefs.current[n]?.focus();
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (overlayOpen() || editing) return;
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;
      if (e.key === '[' || e.key === 'PageUp') {
        e.preventDefault();
        cycleFirst(-1);
      } else if (e.key === ']' || e.key === 'PageDown') {
        e.preventDefault();
        cycleFirst(1);
      } else if (e.key.length === 1 && /[a-z0-9]/i.test(e.key) && !e.metaKey && !e.ctrlKey) {
        const now = Date.now();
        const buf = (now - typed.current.at < 900 ? typed.current.buf : '') + e.key.toUpperCase();
        typed.current = { buf, at: now };
        const f = [...tokens].sort((x, y) => y.length - x.length).find((t) => buf.startsWith(t));
        if (f) {
          if (f !== first) selectFirst(f);
          const rest = buf.slice(f.length);
          const s = rest && seconds.findIndex((t) => t === rest);
          if (typeof s === 'number' && s >= 0) window.setTimeout(() => focusRow(s), 0);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const onListKey = (e: React.KeyboardEvent) => {
    const map: Record<string, number> = { ArrowDown: 1, ArrowUp: -1, ArrowRight: 4, ArrowLeft: -4 };
    if (map[e.key] !== undefined) {
      e.preventDefault();
      focusRow(focusIdx + map[e.key]);
    } else if (e.key === 'Home') {
      e.preventDefault();
      focusRow(0);
    } else if (e.key === 'End') {
      e.preventDefault();
      focusRow(seconds.length - 1);
    }
  };

  const scopeControl =
  <Segmented<PairContext>
    size="sm"
    label="Vocabulary"
    value={ctx}
    onChange={setCtx}
    options={[
    { value: 'shared', label: 'Shared' },
    { value: 'edges', label: 'Edges' },
    { value: 'corners', label: 'Corners' }]
    } />;



  return (
    <div className="flex h-full w-full">
      <aside className="hidden w-[248px] shrink-0 flex-col border-r border-line px-4 pb-4 pt-7 md:flex short:pt-4">
        <h1 className="mb-3 px-1 text-[12px] font-medium text-faint">Letter Pairs</h1>
        {scopeControl}
        <div className="mt-5 min-h-0 flex-1 overflow-y-auto">
          <TokenGrid tokens={tokens} selected={first} onSelect={selectFirst} db={store.pairs} ctx={ctx} />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <h1 className="sr-only md:hidden">Letter Pairs</h1>
        <header className="flex shrink-0 flex-wrap items-center gap-x-4 gap-y-2 px-4 pb-3 pt-3 md:px-10 md:pb-4 md:pt-7 short:md:pt-4">
          <div className="flex items-center gap-1">
            <Button size="icon-sm" variant="ghost" aria-label="Previous first letter" onClick={() => cycleFirst(-1)}>
              <ChevronLeftIcon className="h-4 w-4" />
            </Button>
            <button
              type="button"
              onClick={() => setGridOpen(true)}
              className="flex items-baseline gap-2 rounded-md px-1.5 md:pointer-events-none"
              aria-label={`First letter ${first}. Choose another`}>
              
              <span className="font-mono text-[34px] font-medium leading-none md:text-[40px]">{first}</span>
              <ChevronDownIcon className="h-4 w-4 self-center text-faint md:hidden" />
            </button>
            <Button size="icon-sm" variant="ghost" aria-label="Next first letter" onClick={() => cycleFirst(1)}>
              <ChevronRightIcon className="h-4 w-4" />
            </Button>
            <span className="tnum ml-2 font-mono text-[13px] text-muted">
              {filled}
              <span className="text-faint">/{possible}</span>
            </span>
          </div>
          <div className="md:hidden">{scopeControl}</div>
          {sectionEntries > 0 &&
          <Button size="sm" variant="ghost" className="ml-auto text-faint hover:text-danger" onClick={() => setConfirmSection(true)}>
              Clear {first}·
            </Button>
          }
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 pb-8 md:px-10">
          {empty && <p className="mb-4 text-[13.5px] text-muted">No mnemonics yet. Choose a pair to add its first word.</p>}
          <ul role="list" onKeyDown={onListKey} className="grid gap-x-10 xl:grid-cols-2">
            {seconds.map((second, i) => {
              const key = pairKey(first, second);
              const entry = store.pairs[key];
              const diag = second === first;
              const words = effectiveWords(entry, ctx);
              const inherited = ctx !== 'shared' && !hasOverride(entry, ctx) && words.length > 0;
              const overrideE = ctx === 'shared' && hasOverride(entry, 'edges');
              const overrideC = ctx === 'shared' && hasOverride(entry, 'corners');
              return (
                <li key={second} className="border-b border-line">
                  <button
                    ref={(el) => rowRefs.current[i] = el}
                    type="button"
                    disabled={diag}
                    tabIndex={i === focusIdx ? 0 : -1}
                    onFocus={() => setFocusIdx(i)}
                    onClick={() => setEditing(key)}
                    className="group flex h-12 w-full items-center gap-4 px-1 text-left transition-colors duration-100 hover:bg-raised/60 focus-visible:bg-raised disabled:cursor-default disabled:hover:bg-transparent">
                    
                    <span className={`w-12 shrink-0 font-mono text-[17px] tracking-[0.06em] ${diag ? 'text-faint/50' : 'text-fg'}`}>
                      {first}
                      {second}
                    </span>
                    {diag ?
                    <span className="text-[12.5px] text-faint/70">not a pair</span> :
                    words.length ?
                    <span className="flex min-w-0 flex-1 items-baseline gap-2">
                        <span className={`truncate font-serif text-[17px] italic ${inherited ? 'text-muted' : 'text-fg'}`}>{words[0]}</span>
                        {words.length > 1 && <span className="truncate text-[12.5px] text-faint">+{words.slice(1).join(', ')}</span>}
                      </span> :

                    <span className="flex-1 text-[13px] text-faint/70 group-hover:text-faint">—</span>
                    }
                    <span className="ml-auto flex shrink-0 items-center gap-2 text-[11px] text-faint">
                      {inherited && <span>shared</span>}
                      {ctx !== 'shared' && hasOverride(entry, ctx) && <span className="text-muted">{ctx === 'edges' ? 'edge' : 'corner'} word</span>}
                      {overrideE && <span title={`Edges: ${entry?.edges?.[0]}`}>E·{entry?.edges?.[0]}</span>}
                      {overrideC && <span title={`Corners: ${entry?.corners?.[0]}`}>C·{entry?.corners?.[0]}</span>}
                      {entry && entry.usage > 0 && <span className="tnum hidden font-mono sm:inline">{entry.usage}×</span>}
                    </span>
                  </button>
                </li>);

            })}
          </ul>
        </div>
      </div>

      <Sheet open={gridOpen} onClose={() => setGridOpen(false)} title="First letter">
        <TokenGrid
          tokens={tokens}
          selected={first}
          onSelect={(t) => {
            selectFirst(t);
            setGridOpen(false);
          }}
          db={store.pairs}
          ctx={ctx} />
        
      </Sheet>

      <PairInspector
        pairKeyValue={editing}
        initialCtx={ctx}
        onClose={() => {
          const idx = focusIdx;
          setEditing(null);
          window.setTimeout(() => rowRefs.current[idx]?.focus(), 40);
        }} />
      

      <ConfirmDialog
        open={confirmSection}
        title={`Clear every ${first}· pair?`}
        confirmLabel="Clear section"
        onCancel={() => setConfirmSection(false)}
        onConfirm={() => {
          store.clearFirstToken(first);
          setConfirmSection(false);
        }}>
        
        Removes {sectionEntries} {sectionEntries === 1 ? 'entry' : 'entries'} starting with {first} — primary words, alternates and edge and corner
        overrides, in every scope, not only {ctx === 'shared' ? 'Shared' : ctx === 'edges' ? 'Edges' : 'Corners'}.
      </ConfirmDialog>
    </div>);

}