import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { MotionConfig } from 'framer-motion';
import { AppStoreProvider } from './contexts/AppStore';
import { ChromeProvider } from './contexts/ChromeContext';
import { TimerProvider } from './contexts/TimerContext';
import { TrainingProvider } from './contexts/TrainingContext';
import { ErrorBoundary } from './components/shell/ErrorBoundary';
import { AppShell } from './components/shell/AppShell';
import { TimerPage } from './pages/Timer';
import { TrainingPage } from './pages/Training';
import { LetterPairsPage } from './pages/LetterPairs';
import { FlashcardsPage } from './pages/Flashcards';
import { SettingsPage } from './pages/Settings';
import { SetupPage } from './pages/Setup';
import { SignInPage } from './pages/SignIn';
import { AdminFeedbackPage } from './pages/AdminFeedback';
import { NotFoundPage } from './pages/NotFound';

interface AppProps {
  /** Prototype state simulators — not product settings. */
  accountMode?: 'guest' | 'signedIn' | 'admin' | 'unconfigured';
  syncStatus?: 'synced' | 'saving' | 'offline' | 'failed';
  emptyWorkspace?: boolean;
  simulateFailures?: boolean;
}

export function App({ accountMode = 'admin', syncStatus = 'synced', emptyWorkspace = false, simulateFailures = false }: AppProps) {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AppStoreProvider
          key={`${emptyWorkspace}-${simulateFailures}`}
          accountMode={accountMode}
          syncStatus={syncStatus}
          emptyWorkspace={emptyWorkspace}
          simulateFailures={simulateFailures}>
          
          <ChromeProvider>
            <TimerProvider>
              <TrainingProvider>
                <MotionConfig reducedMotion="user">
                  <Routes>
                    <Route element={<AppShell />}>
                      <Route path="/" element={<TimerPage />} />
                      <Route path="/training" element={<TrainingPage />} />
                      <Route path="/pairs" element={<LetterPairsPage />} />
                      <Route path="/flashcards" element={<FlashcardsPage />} />
                      <Route path="/settings" element={<SettingsPage />} />
                      <Route path="/admin/feedback" element={<AdminFeedbackPage />} />
                      <Route path="*" element={<NotFoundPage />} />
                    </Route>
                    <Route path="/setup" element={<SetupPage />} />
                    <Route path="/signin" element={<SignInPage />} />
                    <Route path="/memo" element={<Navigate to="/training" replace />} />
                    <Route path="/about" element={<Navigate to="/" replace />} />
                  </Routes>
                </MotionConfig>
              </TrainingProvider>
            </TimerProvider>
          </ChromeProvider>
        </AppStoreProvider>
      </BrowserRouter>
    </ErrorBoundary>);

}